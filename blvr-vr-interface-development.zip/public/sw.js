/* BLVR service worker – makes the app installable and fast to reopen (also offline for the core UI).
 * - App page: network-first (updates arrive immediately), falls back to the cached copy offline.
 * - Own images/icons: stale-while-revalidate.
 * - MediaPipe hand model + WASM (versioned URLs, ~20 MB): cache-first → hand tracking starts fast next time.
 * - Everything else (YouTube, APIs, radios…): untouched, straight to the network.
 */
const VERSION = 'blvr-v1';
const SHELL = [
  './', './index.html', './manifest.webmanifest', './icons/icon.svg', './icons/blvr-icon.png',
  './env/panorama.jpg', './img/hero.jpg', './img/neonpop.jpg', './img/meta.jpg',
];
const HEAVY = /^https:\/\/(cdn\.jsdelivr\.net\/npm\/@mediapipe\/|storage\.googleapis\.com\/mediapipe-models\/)/;

self.addEventListener('install', (e) => {
  e.waitUntil((async () => {
    const c = await caches.open(VERSION);
    await Promise.all(SHELL.map((u) => c.add(u).catch(() => undefined))); // one missing file never breaks install
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k !== VERSION && k !== 'blvr-heavy').map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  if (HEAVY.test(req.url)) {
    e.respondWith((async () => {
      const c = await caches.open('blvr-heavy');
      const hit = await c.match(req);
      if (hit) return hit;
      const res = await fetch(req);
      if (res.ok) c.put(req, res.clone()).catch(() => undefined);
      return res;
    })());
    return;
  }

  if (url.origin !== self.location.origin) return;

  if (req.mode === 'navigate') {
    e.respondWith((async () => {
      try {
        const res = await fetch(req);
        const c = await caches.open(VERSION);
        c.put('./index.html', res.clone()).catch(() => undefined);
        return res;
      } catch {
        return (await caches.match('./index.html')) || (await caches.match('./')) || Response.error();
      }
    })());
    return;
  }

  e.respondWith((async () => {
    const c = await caches.open(VERSION);
    const hit = await c.match(req);
    const net = fetch(req).then((res) => { if (res.ok) c.put(req, res.clone()).catch(() => undefined); return res; }).catch(() => undefined);
    return hit || (await net) || Response.error();
  })());
});
