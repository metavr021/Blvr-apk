import { useStore } from './core/store';
import { useSystemServices } from './core/system';
import { VRView } from './components/VRView';
import { StartScreen } from './components/StartScreen';

/**
 * BLVR entry point. Architecture:
 *  core/camera.ts      – shared camera stream (passthrough + hand tracking)
 *  core/hands.ts       – MediaPipe hand tracking (Web Worker, throttled, mutable buffers)
 *  core/orientation.ts – 3DOF sensors
 *  core/renderer.ts    – rAF render loop (read → compute → write → draw)
 *  core/spatial.ts     – world-locked anchors (menu, windows, bar) mutated without React
 *  core/input.ts       – ray / pinch / hold / gaze / touch, overlay drawing
 *  core/system.ts      – service lifecycle
 *  components/*        – VR UI (eyes, menu, windows, settings)
 */
export default function App() {
  const started = useStore((s) => s.started);
  useSystemServices();
  return started ? <VRView /> : <StartScreen />;
}
