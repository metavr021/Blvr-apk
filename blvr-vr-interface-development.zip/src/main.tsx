import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";
import { initInstall } from "./core/install";

initInstall(); // service worker + "install app" prompt (PWA → also the base for the Android APK)

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
