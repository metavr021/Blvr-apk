/**
 * System services lifecycle (camera / passthrough, hand tracking, 3DOF sensors, battery, network).
 * Every service fails independently and gracefully: a failing camera, MediaPipe or sensor never
 * stops the renderer – the UI falls back to the virtual environment / gaze cursor.
 */
import { useEffect, useRef } from 'react';
import { useStore, S } from './store';
import { startGyro, stopGyro } from './orientation';
import { startHandTracking, stopHandTracking, resetHandEngine, applyHandsNum } from './hands';
import { initQuest } from './quest';
import { acquireCamera, releaseCamera, refreshCamera } from './camera';
import { initPerf } from './perf';

export function useSystemServices() {
  const started = useStore((s) => s.started);
  const handTracking = useStore((s) => s.settings.handTracking);
  const gyroEnabled = useStore((s) => s.settings.gyroEnabled);

  const passthrough = useStore((s) => s.settings.passthrough);
  const cam = useStore((s) => s.settings.camera);
  const res = useStore((s) => s.settings.cameraRes);
  const perfMode = useStore((s) => s.settings.perfMode);

  // Performance governor (auto / leve / qualidade)
  useEffect(() => { initPerf(); }, [perfMode]);

  // Passthrough camera (shared stream) – not displayed inside the metaverse
  const meta = useStore((s) => s.meta);
  useEffect(() => {
    if (!started || !passthrough || meta) return;
    acquireCamera('passthrough').catch((e: Error) => {
      S().toast(`Câmera indisponível (${e?.message || 'erro'}). Usando ambiente virtual.`, 'warn');
    });
    return () => releaseCamera('passthrough');
  }, [started, passthrough, meta]);

  // Facing / resolution changes: re-open only if needed (no restart otherwise)
  useEffect(() => {
    if (started) void refreshCamera();
  }, [started, cam, res, passthrough, meta]);

  // Number of tracked hands (1 = faster)
  const handsNum = useStore((s) => s.settings.handsNum);
  useEffect(() => { if (started) applyHandsNum(); }, [started, handsNum]);

  // Quest-style features (double-tap the headset → passthrough)
  useEffect(() => { if (started) initQuest(); }, [started]);

  // Hand tracking
  useEffect(() => {
    if (!started) return;
    if (handTracking) void startHandTracking();
    else stopHandTracking();
  }, [started, handTracking]);

  // CPU/GPU engine change → recreate the model
  const delegate = useStore((s) => s.settings.handDelegate);
  const firstDelegate = useRef(true);
  useEffect(() => {
    if (firstDelegate.current) { firstDelegate.current = false; return; }
    if (!started) return;
    resetHandEngine();
    if (S().settings.handTracking) setTimeout(() => void startHandTracking(), 100);
  }, [delegate, started]);
  useEffect(() => () => stopHandTracking(), []);

  // 3DOF
  useEffect(() => {
    if (!started) return;
    if (gyroEnabled) { stopGyro(); void startGyro(); } else stopGyro();
  }, [started, gyroEnabled]);

  // Battery + network
  useEffect(() => {
    const nav = navigator as Navigator & {
      getBattery?: () => Promise<{ level: number; charging: boolean; addEventListener: (t: string, f: () => void) => void }>;
      connection?: { type?: string; effectiveType?: string; addEventListener?: (t: string, f: () => void) => void };
    };
    nav.getBattery?.().then((b) => {
      const upd = () => S().set({ battery: { level: b.level, charging: b.charging } });
      upd();
      b.addEventListener('levelchange', upd);
      b.addEventListener('chargingchange', upd);
    }).catch(() => undefined);
    const net = () => {
      const c = nav.connection;
      S().set({ online: navigator.onLine, netType: c ? (c.type === 'wifi' ? 'Wi-Fi' : c.type === 'cellular' ? 'Dados' : (c.effectiveType || '').toUpperCase()) : '' });
    };
    net();
    window.addEventListener('online', net);
    window.addEventListener('offline', net);
    nav.connection?.addEventListener?.('change', net);
    return () => { window.removeEventListener('online', net); window.removeEventListener('offline', net); };
  }, []);
}
