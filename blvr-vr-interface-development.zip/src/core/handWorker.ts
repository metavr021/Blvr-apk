/**
 * Hand tracking Web Worker (classic worker so MediaPipe can use importScripts).
 *
 * Input:
 *  1. 'stream' (preferred): ReadableStream<VideoFrame> from a MediaStreamTrackProcessor → camera frames go
 *     straight into this worker; the UI thread does nothing per frame. Old frames are dropped (no backlog).
 *  2. 'frame' (fallback): downscaled ImageBitmaps from the main thread.
 *
 * Engine 'AUTO': benchmarks GPU and CPU on THIS phone (25 frames each) and keeps the fastest.
 * (On some phones the GPU delegate is faster, on others the CPU – guessing was the main cause of lag.)
 * Reports { type:'engine', delegate, ms } so the UI can show the real per-frame cost.
 */
import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision';

interface Ctx { postMessage: (m: unknown, t?: Transferable[]) => void; onmessage: ((e: MessageEvent) => void) | null }
const ctx = self as unknown as Ctx;
type Del = 'GPU' | 'CPU';

let lm: HandLandmarker | null = null;
let lmDel: Del = 'CPU';
let fileset: Awaited<ReturnType<typeof FilesetResolver.forVisionTasks>> | null = null;
let modelUrl = '';
let mode: 'AUTO' | Del = 'AUTO';
let fps = 30;
let reader: ReadableStreamDefaultReader<VideoFrame> | null = null;
let lastTs = 0;
let lastRun = 0;
let switching = false;
let rolling = 0;
let lastReport = 0;
const bench = { phase: 0, n: 0, sum: 0, gpu: Infinity, cpu: Infinity };

// numHands: with 2, MediaPipe re-runs the (expensive) palm detector EVERY frame while it hasn't found the
// second hand → roughly double cost. 1 hand = palm detection only when the hand is lost → much faster.
let numHands = 1;
const make = (delegate: Del) => HandLandmarker.createFromOptions(fileset!, {
  baseOptions: { modelAssetPath: modelUrl, delegate },
  runningMode: 'VIDEO',
  numHands,
  minHandDetectionConfidence: 0.5,
  minHandPresenceConfidence: 0.5,
  minTrackingConfidence: 0.5,
});

async function init(wasm: string, model: string, want: 'AUTO' | Del) {
  fileset = await FilesetResolver.forVisionTasks(wasm);
  modelUrl = model;
  mode = want;
  if (want !== 'CPU') {
    try { lm = await make('GPU'); lmDel = 'GPU'; return 'GPU'; } catch { /* no WebGL in worker → CPU */ }
  }
  lm = await make('CPU');
  lmDel = 'CPU';
  bench.phase = 2; // nothing to compare
  return 'CPU';
}

async function switchTo(d: Del) {
  switching = true;
  try {
    const n = await make(d);
    const old = lm;
    lm = n; lmDel = d;
    old?.close();
  } catch {
    if (d === 'GPU') bench.gpu = Infinity; else bench.cpu = Infinity;
    bench.phase = 2;
  } finally {
    switching = false;
    rolling = 0;
  }
}

function measured(ms: number) {
  rolling = rolling ? rolling * 0.85 + ms * 0.15 : ms;
  if (mode === 'AUTO' && bench.phase < 2 && !switching) {
    bench.n++; bench.sum += ms;
    if (bench.n >= 25) {
      const avg = bench.sum / bench.n;
      bench.n = 0; bench.sum = 0;
      if (lmDel === 'GPU') bench.gpu = avg; else bench.cpu = avg;
      bench.phase++;
      if (bench.phase === 1) void switchTo(lmDel === 'GPU' ? 'CPU' : 'GPU');
      else {
        const best: Del = bench.gpu <= bench.cpu ? 'GPU' : 'CPU';
        if (best !== lmDel) void switchTo(best);
      }
    }
  }
  const now = performance.now();
  if (now - lastReport > 1500) {
    lastReport = now;
    ctx.postMessage({ type: 'engine', delegate: lmDel, ms: Math.round(rolling), testing: mode === 'AUTO' && bench.phase < 2 });
  }
}

function detect(src: TexImageSource) {
  const ts = Math.max(lastTs + 1, performance.now());
  lastTs = ts;
  const t0 = performance.now();
  const r = lm!.detectForVideo(src, ts);
  measured(performance.now() - t0);
  const hands: { label: string; lm: Float32Array; world: Float32Array }[] = [];
  const transfer: Transferable[] = [];
  r.landmarks.forEach((pts, i) => {
    const a = new Float32Array(63);
    const w = new Float32Array(63);
    const wp = r.worldLandmarks?.[i];
    for (let k = 0; k < 21; k++) {
      a[k * 3] = pts[k].x; a[k * 3 + 1] = pts[k].y; a[k * 3 + 2] = pts[k].z;
      if (wp) { w[k * 3] = wp[k].x; w[k * 3 + 1] = wp[k].y; w[k * 3 + 2] = wp[k].z; }
    }
    hands.push({ label: r.handedness?.[i]?.[0]?.categoryName ?? 'Right', lm: a, world: w });
    transfer.push(a.buffer, w.buffer);
  });
  ctx.postMessage({ type: 'result', hands }, transfer);
}

async function pump(readable: ReadableStream<VideoFrame>) {
  if (reader) { try { await reader.cancel(); } catch { /* ignore */ } }
  const my = readable.getReader();
  reader = my;
  for (;;) {
    let res: ReadableStreamReadResult<VideoFrame>;
    try { res = await my.read(); } catch { break; }
    if (res.done || reader !== my) { res.value?.close(); break; }
    const frame = res.value;
    const now = performance.now();
    if (!lm || switching || now - lastRun < 1000 / fps - 3) { frame.close(); continue; } // drop: rate cap / engine swap
    lastRun = now;
    try { detect(frame); } catch (err) { ctx.postMessage({ type: 'result', hands: [], error: String(err) }); }
    finally { frame.close(); }
  }
}

ctx.onmessage = async (e: MessageEvent) => {
  const m = e.data as { type: string; wasm?: string; model?: string; delegate?: 'AUTO' | Del; bitmap?: ImageBitmap; readable?: ReadableStream<VideoFrame>; fps?: number };
  if (m.type === 'init') {
    try {
      if (m.fps === 2 || m.fps === 1) numHands = m.fps; // init carries the hand count in `fps`
      const delegate = await init(m.wasm!, m.model!, m.delegate ?? 'AUTO');
      ctx.postMessage({ type: 'ready', delegate });
    } catch (err) {
      ctx.postMessage({ type: 'error', message: String((err as Error)?.message || err) });
    }
  } else if (m.type === 'hands') {
    numHands = m.fps === 2 ? 2 : 1;
    try { await lm?.setOptions({ numHands }); } catch { /* applied on next model creation */ }
  } else if (m.type === 'fps') {
    fps = Math.max(8, Math.min(30, m.fps ?? 30));
  } else if (m.type === 'stream') {
    if (m.fps) fps = m.fps;
    void pump(m.readable!);
  } else if (m.type === 'stop') {
    const r = reader; reader = null;
    try { await r?.cancel(); } catch { /* ignore */ }
  } else if (m.type === 'frame') {
    const bmp = m.bitmap!;
    if (!lm || switching) { bmp.close(); ctx.postMessage({ type: 'result', hands: [] }); return; }
    try { detect(bmp); } catch (err) { ctx.postMessage({ type: 'result', hands: [], error: String(err) }); }
    finally { bmp.close(); }
  }
};
