/**
 * 3DoF module – rotation sensors only (gyroscope + accelerometer) → head rotation.
 *
 *  - Sensor: 'deviceorientation' (Chrome/Android "game rotation vector" = gyro + accelerometer fusion,
 *    no magnetometer, no camera). Gyro = rotation; accelerometer (gravity) = correct up/down and tilt.
 *  - 3DoF = ROTATION ONLY: look up/down, turn sideways, tilt the head. No translation: walking, crouching
 *    or leaning does not move the scene (it stays at the same distance) – by design, no camera needed.
 *  - Math: NO Euler angles for rendering. The device quaternion is split with a swing–twist decomposition
 *    about the world vertical:  q = twist(heading) · swing(pitch+roll).
 *    The twist angle is continuous everywhere (no gimbal lock looking up/down, no jump at the horizon when
 *    the head is tilted – that jump made menus "jerk" in the previous version). The renderer uses the
 *    final quaternion directly (matrix3d), so the view always equals the real device orientation.
 *  - Heading is integrated from twist deltas → sensitivity, horizontal inversion and "Recalibrar" work.
 *  - Smoothing: One-Euro style filter on the quaternion (stable when still, low lag when turning).
 *  - Without a magnetometer the heading can drift slowly → "Recalibrar" re-centers it.
 */
import { deviceQuat, quatMul, quatConj, quatY, quatX, quatAngle, quatNlerp, quatRotate, wrap180, clamp, DEG, type Quat } from './math';
import { S } from './store';

/** Derived head angles in degrees (yaw + = left, pitch + = up). Used for UI placement / cursor math. */
export const pose = { yaw: 0, pitch: 0, roll: 0 };
export const manual = { yaw: 0, pitch: 0 };
/** Final smoothed head rotation (three.js convention: -Z forward, +Y up). The renderer uses this directly. */
export const headQ: Quat = [0, 0, 0, 1];

let raw: { a: number; b: number; g: number } | null = null;
let lastEvt = 0;
let lastSample = 0;
let listeningOn: '' | 'deviceorientation' = '';
let startedAt = 0;

let swing: Quat = [0, 0, 0, 1];
let prevTwist: number | null = null;
let yawAcc = 0;
let sm: Quat = [0, 0, 0, 1];
let speed = 0;
let snap = true;
let prevOutTwist: number | null = null;
let yawOut = 0;

function onOrient(e: DeviceOrientationEvent) {
  if (e.alpha == null || e.beta == null || e.gamma == null) return;
  raw = { a: e.alpha, b: e.beta, g: e.gamma };
  lastEvt = performance.now();
}

function screenAngle() {
  const so = (screen as Screen & { orientation?: { angle: number } }).orientation;
  if (so && typeof so.angle === 'number') return so.angle;
  const wo = (window as unknown as { orientation?: number }).orientation;
  return typeof wo === 'number' ? wo : 0;
}

function listen(ev: '' | 'deviceorientation') {
  if (listeningOn === ev) return;
  if (listeningOn) window.removeEventListener(listeningOn, onOrient as EventListener, true);
  listeningOn = ev;
  prevTwist = null;
  if (ev) window.addEventListener(ev, onOrient as EventListener, true);
}

export async function startGyro(): Promise<void> {
  const st = S();
  if (!st.settings.gyroEnabled) { st.set({ gyroStatus: 'off' }); return; }
  if (typeof DeviceOrientationEvent === 'undefined') { st.set({ gyroStatus: 'unavailable' }); return; }
  const DOE = DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> };
  if (typeof DOE.requestPermission === 'function') {
    try {
      const r = await DOE.requestPermission();
      if (r !== 'granted') { st.set({ gyroStatus: 'denied' }); return; }
    } catch { st.set({ gyroStatus: 'denied' }); return; }
  }
  listen('deviceorientation'); // relative: gyroscope + accelerometer only
  startedAt = performance.now();
  st.set({ gyroStatus: 'waiting' });
}

export function stopGyro() {
  listen('');
  raw = null;
  swing = [0, 0, 0, 1]; // keep the current heading, level the view
  S().set({ gyroStatus: 'off' });
}

/** Current look direction becomes the new center. */
export function recalibrate() {
  yawAcc = 0;
  manual.yaw = 0;
  manual.pitch = 0;
  snap = true;
}

/** Called once per animation frame (cheap). */
export function updatePose(dt: number) {
  const st = S();
  const set = st.settings;
  const now = performance.now();
  if (listeningOn) {
    if (raw && now - lastEvt < 2000) {
      if (st.gyroStatus !== 'active') st.set({ gyroStatus: 'active' });
    } else if (now - startedAt > 2500 && st.gyroStatus === 'waiting') {
      st.set({ gyroStatus: 'unavailable' });
    }
  }

  // New sensor sample → swing/twist decomposition
  if (listeningOn && raw && lastEvt !== lastSample) {
    lastSample = lastEvt;
    const q = deviceQuat(raw.a, raw.b, raw.g, screenAngle());
    const hl = Math.hypot(q[1], q[3]);
    if (hl > 1e-4) { // hl≈0 only when upside-down AND facing backwards – keep the last value then
      const twist: Quat = [0, q[1] / hl, 0, q[3] / hl];
      let sw = quatMul(quatConj(twist), q);
      if (set.invertV) sw = [-sw[0], sw[1], sw[2], sw[3]];
      swing = sw;
      const tw = 2 * Math.atan2(q[1], q[3]) * DEG;
      if (prevTwist !== null) {
        const d = wrap180(tw - prevTwist);
        if (Math.abs(d) < 120) yawAcc += d * set.sensitivity * (set.invertH ? -1 : 1); // >120° in one sample = glitch
      }
      prevTwist = tw;
    }
  }

  // Target rotation = heading · manual pitch · swing
  const T = quatMul(quatMul(quatY(yawAcc + manual.yaw), quatX(clamp(manual.pitch, -80, 80))), swing);

  // One-Euro smoothing on the rotation
  if (snap) {
    sm = T; speed = 0; snap = false; prevOutTwist = null;
  } else {
    const d = Math.max(dt, 1e-3);
    const ang = quatAngle(sm, T);
    const ad = 1 / (1 + 1 / (2 * Math.PI) / d);
    speed += (ang / d - speed) * ad;
    const minCut = 0.25 + (1 - clamp(set.smoothing, 0, 0.95)) * 7;
    const cutoff = minCut + 0.06 * speed;
    const a = 1 / (1 + 1 / (2 * Math.PI * cutoff) / d);
    sm = quatNlerp(sm, T, a);
  }
  headQ[0] = sm[0]; headQ[1] = sm[1]; headQ[2] = sm[2]; headQ[3] = sm[3];

  // Derived angles (continuous)
  const f = quatRotate(sm, [0, 0, -1]);
  pose.pitch = Math.asin(clamp(f[1], -1, 1)) * DEG;
  const tw = 2 * Math.atan2(sm[1], sm[3]) * DEG;
  const target = yawAcc + manual.yaw;
  if (prevOutTwist === null) yawOut = target + wrap180(tw - target);
  else yawOut += wrap180(tw - prevOutTwist);
  prevOutTwist = tw;
  pose.yaw = yawOut;
  const r = quatRotate(sm, [1, 0, 0]);
  pose.roll = -Math.asin(clamp(r[1], -1, 1)) * DEG;
}
