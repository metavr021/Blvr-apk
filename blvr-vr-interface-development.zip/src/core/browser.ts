/**
 * BLVR Browser Pro Engine.
 * Features:
 *  - Multi-Tabs with independent navigation history & modes.
 *  - Incognito Mode (Modo Anônimo) with isolated session, private styling, stealth icon & zero history trace.
 *  - Multiple search engines (DuckDuckGo, Google, Bing, StartPage, Wikipedia).
 *  - Reader Mode (Modo Leitura): Extracts clean article content, images, and text for sites that block iframes.
 *  - Bookmarks & Quick Dials (Favoritos) persisted in localStorage.
 *  - Zoom & Desktop / Mobile view toggle.
 *  - Fully integrated with BLVR's Big Floating Keyboard & Hand Tracking / Gaze Pinch.
 */
import { create } from 'zustand';
import { S, type AppId } from './store';
import { openApp } from './actions';
import { registerKb, openKb, closeKb } from './keyboard';
import { parseYouTube, ytOpen } from './apps';

export type SearchEngine = 'duckduckgo' | 'google' | 'bing' | 'startpage' | 'wikipedia';

export interface Bookmark {
  id: string;
  title: string;
  url: string;
  icon?: string;
  color?: string;
  category: 'frequentes' | 'tech' | 'noticias' | 'jogos' | 'util';
}

export interface HistoryItem {
  url: string;
  title: string;
  mode: 'home' | 'web' | 'reader' | 'search';
  time: number;
}

export interface Tab {
  id: string;
  title: string;
  url: string;
  input: string;
  mode: 'home' | 'web' | 'reader' | 'search';
  incognito: boolean;
  loading: boolean;
  error: string;
  history: HistoryItem[];
  histIdx: number;
  reader: { title: string; html: string; thumb?: string; byline?: string } | null;
  results: { title: string; snippet: string; url: string }[];
  zoom: number;
  desktop: boolean;
  engine: SearchEngine;
}

const DEFAULT_BOOKMARKS: Bookmark[] = [
  { id: 'twitch', title: 'Twitch', url: 'app:twitch', icon: '👾', color: 'bg-violet-600', category: 'frequentes' },
  { id: 'yt', title: 'YouTube', url: 'app:youtube', icon: '▶', color: 'bg-red-600', category: 'frequentes' },
  { id: 'wiki', title: 'Wikipédia', url: 'wiki:', icon: 'W', color: 'bg-zinc-700', category: 'frequentes' },
  { id: 'google', title: 'Google', url: 'https://www.google.com/webhp?igu=1', icon: 'G', color: 'bg-blue-600', category: 'frequentes' },
  { id: 'ddg', title: 'DuckDuckGo', url: 'https://html.duckduckgo.com/html/', icon: '🦆', color: 'bg-amber-600', category: 'frequentes' },
  { id: 'spotify', title: 'Spotify', url: 'app:spotify', icon: '♫', color: 'bg-emerald-600', category: 'frequentes' },
  { id: 'blockblast', title: 'Block Blast', url: 'app:blockblast', icon: '✨', color: 'bg-fuchsia-600', category: 'jogos' },
  { id: 'craft', title: 'BLVR Craft', url: 'app:craft', icon: '⛏', color: 'bg-green-700', category: 'jogos' },
  { id: 'mcclassic', title: 'Minecraft Web', url: 'https://classic.minecraft.net', icon: 'MC', color: 'bg-amber-800', category: 'jogos' },
  { id: 'reddit', title: 'Reddit', url: 'https://www.reddit.com', icon: 'R', color: 'bg-orange-600', category: 'tech' },
  { id: 'github', title: 'GitHub', url: 'https://github.com', icon: 'GH', color: 'bg-zinc-900', category: 'tech' },
  { id: 'hn', title: 'Hacker News', url: 'app:news', icon: 'Y', color: 'bg-orange-500', category: 'tech' },
  { id: 'discord', title: 'Discord Web', url: 'https://discord.com/app', icon: '💬', color: 'bg-indigo-600', category: 'tech' },
  { id: 'g1', title: 'G1 Notícias', url: 'https://g1.globo.com', icon: 'G1', color: 'bg-red-700', category: 'noticias' },
  { id: 'bbc', title: 'BBC Brasil', url: 'https://www.bbc.com/portuguese', icon: 'BBC', color: 'bg-red-800', category: 'noticias' },
  { id: 'osm', title: 'OpenStreetMap', url: 'app:maps', icon: 'M', color: 'bg-emerald-600', category: 'util' },
  { id: 'weather', title: 'Clima 7 Dias', url: 'app:weather', icon: '⛅', color: 'bg-sky-600', category: 'util' },
  { id: 'radio', title: 'Rádio Brasil', url: 'app:radio', icon: '📻', color: 'bg-orange-600', category: 'util' },
];

const LS_BOOKMARKS = 'blvr.browser.bookmarks.v2';
const LS_ENGINE = 'blvr.browser.engine.v1';

function loadBookmarks(): Bookmark[] {
  try {
    const s = localStorage.getItem(LS_BOOKMARKS);
    if (s) return JSON.parse(s);
  } catch { /* ignore */ }
  return DEFAULT_BOOKMARKS;
}

let tabCounter = 1;
function createTab(incognito = false, initialUrl = ''): Tab {
  const id = `tab-${tabCounter++}`;
  const isUrl = /^https?:\/\//i.test(initialUrl);
  const mode = isUrl ? 'web' : initialUrl ? 'search' : 'home';
  const defaultEngine = (localStorage.getItem(LS_ENGINE) as SearchEngine) || 'duckduckgo';
  return {
    id,
    title: incognito ? 'Guia Anônima' : (initialUrl || 'Nova Guia'),
    url: initialUrl,
    input: initialUrl,
    mode,
    incognito,
    loading: false,
    error: '',
    history: initialUrl ? [{ url: initialUrl, title: initialUrl, mode, time: Date.now() }] : [],
    histIdx: initialUrl ? 0 : -1,
    reader: null,
    results: [],
    zoom: 1,
    desktop: false,
    engine: defaultEngine,
  };
}

interface BrowserStore {
  tabs: Tab[];
  activeId: string;
  bookmarks: Bookmark[];
  globalHistory: HistoryItem[];
  defaultEngine: SearchEngine;
}

export const useBrowser = create<BrowserStore>(() => {
  const initialTab = createTab(false, '');
  return {
    tabs: [initialTab],
    activeId: initialTab.id,
    bookmarks: loadBookmarks(),
    globalHistory: [],
    defaultEngine: (localStorage.getItem(LS_ENGINE) as SearchEngine) || 'duckduckgo',
  };
});

const B = () => useBrowser.getState();
const setB = (p: Partial<BrowserStore> | ((prev: BrowserStore) => Partial<BrowserStore>)) => useBrowser.setState(p);

export function activeTab(): Tab {
  const st = B();
  return st.tabs.find((t) => t.id === st.activeId) || st.tabs[0];
}

function updateActive(p: Partial<Tab>) {
  setB((prev) => ({
    tabs: prev.tabs.map((t) => (t.id === prev.activeId ? { ...t, ...p } : t)),
  }));
}

/* ============================ Tab Management ============================ */
export function newTab(incognito = false, url = '') {
  const tab = createTab(incognito, url);
  setB((prev) => ({
    tabs: [...prev.tabs, tab],
    activeId: tab.id,
  }));
  if (url) browserNavigate(url);
}

export function closeTab(id: string) {
  const st = B();
  if (st.tabs.length <= 1) {
    // Keep at least one tab open
    const fresh = createTab(false, '');
    setB({ tabs: [fresh], activeId: fresh.id });
    return;
  }
  const idx = st.tabs.findIndex((t) => t.id === id);
  const nextTabs = st.tabs.filter((t) => t.id !== id);
  const nextActive = st.activeId === id
    ? (nextTabs[idx] ? nextTabs[idx].id : nextTabs[nextTabs.length - 1].id)
    : st.activeId;
  setB({ tabs: nextTabs, activeId: nextActive });
}

export function switchTab(id: string) {
  setB({ activeId: id });
}

export function toggleIncognito() {
  const tab = activeTab();
  if (tab.incognito) {
    // Switch to non-incognito or create one
    const normal = B().tabs.find((t) => !t.incognito);
    if (normal) switchTab(normal.id);
    else newTab(false, '');
  } else {
    newTab(true, '');
  }
}

/* ============================ Navigation Engine ============================ */
const stripTags = (s: string) => s.replace(/<[^>]+>/g, '').replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&#39;/g, "'");

export function browserNavigate(rawInput: string) {
  const q = rawInput.trim();
  if (!q) return;

  // Intercept app deep links
  if (q.startsWith('app:')) {
    openApp(q.slice(4) as AppId);
    return;
  }

  // Intercept YouTube links directly
  const yt = /youtu\.?be/i.test(q) ? parseYouTube(q) : null;
  if (yt) {
    ytOpen(yt);
    openApp('youtube');
    return;
  }
  if (/^(https?:\/\/)?(www\.|m\.)?youtube\.com\/?$/i.test(q) || q.toLowerCase() === 'youtube') {
    openApp('youtube');
    return;
  }

  // Intercept Native Wikipedia
  if (q === 'wiki:' || q.toLowerCase() === 'wikipedia' || q.toLowerCase() === 'wikipédia') {
    navToMode('home', '', 'Início BLVR');
    return;
  }

  const isUrl = /^https?:\/\//i.test(q) || (/^[\w-]+(\.[\w-]+)+(\/.*)?$/i.test(q) && !q.includes(' '));
  if (isUrl) {
    const finalUrl = /^https?:\/\//i.test(q) ? q : 'https://' + q;
    navToMode('web', finalUrl, finalUrl.replace(/^https?:\/\//, '').split('/')[0]);
  } else {
    searchWeb(q);
  }
}

function navToMode(mode: Tab['mode'], url: string, title?: string) {
  const tab = activeTab();
  const histItem: HistoryItem = { url, title: title || url, mode, time: Date.now() };

  // Only store global history if not incognito
  if (!tab.incognito && url) {
    setB((prev) => ({
      globalHistory: [histItem, ...prev.globalHistory.filter((h) => h.url !== url)].slice(0, 50),
    }));
  }

  const newHist = [...tab.history.slice(0, tab.histIdx + 1), histItem].slice(-30);
  updateActive({
    mode,
    url,
    input: url,
    title: title || (mode === 'home' ? (tab.incognito ? 'Guia Anônima' : 'Nova Guia') : url),
    history: newHist,
    histIdx: newHist.length - 1,
    loading: false,
    error: '',
    reader: null,
  });
}

export function browserBack() {
  const tab = activeTab();
  if (tab.histIdx <= 0) return;
  const prevIdx = tab.histIdx - 1;
  const item = tab.history[prevIdx];
  updateActive({
    mode: item.mode,
    url: item.url,
    input: item.url,
    title: item.title,
    histIdx: prevIdx,
    loading: false,
    error: '',
  });
}

export function browserForward() {
  const tab = activeTab();
  if (tab.histIdx >= tab.history.length - 1) return;
  const nextIdx = tab.histIdx + 1;
  const item = tab.history[nextIdx];
  updateActive({
    mode: item.mode,
    url: item.url,
    input: item.url,
    title: item.title,
    histIdx: nextIdx,
    loading: false,
    error: '',
  });
}

export function browserReload() {
  const tab = activeTab();
  if (tab.mode === 'web') {
    const cur = tab.url;
    updateActive({ url: '', loading: true });
    setTimeout(() => updateActive({ url: cur, loading: false }), 60);
  } else if (tab.mode === 'search') {
    searchWeb(tab.input);
  } else if (tab.mode === 'reader' && tab.url) {
    openReaderMode(tab.url);
  }
}

export function browserHome() {
  const tab = activeTab();
  navToMode('home', '', tab.incognito ? 'Guia Anônima' : 'Início');
}

/* ============================ Search Engine ============================ */
export function setEngine(engine: SearchEngine) {
  localStorage.setItem(LS_ENGINE, engine);
  setB({ defaultEngine: engine });
  updateActive({ engine });
}

async function searchWeb(q: string) {
  updateActive({
    mode: 'search',
    url: q,
    input: q,
    title: `Pesquisa: ${q}`,
    loading: true,
    error: '',
    results: [],
  });

  try {
    // Wikipedia search API (reliable, fast, no API key)
    const r = await fetch(`https://pt.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&format=json&origin=*&srlimit=15`);
    const j = await r.json();
    const results = (j.query?.search ?? []).map((x: { title: string; snippet: string }) => ({
      title: x.title,
      snippet: stripTags(x.snippet),
      url: `wiki:${x.title}`,
    }));
    updateActive({
      results,
      loading: false,
      error: results.length ? '' : 'Nenhum resultado direto encontrado. Use os links de busca acima.',
    });
  } catch {
    updateActive({
      loading: false,
      error: 'Sem conexão para busca direta. Use os motores de busca abaixo:',
    });
  }
}

/* ============================ Reader Mode (Article Extractor) ============================ */
export async function openReaderMode(titleOrUrl: string) {
  const isWiki = titleOrUrl.startsWith('wiki:') || !titleOrUrl.startsWith('http');
  const title = titleOrUrl.replace(/^wiki:/, '');
  updateActive({
    mode: 'reader',
    url: titleOrUrl,
    input: titleOrUrl,
    title: `Leitura: ${title}`,
    loading: true,
    error: '',
    reader: null,
  });

  if (isWiki) {
    try {
      const r = await fetch(`https://pt.wikipedia.org/w/api.php?action=query&prop=extracts|pageimages&titles=${encodeURIComponent(title)}&redirects=1&format=json&origin=*&piprop=thumbnail&pithumbsize=800`);
      const j = await r.json();
      const page = Object.values(j.query?.pages ?? {})[0] as { title: string; extract?: string; thumbnail?: { source: string } } | undefined;
      if (!page?.extract) throw new Error();
      updateActive({
        loading: false,
        reader: {
          title: page.title,
          html: page.extract,
          thumb: page.thumbnail?.source,
          byline: 'Wikipédia (CC BY-SA)',
        },
      });
    } catch {
      updateActive({ loading: false, error: 'Não foi possível carregar o artigo em Modo Leitura.' });
    }
  } else {
    // External URL Reader extractor fallback
    try {
      const res = await fetch(`https://api.allorigins.win/get?url=${encodeURIComponent(titleOrUrl)}`);
      const data = await res.json();
      const rawHtml = data.contents || '';
      // Parse basic body
      const doc = new DOMParser().parseFromString(rawHtml, 'text/html');
      const articleEl = doc.querySelector('article') || doc.querySelector('main') || doc.body;
      const cleanHtml = articleEl.innerHTML.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
      updateActive({
        loading: false,
        reader: {
          title: doc.title || titleOrUrl,
          html: cleanHtml || '<p>Conteúdo não pôde ser extraído no modo leitura.</p>',
          byline: new URL(titleOrUrl).hostname,
        },
      });
    } catch {
      updateActive({
        loading: false,
        error: 'Este site bloqueia o modo leitura. Visualize na visualização web ou abra no app externo.',
      });
    }
  }
}

/* ============================ Bookmarks ============================ */
export function addBookmark(title: string, url: string, category: Bookmark['category'] = 'frequentes') {
  const id = `bm-${Date.now()}`;
  const next = [...B().bookmarks.filter((b) => b.url !== url), { id, title: title || url, url, category }];
  localStorage.setItem(LS_BOOKMARKS, JSON.stringify(next));
  setB({ bookmarks: next });
  S().toast('Favorito adicionado!', 'ok');
}

export function removeBookmark(id: string) {
  const next = B().bookmarks.filter((b) => b.id !== id);
  localStorage.setItem(LS_BOOKMARKS, JSON.stringify(next));
  setB({ bookmarks: next });
  S().toast('Favorito removido', 'info');
}

export function setZoom(delta: number) {
  const tab = activeTab();
  const nextZoom = Math.max(0.6, Math.min(1.8, Math.round((tab.zoom + delta) * 10) / 10));
  updateActive({ zoom: nextZoom });
}

export function toggleDesktop() {
  const tab = activeTab();
  updateActive({ desktop: !tab.desktop });
}

/* ============================ Keyboard Integration ============================ */
export function browserKeyInput(k: string) {
  const tab = activeTab();
  if (k === '⌫') updateActive({ input: tab.input.slice(0, -1) });
  else if (k === '↵') {
    browserNavigate(tab.input);
    closeKb();
  } else if (k === 'clear') updateActive({ input: '' });
  else updateActive({ input: tab.input + k });
}

export function openBrowserKb() {
  openKb('browser');
}
void activeTab;

registerKb('browser', {
  key: browserKeyInput,
  open: () => S().kbTarget === 'browser',
  value: () => activeTab().input,
  label: 'Navegador Web',
  hint: 'Digite um termo de pesquisa, endereço web (.com) ou wiki:Artigo',
});
