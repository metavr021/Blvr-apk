/**
 * Installation as an app (PWA): registers the service worker and captures Chrome's install prompt.
 * Installed BLVR opens fullscreen from the home screen like a native app. The same build is what
 * PWABuilder (pwabuilder.com) packages into an Android APK.
 */
import { S } from './store';

interface BIPEvent extends Event { prompt: () => Promise<void>; userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }> }
let deferred: BIPEvent | null = null;

export const isInstalled = () =>
  window.matchMedia?.('(display-mode: fullscreen)').matches || window.matchMedia?.('(display-mode: standalone)').matches
  || (navigator as Navigator & { standalone?: boolean }).standalone === true;

export function initInstall() {
  if ('serviceWorker' in navigator && import.meta.env.PROD && window.isSecureContext) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js', { scope: './' }).catch(() => undefined);
    });
  }
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferred = e as BIPEvent;
    S().set({ canInstall: true });
  });
  window.addEventListener('appinstalled', () => {
    deferred = null;
    S().set({ canInstall: false });
    S().toast('BLVR instalado! Abra pelo ícone na tela inicial.', 'ok');
  });
}

export async function promptInstall(): Promise<boolean> {
  if (!deferred) {
    S().toast('Para instalar: menu ⋮ do Chrome → "Instalar app" / "Adicionar à tela inicial"', 'info');
    return false;
  }
  await deferred.prompt();
  const r = await deferred.userChoice;
  deferred = null;
  S().set({ canInstall: false });
  return r.outcome === 'accepted';
}
