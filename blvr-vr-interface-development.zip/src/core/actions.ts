import { S, saveInstalled, type AppId, type Section, type BrowserState } from './store';
import { pose, recalibrate } from './orientation';
import { sfx } from './sound';
import { clamp, wrap180 } from './math';
import { byId } from './catalog';
import { setAnchor, getAnchor, deleteAnchor, menuGeo, setMenuGeo, barGeo, setBarGeo } from './spatial';
import { APP_WIN } from './catalog';
import { parseYouTube, ytOpen, ytCmd, useApps, radioStop, ytHandover } from './apps';
import { resetHandEngine } from './hands';
import { enterMeta, closeMetaHub } from './meta';
import { registerKb, openKb, closeKb } from './keyboard';
import { lookStart as craftLookStart, lookMove as craftLookMove, newWorld as craftNewWorld } from './craft';

/* ---------------- Pure 3DoF mode (rotation sensors only, camera OFF) ----------------
 * 3DoF = gyroscope + accelerometer only. The camera is fully released (no passthrough, no hand
 * tracking, hand model unloaded from memory) → much lower battery use and no heating. Interaction
 * uses the gaze cursor (center of view) + tap / VR Box button / Bluetooth controller / dwell. */
export const is3dof = (s = S().settings) => !s.passthrough && !s.handTracking;

export function set3dof(on: boolean) {
  const st = S();
  const s = st.settings;
  if (on) {
    if (!is3dof(s)) st.setSetting('mixedPrefs', { passthrough: s.passthrough, handTracking: s.handTracking });
    st.setSetting('passthrough', false);
    st.setSetting('handTracking', false);
    st.setSetting('gazeCursor', true);
    resetHandEngine(); // frees the hand model (worker + WASM memory) – important on 2-4 GB phones
    if (st.started) st.toast('Modo 3DoF: só giroscópio + acelerômetro · câmera desligada', 'ok');
  } else {
    const p = s.mixedPrefs;
    const both = !p.passthrough && !p.handTracking; // never restore into "nothing on"
    st.setSetting('passthrough', both ? true : p.passthrough);
    st.setSetting('handTracking', both ? true : p.handTracking);
    if (st.started) st.toast('Câmera ligada: passthrough + hand tracking', 'info');
  }
}

/* ---------------- Display mode / vertical test mode ---------------- */
export async function applyOrientation(): Promise<boolean> {
  const want = S().settings.portrait ? 'portrait' : 'landscape';
  try {
    const so = screen.orientation as unknown as { lock?: (o: string) => Promise<void> };
    if (!so?.lock) return false;
    await so.lock(want);
    return true;
  } catch { return false; }
}

/** Vertical mode = single-screen test mode (VR Box needs landscape stereo). */
export function setPortrait(v: boolean) {
  S().setSetting('portrait', v);
  if (v && S().settings.displayMode === 'stereo') S().setSetting('displayMode', 'single');
  void applyOrientation().then((ok) => {
    if (!ok && S().started) S().toast(v ? 'Gire o celular para a vertical' : 'Gire o celular para a horizontal', 'info');
  });
}

export function setDisplayMode(m: 'single' | 'stereo') {
  S().setSetting('displayMode', m);
  if (m === 'stereo' && S().settings.portrait) setPortrait(false);
}

/* ---------------- Menu (world-anchored) ---------------- */
/** Captures the CURRENT head orientation and anchors the menu there (it does not follow the screen). */
export function openMenu(section?: Section) {
  const st = S();
  setAnchor('menu', { yaw: pose.yaw, pitch: clamp(pose.pitch, -20, 20) * 0.85, dist: 0, scale: 1 });
  st.set({ menuOpen: true, quickOpen: false, section: section ?? st.section, introDone: true });
  sfx.open();
}
export function closeMenu() {
  if (S().metaHubOpen && !S().menuOpen) { closeMetaHub(); return; } // opening an app from the metaverse hub
  if (!S().menuOpen) return;
  S().set({ menuOpen: false });
  sfx.close();
}
export function toggleMenu() { if (S().menuOpen) closeMenu(); else openMenu(); }

export function openSection(s: Section) {
  if (s === 'browser') { openApp('browser'); return; }
  if (!S().menuOpen) openMenu(s); else S().set({ section: s });
}

/* ---------------- Secondary system panel ---------------- */
export function openQuick() {
  setAnchor('quick', { yaw: pose.yaw, pitch: clamp(pose.pitch, -35, 20), dist: 1100, scale: 1 });
  S().set({ quickOpen: true, introDone: true });
  sfx.open();
}
export function closeQuick() { if (S().quickOpen) { S().set({ quickOpen: false }); sfx.close(); } }
export function toggleQuick() { if (S().quickOpen) closeQuick(); else openQuick(); }

/** Recalibrate: current direction becomes the center; open menu is re-centered in front. */
export function recenter() {
  recalibrate();
  if (S().reclined) S().set({ reclined: false }); // recalibrate also clears the lying-down offset
  if (S().menuOpen) setAnchor('menu', { yaw: 0 });
  if (S().quickOpen) setAnchor('quick', { yaw: 0 });
  S().toast('Visão recalibrada', 'ok');
}

/* ---------------- Windows ---------------- */
let winCounter = 1;
export const WIN_DIST = 1500;
export const WIN_SCALE = 1.25;
const WIN_DEFAULT = APP_WIN;

function gazeTarget() {
  const st = S();
  const m = getAnchor('menu');
  if (st.menuOpen && m) return { yaw: m.yaw, pitch: m.pitch };
  return { yaw: pose.yaw, pitch: clamp(pose.pitch, -15, 20) };
}

/* ---------------- Telão (YouTube big screen in the scene) ---------------- */
export const TELAO_W = 1280;
export const TELAO_H = 830; // 720 video + controls
export const TELAO_BASE = 2.44; // world scale at size 100% (≈55° wide at 3 m)

export function openTelao() {
  const st = S();
  const yaw = st.menuOpen ? (getAnchor('menu')?.yaw ?? pose.yaw) : pose.yaw;
  setAnchor('telao', { yaw, pitch: clamp(pose.pitch, -10, 20) + 4, dist: st.settings.telaoDist, scale: TELAO_BASE * st.settings.telaoScale, w: TELAO_W, h: TELAO_H });
  ytHandover(); // the video continues on the telão at the same second
  st.set({ telaoOpen: true });
  closeMenu();
  sfx.open();
}
export function closeTelao() {
  if (!S().telaoOpen) return;
  ytCmd('pauseVideo');
  ytHandover();
  useApps.setState({ yt: { ...useApps.getState().yt, playing: false } });
  S().set({ telaoOpen: false });
  sfx.close();
}
export const toggleTelao = () => (S().telaoOpen ? closeTelao() : openTelao());

export function openApp(app: AppId) {
  if (app === 'meta') { enterMeta(); return; }
  if (app === 'telao') { openTelao(); return; }
  if (app === 'balloons' || app === 'neonpop') { startGame(app); return; }
  const st = S();
  const g = gazeTarget();
  const ex = st.windows.find((w) => w.app === app);
  if (ex) {
    setAnchor(`win:${ex.id}`, { yaw: g.yaw, pitch: g.pitch });
    st.set({ windows: st.windows.map((w) => (w.id === ex.id ? { ...w, minimized: false } : w)) });
    focusWin(ex.id);
  } else {
    const d = WIN_DEFAULT[app];
    const id = `w${winCounter++}`;
    setAnchor(`win:${id}`, { yaw: g.yaw, pitch: g.pitch, dist: WIN_DIST, scale: WIN_SCALE, w: d.w, h: d.h + 44 });
    st.set({ windows: [...st.windows, { id, app, title: d.title, minimized: false }] });
    focusWin(id);
  }
  closeMenu();
  sfx.open();
}

/** Focused window comes slightly forward (proper depth ordering in 3D instead of z-index). */
export function focusWin(id: string) {
  const st = S();
  st.windows.forEach((w) => setAnchor(`win:${w.id}`, { dist: w.id === id ? WIN_DIST - 70 : WIN_DIST }));
  if (st.focused !== id) st.set({ focused: id });
}
export function closeWin(id: string) {
  // Closing the Rádio window stops the stream (the global <audio> would otherwise keep playing)
  if (S().windows.find((w) => w.id === id)?.app === 'radio') radioStop();
  S().set({ windows: S().windows.filter((w) => w.id !== id), focused: S().focused === id ? null : S().focused });
  setTimeout(() => deleteAnchor(`win:${id}`), 500);
  sfx.close();
}
export function minimizeWin(id: string) {
  // A minimized player kept decoding video invisibly (wasted CPU/GPU → stutter): pause it.
  const app = S().windows.find((w) => w.id === id)?.app;
  // (not when the video is on the telão – then the window is only the search/controller)
  if (app === 'youtube' && !S().telaoOpen) { ytCmd('pauseVideo'); useApps.setState({ yt: { ...useApps.getState().yt, playing: false } }); }
  if (app === 'cinema') S().set({ cinema: { ...S().cinema, playing: false } });
  S().set({ windows: S().windows.map((w) => (w.id === id ? { ...w, minimized: true } : w)) });
  sfx.close();
}
export function restoreWin(id: string) {
  setAnchor(`win:${id}`, { yaw: pose.yaw, pitch: clamp(pose.pitch, -15, 20) });
  S().set({ windows: S().windows.map((w) => (w.id === id ? { ...w, minimized: false } : w)) });
  focusWin(id);
  sfx.open();
}

/* ---------------- Drag (pinch + hold) – fully imperative, no React per frame ---------------- */
interface Ang { yaw: number; pitch: number }
export const dragState = { kind: '', id: '' };
let drag: { anchor: string; offYaw: number; offPitch: number; y0: number; p0: number; w0: number; h0: number; dist: number } | null = null;

let geoDrag: { kind: 'menuSize' | 'menuDepth' | 'barSize' | 'telaoSize' | 'telaoDepth'; y0: number; s0: number; d0: number; r0: number } | null = null;
const angFrom = (id: string, a: Ang) => {
  const m = getAnchor(id);
  return m ? Math.hypot(wrap180(a.yaw - m.yaw), a.pitch - m.pitch) : 0;
};
const angFromMenu = (a: Ang) => angFrom('menu', a);

export function dragStart(key: string, a: Ang): boolean {
  const [kind, id] = key.split(':');
  // BLVR Craft: pinch-drag on the game view = look around
  if (kind === 'craftLook') {
    craftLookStart(a);
    dragState.kind = kind; dragState.id = '';
    return true;
  }
  // Telão size (corner handles) / depth (slider)
  if (kind === 'telaoSize' || kind === 'telaoDepth') {
    const t = getAnchor('telao');
    if (!t) return false;
    geoDrag = { kind, y0: a.yaw, s0: t.scale / TELAO_BASE, d0: t.dist, r0: Math.max(3, angFrom('telao', a)) };
    dragState.kind = kind; dragState.id = '';
    sfx.grab();
    return true;
  }
  // Hotbar size (end handles): horizontal distance from the bar center, saved on release
  if (kind === 'barSize') {
    const b = getAnchor('bar');
    if (!b) return false;
    geoDrag = { kind, y0: a.yaw, s0: barGeo.scale, d0: 0, r0: Math.max(2, Math.abs(wrap180(a.yaw - b.yaw))) };
    dragState.kind = kind; dragState.id = '';
    sfx.grab();
    return true;
  }
  // Menu size (corner handle) / depth (slider): imperative CSS vars, saved on release
  if (kind === 'menuSize' || kind === 'menuDepth') {
    if (!getAnchor('menu')) return false;
    geoDrag = { kind, y0: a.yaw, s0: menuGeo.scale, d0: menuGeo.dist, r0: Math.max(3, angFromMenu(a)) };
    dragState.kind = kind; dragState.id = '';
    sfx.grab();
    return true;
  }
  const anchorId = kind === 'win' || kind === 'resize' ? `win:${id}` : kind;
  const an = getAnchor(anchorId);
  if (!an) return false;
  if (kind === 'win' || kind === 'resize') focusWin(id);
  drag = { anchor: anchorId, offYaw: wrap180(an.yaw - a.yaw), offPitch: an.pitch - a.pitch, y0: a.yaw, p0: a.pitch, w0: an.w ?? 0, h0: an.h ?? 0, dist: an.dist * (1 / an.scale) };
  dragState.kind = kind; dragState.id = id ?? '';
  sfx.grab();
  return true;
}
export function dragMove(a: Ang) {
  if (dragState.kind === 'craftLook') { craftLookMove(a); return; }
  if (geoDrag) {
    if (geoDrag.kind === 'telaoSize') {
      setAnchor('telao', { scale: TELAO_BASE * clamp(geoDrag.s0 * (angFrom('telao', a) / geoDrag.r0), 0.4, 2.5) });
    } else if (geoDrag.kind === 'telaoDepth') {
      // right = farther, left = closer (≈90 mm per degree)
      setAnchor('telao', { dist: clamp(geoDrag.d0 - wrap180(a.yaw - geoDrag.y0) * 90, 1500, 6000) });
    } else if (geoDrag.kind === 'barSize') {
      const b = getAnchor('bar');
      if (b) setBarGeo(clamp(geoDrag.s0 * (Math.abs(wrap180(a.yaw - b.yaw)) / geoDrag.r0), 0.6, 1.8));
    } else if (geoDrag.kind === 'menuSize') {
      // Distance of the hand from the menu center: farther = bigger (works from either corner)
      setMenuGeo({ scale: clamp(geoDrag.s0 * (angFromMenu(a) / geoDrag.r0), 0.55, 1.8) });
    } else {
      // Move right = farther, left = closer (≈45 mm per degree)
      setMenuGeo({ dist: clamp(geoDrag.d0 - wrap180(a.yaw - geoDrag.y0) * 45, 800, 2500) });
    }
    return;
  }
  if (!drag) return;
  if (dragState.kind === 'resize') {
    const k = Math.PI / 180;
    const dx = -(a.yaw - drag.y0) * k * drag.dist;
    const dy = -(a.pitch - drag.p0) * k * drag.dist;
    setAnchor(drag.anchor, { w: clamp(drag.w0 + dx * 2, 520, 1800), h: clamp(drag.h0 + dy * 2, 380, 1150) });
  } else {
    setAnchor(drag.anchor, { yaw: a.yaw + drag.offYaw, pitch: clamp(a.pitch + drag.offPitch, -55, 60) });
  }
}
export function dragEnd() {
  if (geoDrag) {
    const t = getAnchor('telao');
    if (geoDrag.kind === 'barSize') S().setSetting('barScale', Math.round(barGeo.scale * 100) / 100);
    else if (geoDrag.kind === 'telaoSize' || geoDrag.kind === 'telaoDepth') {
      if (t) {
        S().setSetting('telaoScale', Math.round((t.scale / TELAO_BASE) * 100) / 100);
        S().setSetting('telaoDist', Math.round(t.dist / 10) * 10);
      }
    } else {
      S().setSetting('menuScale', Math.round(menuGeo.scale * 100) / 100);
      S().setSetting('menuDistance', Math.round(menuGeo.dist / 10) * 10);
    }
    geoDrag = null;
    sfx.click();
  }
  if (drag) sfx.click();
  drag = null;
  dragState.kind = ''; dragState.id = '';
}

/* ---------------- Hold-to-confirm actions ---------------- */
export function holdAction(key: string) {
  const [kind, id] = key.split(':');
  const st = S();
  if (kind === 'install') {
    if (!st.installed.includes(id)) {
      const list = [...st.installed, id];
      saveInstalled(list);
      st.set({ installed: list });
      st.toast(`${byId(id)?.name ?? id} instalado`, 'ok');
    }
  } else if (kind === 'uninstall') {
    const list = st.installed.filter((x) => x !== id);
    saveInstalled(list);
    st.set({ installed: list });
    if (id === 'env-night' && st.settings.environment === 'night') st.setSetting('environment', 'sunset');
    if (id === 'env-void' && st.settings.environment === 'void') st.setSetting('environment', 'sunset');
    st.set({ windows: st.windows.filter((w) => w.app !== id) });
    st.toast(`${byId(id)?.name ?? id} removido`, 'info');
  } else if (kind === 'reset') {
    st.resetSettings();
    st.toast('Configurações restauradas', 'ok');
  } else if (kind === 'craftnew') {
    craftNewWorld();
  } else if (kind === 'clearnotes') {
    st.set({ notes: '' });
    st.toast('Notas apagadas', 'info');
  } else if (kind === 'closeall') {
    radioStop();
    st.windows.forEach((w) => deleteAnchor(`win:${w.id}`));
    st.set({ windows: [], focused: null });
    st.toast('Todas as janelas fechadas', 'info');
  }
}

/* ---------------- Browser ---------------- */
const setB = (p: Partial<BrowserState>) => S().set({ browser: { ...S().browser, ...p } });
type Entry = { mode: BrowserState['mode']; url: string };

function nav(e: Entry, push = true) {
  const b = S().browser;
  if (push) setB({ history: [...b.history, { mode: b.mode, url: b.url }].slice(-30) });
  if (e.mode === 'home') setB({ mode: 'home', url: '', input: '', keyboard: false, error: '' });
  else if (e.mode === 'web') setB({ mode: 'web', url: e.url, input: e.url, keyboard: false, error: '' });
  else if (e.mode === 'search') void wikiSearch(e.url);
  else if (e.mode === 'article') void wikiArticle(e.url);
}

export function browserGo(raw: string) {
  const q = raw.trim();
  if (!q) return;
  if (q === 'wiki:') { nav({ mode: 'home', url: '' }); return; }
  // Built-in app links + YouTube: youtube.com refuses to load inside frames, so links open the official player app
  if (q.startsWith('app:')) { openApp(q.slice(4) as AppId); return; }
  const yt = /youtu\.?be/i.test(q) ? parseYouTube(q) : null;
  if (yt) { ytOpen(yt); openApp('youtube'); setB({ input: '', keyboard: false }); return; }
  if (/^(https?:\/\/)?(www\.|m\.)?youtube\.com\/?$/i.test(q) || q.toLowerCase() === 'youtube') { openApp('youtube'); setB({ input: '', keyboard: false }); return; }
  const isUrl = /^https?:\/\//i.test(q) || (/^[\w-]+(\.[\w-]+)+(\/.*)?$/.test(q) && !q.includes(' '));
  if (isUrl) nav({ mode: 'web', url: /^https?:\/\//i.test(q) ? q : 'https://' + q });
  else nav({ mode: 'search', url: q });
}
export const browserOpenArticle = (title: string) => nav({ mode: 'article', url: title });
export const browserHome = () => nav({ mode: 'home', url: '' });
export function browserBack() {
  const h = S().browser.history;
  if (!h.length) return;
  const prev = h[h.length - 1];
  setB({ history: h.slice(0, -1) });
  nav(prev, false);
}
export function browserReload() {
  const b = S().browser;
  if (b.mode === 'web') { setB({ url: '' }); setTimeout(() => setB({ url: b.input }), 50); }
  else nav({ mode: b.mode, url: b.url }, false);
}
export function browserKeyboard(v?: boolean) {
  const nv = v ?? !S().browser.keyboard;
  setB({ keyboard: nv });
  if (nv) openKb('browser'); else if (S().kbTarget === 'browser') closeKb();
}
export function browserKey(k: string) {
  const b = S().browser;
  if (k === '⌫') setB({ input: b.input.slice(0, -1) });
  else if (k === '↵') browserGo(b.input);
  else if (k === 'clear') setB({ input: '' });
  else setB({ input: b.input + k });
}
registerKb('browser', { key: browserKey, open: () => S().browser.keyboard, value: () => S().browser.input, label: 'Navegador', hint: 'Enter = pesquisar ou abrir endereço' });
registerKb('notes', { key: (k) => noteKey(k), open: () => true, value: () => S().notes, label: 'Notas', hint: 'Enter = nova linha' });

const stripTags = (s: string) => s.replace(/<[^>]+>/g, '').replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&#39;/g, "'");

async function wikiSearch(q: string) {
  setB({ mode: 'search', url: q, input: q, keyboard: false, loading: true, error: '', results: [] });
  try {
    const r = await fetch(`https://pt.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&format=json&origin=*&srlimit=12`);
    const j = await r.json();
    const results = (j.query?.search ?? []).map((x: { title: string; snippet: string }) => ({ title: x.title, snippet: stripTags(x.snippet) }));
    setB({ results, loading: false, error: results.length ? '' : 'Nenhum resultado encontrado.' });
  } catch {
    setB({ loading: false, error: 'Sem conexão com a internet ou serviço indisponível.' });
  }
}

async function wikiArticle(title: string) {
  setB({ mode: 'article', url: title, input: title, keyboard: false, loading: true, error: '', article: null });
  try {
    const r = await fetch(`https://pt.wikipedia.org/w/api.php?action=query&prop=extracts|pageimages&titles=${encodeURIComponent(title)}&redirects=1&format=json&origin=*&piprop=thumbnail&pithumbsize=640`);
    const j = await r.json();
    const page = Object.values(j.query?.pages ?? {})[0] as { title: string; extract?: string; thumbnail?: { source: string } } | undefined;
    if (!page?.extract) throw new Error();
    setB({ loading: false, article: { title: page.title, html: page.extract, thumb: page.thumbnail?.source } });
  } catch {
    setB({ loading: false, error: 'Não foi possível carregar o artigo.' });
  }
}

/* ---------------- Notes ---------------- */
export function noteKey(k: string) {
  const n = S().notes;
  if (k === '⌫') S().set({ notes: n.slice(0, -1) });
  else if (k === '↵') S().set({ notes: n + '\n' });
  else if (k === 'clear') S().set({ notes: '' });
  else S().set({ notes: n + k });
}

/* ---------------- Game: Balões 360 / Neon Pop ---------------- */
let spawnAcc = 0;
let timeLeft = 0;
let tid = 1;
export function startGame(mode: 'balloons' | 'neonpop') {
  timeLeft = mode === 'neonpop' ? 45 : 60;
  spawnAcc = 0;
  S().set({ game: { ...S().game, active: true, mode, score: 0, timeLeft: Math.ceil(timeLeft), yaw: pose.yaw, targets: [], finished: false } });
  closeMenu();
  S().toast('Aponte e faça pinça (ou olhe e toque) para estourar!', 'info');
}
export function exitGame() { S().set({ game: { ...S().game, active: false, targets: [], finished: false } }); sfx.close(); }

export function gameTick(dt: number) {
  const g = S().game;
  if (!g.active || g.finished) return;
  const neon = g.mode === 'neonpop';
  timeLeft -= dt;
  spawnAcc += dt;
  let targets = g.targets;
  let changed = false;
  const interval = neon ? 0.6 : 0.95;
  if (spawnAcc > interval) {
    spawnAcc = 0;
    if (targets.filter((t) => !t.popped).length < (neon ? 9 : 7)) {
      targets = [...targets, {
        id: tid++, yaw: g.yaw + (Math.random() * 150 - 75), pitch: Math.random() * 45 - 12,
        hue: neon ? [300, 190, 260, 330][Math.floor(Math.random() * 4)] : Math.floor(Math.random() * 360),
        size: neon ? 90 + Math.random() * 40 : 130 + Math.random() * 50, popped: false,
      }];
      changed = true;
    }
  }
  const secs = Math.max(0, Math.ceil(timeLeft));
  if (timeLeft <= 0) {
    const best = { ...g.best, [g.mode]: Math.max(g.best[g.mode] ?? 0, g.score) };
    S().set({ game: { ...g, finished: true, timeLeft: 0, targets: [], best } });
    sfx.hold();
    return;
  }
  if (changed || secs !== g.timeLeft) S().set({ game: { ...S().game, targets, timeLeft: secs } });
}

export function popTarget(id: number) {
  const g = S().game;
  const t = g.targets.find((x) => x.id === id);
  if (!t || t.popped) return;
  sfx.pop();
  S().set({ game: { ...g, score: g.score + (g.mode === 'neonpop' ? 15 : 10), targets: g.targets.map((x) => (x.id === id ? { ...x, popped: true } : x)) } });
  setTimeout(() => {
    const gg = S().game;
    S().set({ game: { ...gg, targets: gg.targets.filter((x) => x.id !== id) } });
  }, 380);
}
