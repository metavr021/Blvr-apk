/**
 * Hand Tracking module (MediaPipe Hand Landmarker).
 *
 * Performance design (UI must never stutter because of hands):
 *  - Preferred path: camera track → MediaStreamTrackProcessor → ReadableStream transferred to a Web Worker.
 *    The worker reads VideoFrames directly; the UI thread does ZERO work per camera frame.
 *  - Fallback: downscaled ImageBitmap per frame (main thread only does the cheap bitmap request).
 *  - Last resort: main-thread detector, hard-capped at 12 FPS.
 *  - Delegate 'auto' = CPU on low-end phones (keeps the weak GPU free for the compositor), GPU otherwise.
 *  - Results land in pre-allocated mutable buffers; Zustand only receives rare, debounced status changes.
 *
 * Pointer stability: index fingertip → One Euro filter → "sticky" deadzone (absorbs micro-tremor,
 * follows real movement instantly) → pinch lock (while the fingers close, the dot holds still so the
 * pinch hits what you aimed at).
 */
import type { HandLandmarker } from '@mediapipe/tasks-vision';
import HandWorker from './handWorker?worker&inline';
import { OneEuro, clamp, DEG } from './math';
import { S, emptyHand, type HandSide } from './store';
import { camera, acquireCamera, releaseCamera } from './camera';
import { view } from './view';
import { perf, heuristicTier } from './perf';

const VERSION = '0.10.14';
const WASM_URL = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${VERSION}/wasm`;
const MODEL_URL = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';

export interface HandInfo {
  side: 'left' | 'right';
  raw: Float32Array; // 21 landmarks, normalized camera coords (mirrored for front cam)
  pts: Float32Array; // 21 landmarks in stage coords (aligned with the passthrough image)
  pinching: boolean;
  pinchVal: number;
  palmUp: boolean;
  pointing: boolean;
  /** stabilized index fingertip in stage coords – the cursor dot */
  ptr: { x: number; y: number };
  dir: number;
  poke: boolean;
  seen: number;
}

export const handFrame: { left: HandInfo | null; right: HandInfo | null; seq: number; interval: number } = { left: null, right: null, seq: 0, interval: 60 };

/** Follow speed presets: One Euro (cut, beta), sticky deadzone (fraction of screen), render resampling factor. */
export const FOLLOW: Record<string, { cut: number; beta: number; dz: number; interp: number }> = {
  slow: { cut: 0.5, beta: 0.8, dz: 0.007, interp: 1.6 },
  normal: { cut: 1.0, beta: 3, dz: 0.005, interp: 1.0 },
  fast: { cut: 1.6, beta: 6, dz: 0.0045, interp: 0.75 },
  instant: { cut: 2.5, beta: 12, dz: 0.004, interp: 0.5 },
};

interface SideState {
  info: HandInfo;
  pinching: boolean; palmUp: boolean; relCount: number;
  fx: OneEuro; fy: OneEuro;
  stick: { x: number; y: number; init: boolean };
  lastSeen: number; scales: number[]; scaleT: number[]; pokeCooldown: number;
}
const mkSide = (side: 'left' | 'right'): SideState => ({
  info: { side, raw: new Float32Array(42), pts: new Float32Array(42), pinching: false, pinchVal: 0, palmUp: false, pointing: false, ptr: { x: 0.5, y: 0.5 }, dir: 0, poke: false, seen: 0 },
  pinching: false, palmUp: false, relCount: 0,
  fx: new OneEuro(), fy: new OneEuro(),
  stick: { x: 0.5, y: 0.5, init: false },
  lastSeen: 0, scales: [], scaleT: [], pokeCooldown: 0,
});
const sides = { left: mkSide('left'), right: mkSide('right') };

/* ---------------- Engine ---------------- */
type Raw = { label: string; lm: Float32Array; world: Float32Array };
let active = false;
let ready = false;
let worker: Worker | null = null;
let mainLm: HandLandmarker | null = null;
let streaming = false;
let streamTrack: MediaStreamTrack | null = null;
let streamOf: MediaStream | null = null;
let busy = false;
let busySince = 0;
let lastSent = 0;
let lastTs = 0;
let rvfcHandle = 0;
let timer = 0;
let gen = 0;
let sentFps = 0;
let lastResultAt = 0;

const status = (handStatus: ReturnType<typeof S>['handStatus'], handMsg: string) => {
  const st = S();
  if (st.handStatus !== handStatus || st.handMsg !== handMsg) st.set({ handStatus, handMsg });
};

/** Hands tracked: 'auto' = 1 on modest phones (≈2× faster detection), 2 on strong phones. */
export function wantHands(): 1 | 2 {
  const h = S().settings.handsNum;
  if (h === '1') return 1;
  if (h === '2') return 2;
  return heuristicTier() >= 1 ? 1 : 2;
}
export function applyHandsNum() {
  const n = wantHands();
  worker?.postMessage({ type: 'hands', fps: n });
  mainLm?.setOptions({ numHands: n }).catch(() => undefined);
}

/** 'AUTO' = the worker benchmarks GPU and CPU on this phone and keeps the fastest. */
export function wantDelegate(): 'AUTO' | 'GPU' | 'CPU' {
  const d = S().settings.handDelegate;
  if (d === 'gpu') return 'GPU';
  if (d === 'cpu') return 'CPU';
  return 'AUTO';
}

/**
 * Detection rate. Zero-copy stream: detection is fully off the UI thread → run at max rate (30).
 * Bitmap fallback: capped by the perf tier. Main-thread fallback: 12.
 */
const targetFps = () => {
  const want = S().settings.handFps;
  if (!worker) return Math.min(want, 12);
  if (streaming) return Math.min(want, 30);
  return Math.min(want, perf.handCap);
};
void heuristicTier;

function initWorker(): Promise<string> {
  return new Promise((resolve, reject) => {
    let w: Worker;
    try { w = new HandWorker(); } catch (e) { reject(e); return; }
    const to = setTimeout(() => { w.terminate(); reject(new Error('timeout ao iniciar worker')); }, 45000);
    w.onmessage = (e) => {
      const m = e.data;
      if (m.type === 'ready') { clearTimeout(to); worker = w; w.onmessage = onWorkerMsg; resolve(`Worker · ${m.delegate}`); }
      else if (m.type === 'error') { clearTimeout(to); w.terminate(); reject(new Error(m.message)); }
    };
    w.onerror = (e) => { clearTimeout(to); w.terminate(); reject(new Error(e.message || 'erro no worker')); };
    w.postMessage({ type: 'init', wasm: WASM_URL, model: MODEL_URL, delegate: wantDelegate(), fps: wantHands() });
  });
}

async function initMain(): Promise<string> {
  const vision = await import('@mediapipe/tasks-vision');
  const fileset = await vision.FilesetResolver.forVisionTasks(WASM_URL);
  const make = (delegate: 'GPU' | 'CPU') => vision.HandLandmarker.createFromOptions(fileset, {
    baseOptions: { modelAssetPath: MODEL_URL, delegate }, runningMode: 'VIDEO', numHands: wantHands(),
    minHandDetectionConfidence: 0.55, minHandPresenceConfidence: 0.5, minTrackingConfidence: 0.5,
  });
  let d: 'GPU' | 'CPU' = wantDelegate() === 'CPU' ? 'CPU' : 'GPU';
  try { mainLm = await make(d); } catch { d = 'CPU'; mainLm = await make('CPU'); }
  return `Thread principal · ${d} (fallback, limitado a 12 FPS)`;
}

let engineBase = '';
function onWorkerMsg(e: MessageEvent) {
  const m = e.data;
  if (m.type === 'engine') {
    // Real cost per detected frame on this phone (shown in Configurações → Mãos and in the Metaverso hub)
    const txt = `${engineBase} · ${m.delegate} · ${m.ms} ms/quadro${m.testing ? ' (testando GPU×CPU…)' : ''}`;
    if (S().handEngine !== txt) S().set({ handEngine: txt });
    return;
  }
  if (m.type !== 'result') return;
  busy = false;
  if (active) ingest(m.hands as Raw[], performance.now());
}

/** Zero-copy camera → worker stream. Returns false if the browser can't do it (then we use bitmaps). */
function attachStream(): boolean {
  const MSTP = (window as unknown as { MediaStreamTrackProcessor?: new (o: { track: MediaStreamTrack; maxBufferSize?: number }) => { readable: ReadableStream } }).MediaStreamTrackProcessor;
  if (!worker || !MSTP || !camera.stream) return false;
  if (streaming && streamOf === camera.stream) return true;
  detachStream();
  try {
    const src = camera.stream.getVideoTracks()[0];
    if (!src) return false;
    const track = src.clone();
    const proc = new MSTP({ track, maxBufferSize: 1 });
    sentFps = targetFps();
    worker.postMessage({ type: 'stream', readable: proc.readable, fps: sentFps }, [proc.readable as unknown as Transferable]);
    streamTrack = track; streamOf = camera.stream; streaming = true;
    return true;
  } catch (err) {
    console.warn('[BLVR] stream para o worker indisponível, usando bitmaps:', err);
    detachStream();
    return false;
  }
}
function detachStream() {
  if (worker && streaming) worker.postMessage({ type: 'stop' });
  streamTrack?.stop();
  streamTrack = null; streamOf = null; streaming = false;
}
function onCameraChange() {
  if (!active || !ready) return;
  if (streaming && streamOf !== camera.stream) { detachStream(); if (!attachStream()) schedule(); }
}

export async function startHandTracking() {
  if (active) return;
  active = true;
  const my = ++gen;
  if (!window.isSecureContext) { active = false; status('unsupported', 'Indisponível: requer HTTPS'); return; }
  if (!navigator.mediaDevices?.getUserMedia) { active = false; status('unsupported', 'Indisponível: navegador sem câmera'); return; }
  if (typeof WebAssembly === 'undefined') { active = false; status('unsupported', 'Indisponível: sem WebAssembly'); return; }
  try {
    status('starting', 'Solicitando câmera…');
    await acquireCamera('hands');
    if (my !== gen) return;
    status('loading', 'Carregando modelo de mãos…');
    if (!ready) {
      let engine: string;
      const canWorker = typeof Worker !== 'undefined' && typeof OffscreenCanvas !== 'undefined';
      try {
        if (!canWorker) throw new Error('sem suporte a worker/OffscreenCanvas');
        engine = await initWorker();
      } catch (we) {
        console.warn('[BLVR] Worker de mãos indisponível, usando thread principal:', we);
        engine = await initMain();
      }
      ready = true;
      S().set({ handEngine: engine });
    }
    if (my !== gen || !active) return;
    camera.listeners.add(onCameraChange);
    const zeroCopy = attachStream();
    if (!zeroCopy) schedule();
    engineBase = worker ? (zeroCopy ? 'Worker · stream' : 'Worker · bitmap') : 'Thread principal';
    if (worker) S().set({ handEngine: `${engineBase} · iniciando…` });
    status('searching', 'Procurando mãos…');
    S().toast('Hand tracking ativo — mostre as mãos para a câmera', 'ok');
  } catch (e) {
    if (my !== gen) return;
    active = false;
    const msg = (e as Error)?.message || 'erro desconhecido';
    status('error', 'Falhou: ' + msg);
    S().toast('Hand tracking indisponível: ' + msg + '. Usando cursor por olhar.', 'warn');
    releaseCamera('hands');
  }
}

export function stopHandTracking() {
  active = false;
  gen++;
  cancelSchedule();
  detachStream();
  camera.listeners.delete(onCameraChange);
  handFrame.left = null; handFrame.right = null;
  sides.left = mkSide('left'); sides.right = mkSide('right');
  releaseCamera('hands');
  status('off', 'Desligado');
  S().set({ hands: { left: emptyHand, right: emptyHand } });
  lastKey = '';
}

/** Changing CPU/GPU needs a fresh model instance. */
export function resetHandEngine() {
  stopHandTracking();
  worker?.terminate();
  worker = null;
  mainLm?.close();
  mainLm = null;
  ready = false;
  S().set({ handEngine: '' });
}

export const isHandTrackingActive = () => active && ready;

/** Called from the render loop at most a few times per second: keeps the worker's rate in sync with the perf tier. */
export function syncHandRate() {
  if (!streaming || !worker) return;
  const f = targetFps();
  if (f !== sentFps) { sentFps = f; worker.postMessage({ type: 'fps', fps: f }); }
}

/* ---------------- Fallback scheduling (bitmap / main thread) ---------------- */
type RVFCVideo = HTMLVideoElement & { requestVideoFrameCallback?: (cb: () => void) => number; cancelVideoFrameCallback?: (h: number) => void };

function cancelSchedule() {
  const v = camera.video as RVFCVideo | null;
  if (rvfcHandle && v?.cancelVideoFrameCallback) v.cancelVideoFrameCallback(rvfcHandle);
  rvfcHandle = 0;
  clearTimeout(timer);
}

function schedule() {
  if (!active || streaming) return;
  const v = camera.video as RVFCVideo | null;
  if (v?.requestVideoFrameCallback && v.readyState >= 2) rvfcHandle = v.requestVideoFrameCallback(tick);
  else timer = window.setTimeout(tick, 40);
}

function tick() {
  rvfcHandle = 0;
  if (!active || streaming) return;
  const now = performance.now();
  const v = camera.video;
  if (busy && now - busySince > 2000) busy = false; // watchdog
  const interval = 1000 / clamp(targetFps(), 8, 30);
  if (!busy && v && v.readyState >= 2 && v.videoWidth && !document.hidden && now - lastSent >= interval - 6) {
    lastSent = now;
    const ts = Math.max(lastTs + 1, now);
    lastTs = ts;
    if (worker) {
      busy = true; busySince = now;
      const dw = Math.min(perf.detectW, v.videoWidth);
      const h = Math.round((dw * v.videoHeight) / v.videoWidth);
      createImageBitmap(v, { resizeWidth: dw, resizeHeight: h, resizeQuality: 'low' })
        .then((bitmap) => {
          if (!active || !worker) { bitmap.close(); busy = false; return; }
          worker.postMessage({ type: 'frame', bitmap }, [bitmap]);
        })
        .catch(() => { busy = false; });
    } else if (mainLm) {
      try {
        const r = mainLm.detectForVideo(v, ts);
        const hands: Raw[] = r.landmarks.map((pts, i) => {
          const lm = new Float32Array(63), world = new Float32Array(63);
          const wp = r.worldLandmarks?.[i];
          for (let k = 0; k < 21; k++) {
            lm[k * 3] = pts[k].x; lm[k * 3 + 1] = pts[k].y; lm[k * 3 + 2] = pts[k].z;
            if (wp) { world[k * 3] = wp[k].x; world[k * 3 + 1] = wp[k].y; world[k * 3 + 2] = wp[k].z; }
          }
          return { label: r.handedness?.[i]?.[0]?.categoryName ?? 'Right', lm, world };
        });
        ingest(hands, performance.now());
      } catch { /* skip frame */ }
    }
  }
  schedule();
}

/* ---------------- Analysis ---------------- */
const W = (w: Float32Array, i: number, j: number) => {
  const dx = w[i * 3] - w[j * 3], dy = w[i * 3 + 1] - w[j * 3 + 1], dz = w[i * 3 + 2] - w[j * 3 + 2];
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
};
const fallbackWorld = new Float32Array(63);

function analyze(r: Raw, trueRight: boolean, now: number) {
  const set = S().settings;
  const side = trueRight ? 'right' : 'left';
  const st = sides[side];
  const info = st.info;
  const front = camera.facing === 'user';
  const lm = r.lm;
  const vw = camera.video?.videoWidth || 4, vh = camera.video?.videoHeight || 3;
  const ar = vw / vh;
  const hasWorld = r.world[27] !== 0 || r.world[28] !== 0 || r.world[29] !== 0;
  let wl = r.world;
  if (!hasWorld) {
    for (let k = 0; k < 21; k++) { fallbackWorld[k * 3] = lm[k * 3] * ar; fallbackWorld[k * 3 + 1] = lm[k * 3 + 1]; fallbackWorld[k * 3 + 2] = lm[k * 3 + 2] * ar; }
    wl = fallbackWorld;
  }

  // Cover-mapping camera -> stage (same math as <video object-fit:cover> + ptZoom)
  const s = Math.max(view.w / vw, view.h / vh) * set.ptZoom;
  const sx = (vw * s) / view.w, sy = (vh * s) / view.h;
  const ox = (1 - sx) / 2, oy = (1 - sy) / 2;
  for (let k = 0; k < 21; k++) {
    const x = front ? 1 - lm[k * 3] : lm[k * 3];
    const y = lm[k * 3 + 1];
    info.raw[k * 2] = x; info.raw[k * 2 + 1] = y;
    info.pts[k * 2] = ox + x * sx; info.pts[k * 2 + 1] = oy + y * sy;
  }

  const hs = Math.max(1e-4, W(wl, 0, 9));
  // Pinch: average of the 3D ratio and the 2D image ratio (more reliable than either alone)
  const imgD = (i: number, j: number) => Math.hypot((lm[i * 3] - lm[j * 3]) * ar, lm[i * 3 + 1] - lm[j * 3 + 1]);
  const pd = 0.5 * (W(wl, 4, 8) / hs + imgD(4, 8) / Math.max(1e-4, imgD(0, 9)));
  if (st.pinching) {
    if (pd > 0.52) { if (++st.relCount >= 2) { st.pinching = false; st.relCount = 0; } } else st.relCount = 0;
  } else if (pd < 0.37) { st.pinching = true; st.relCount = 0; }
  const pinchVal = clamp(1 - (pd - 0.2) / 0.6, 0, 1);

  // Palm up (palm normal pointing up). Strict thresholds.
  const ax = wl[15] - wl[0], ay = wl[16] - wl[1], az = wl[17] - wl[2];
  const bx = wl[51] - wl[0], by = wl[52] - wl[1], bz = wl[53] - wl[2];
  const nx = ay * bz - az * by, nz = ax * by - ay * bx;
  let ny = az * bx - ax * bz;
  ny /= Math.hypot(nx, ny, nz) || 1;
  if (!trueRight) ny = -ny;
  if (st.palmUp) { if (-ny < 0.4) st.palmUp = false; } else if (-ny > 0.62) st.palmUp = true;

  const ext = (tip: number, pip: number) => W(wl, 0, tip) > W(wl, 0, pip) * 1.12;
  const curled = (tip: number, pip: number) => W(wl, 0, tip) < W(wl, 0, pip) * 1.05;
  const pointing = !st.pinching && ext(8, 6) && curled(12, 10) && curled(16, 14) && curled(20, 18);

  const R = info.raw;
  const dir = Math.atan2(R[18] - R[0], -(R[19] - R[1])) * DEG;

  // ---- Stable pointer = index fingertip (landmark 8) in stage coords ----
  const f = FOLLOW[set.handFollow] ?? FOLLOW.instant;
  st.fx.minCutoff = st.fy.minCutoff = f.cut;
  st.fx.beta = st.fy.beta = f.beta;
  const t = now / 1000;
  const gain = set.rayGain;
  const tx = 0.5 + (info.pts[16] - 0.5) * gain, ty = 0.5 + (info.pts[17] - 0.5) * gain;
  const fxv = st.fx.filter(tx, t), fyv = st.fy.filter(ty, t);
  // Sticky deadzone: output only moves by the excess beyond radius → tremor absorbed, movement instant.
  // Pinch lock: while the fingers are closing (not yet pinching) the radius grows so the dot holds still.
  // (small lock only right before the pinch closes – a big lock made the dot feel stuck/slow)
  const closing = !st.pinching && pinchVal > 0.68;
  const radius = closing ? 0.014 : st.pinching ? f.dz * 1.2 : f.dz;
  const sk = st.stick;
  if (!sk.init) { sk.x = fxv; sk.y = fyv; sk.init = true; }
  const dx = (fxv - sk.x) * view.w, dy = (fyv - sk.y) * view.h;
  const dist = Math.hypot(dx, dy);
  const rpx = radius * Math.min(view.w, view.h);
  if (dist > rpx) {
    const k = (dist - rpx) / dist;
    sk.x += (dx * k) / view.w; sk.y += (dy * k) / view.h;
  }
  info.ptr.x = sk.x; info.ptr.y = sk.y;

  // Poke (experimental): pointing hand moving toward the scene
  let poke = false;
  if (set.poke) {
    const imgSize = Math.hypot(R[18] - R[0], R[19] - R[1]);
    st.scales.push(imgSize); st.scaleT.push(now);
    while (st.scaleT.length && now - st.scaleT[0] > 260) { st.scaleT.shift(); st.scales.shift(); }
    if (pointing && now > st.pokeCooldown && st.scales.length > 3) {
      const old = st.scales[0];
      const rel = front ? (imgSize - old) / old : (old - imgSize) / old;
      if (rel > 0.13) { poke = true; st.pokeCooldown = now + 700; st.scales.length = 0; st.scaleT.length = 0; }
    }
  }

  info.pinching = st.pinching; info.pinchVal = pinchVal; info.palmUp = st.palmUp;
  info.pointing = pointing; info.dir = dir; info.poke = poke; info.seen = now;
  st.lastSeen = now;
  return info;
}

let lastSummary = 0;
let lastKey = '';
let lastAnyAt = 0;

function ingest(list: Raw[], now: number) {
  if (lastResultAt) handFrame.interval = handFrame.interval * 0.85 + Math.min(200, now - lastResultAt) * 0.15;
  lastResultAt = now;
  const swap = S().settings.swapHands;
  const front = camera.facing === 'user';
  const near = (r: Raw, s: 'left' | 'right') => {
    const st = sides[s];
    if (now - st.lastSeen > 350) return false;
    const x = front ? 1 - r.lm[0] : r.lm[0];
    return Math.hypot(x - st.info.raw[0], r.lm[1] - st.info.raw[1]) < 0.12;
  };
  let gotL = false, gotR = false;
  for (const r of list) {
    let right = (r.label === 'Left') !== swap; // MediaPipe labels assume a mirrored image
    if (list.length === 1) {
      if (!right && near(r, 'right') && !near(r, 'left')) right = true;
      else if (right && near(r, 'left') && !near(r, 'right')) right = false;
    }
    if ((right && gotR) || (!right && gotL)) right = !right;
    if ((right && gotR) || (!right && gotL)) continue;
    const info = analyze(r, right, now);
    if (right) { gotR = true; handFrame.right = info; } else { gotL = true; handFrame.left = info; }
  }
  if (!gotL && handFrame.left) { if (now - sides.left.lastSeen > 220) { handFrame.left = null; sides.left = mkSide('left'); } else handFrame.left.poke = false; }
  if (!gotR && handFrame.right) { if (now - sides.right.lastSeen > 220) { handFrame.right = null; sides.right = mkSide('right'); } else handFrame.right.poke = false; }
  handFrame.seq++;

  // ---- Rare, debounced UI status (never per frame) ----
  const any = !!(handFrame.left || handFrame.right);
  if (any) lastAnyAt = now;
  if (now - lastSummary < 400) return;
  lastSummary = now;
  const st = S();
  const tracking = any || now - lastAnyAt < 1200; // don't flip status when a hand blinks out briefly
  const parts = [handFrame.left && 'esquerda', handFrame.right && 'direita'].filter(Boolean).join(' + ');
  status(tracking ? 'tracking' : 'searching', tracking ? `Rastreando${parts ? ': ' + parts : ''}` : 'Procurando mãos…');
  // Detailed per-hand info is only needed by the Settings diagnostics panel
  if (!(st.menuOpen && st.section === 'settings')) return;
  const sum = (h: HandInfo | null): HandSide => h
    ? { present: true, pinch: Math.round(h.pinchVal * 5) / 5, pinching: h.pinching, palmUp: h.palmUp, pointing: h.pointing, dir: Math.round(h.dir / 15) * 15 }
    : emptyHand;
  const L = sum(handFrame.left), Rr = sum(handFrame.right);
  const key = `${+L.present}${L.pinch}${+L.pinching}${+L.palmUp}${+L.pointing}${L.dir}|${+Rr.present}${Rr.pinch}${+Rr.pinching}${+Rr.palmUp}${+Rr.pointing}${Rr.dir}`;
  if (key === lastKey) return;
  lastKey = key;
  st.set({ hands: { left: L, right: Rr } });
}
