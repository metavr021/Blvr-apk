/**
 * Phone apps in BLVR ("Meus apps do celular").
 *
 * HONEST LIMITS (Android/Chrome security, not a BLVR choice):
 *  - A website / web APK cannot read the list of installed apps → the user marks the apps he has.
 *  - A website / web APK cannot draw another Android app inside its own window. Only the OS of a headset
 *    (Horizon OS on the Quest) can do that. So:
 *      • apps that have a real BLVR version (YouTube, Spotify, Twitch, Maps, Waze, Lichess, Wikipédia, Chrome)
 *        open INSIDE BLVR in a window;
 *      • the others open the real app on the phone via Chrome "intent:" links (or its Play Store page).
 *
 * External apps can only be opened from a real user gesture (screen tap / BT controller key); a pinch is
 * not a gesture for the browser, so a pinch-launch stays PENDING until the next real tap.
 */
import { S, LS_MYAPPS, type AppId } from './store';
import { openApp, browserGo } from './actions';

export interface DroidApp {
  id: string; name: string; pkg: string; scheme?: string; https?: string; web?: string; color: string; letter: string; note?: string;
  inside?: AppId; url?: string; // opens inside BLVR (window) – url = optional page for the browser window
  alt?: AppId; // in-BLVR alternative (e.g. Minecraft → BLVR Craft)
  cat: 'jogos' | 'video' | 'musica' | 'social' | 'util';
}

export const DROID: DroidApp[] = [
  // jogos
  { id: 'minecraft', name: 'Minecraft', pkg: 'com.mojang.minecraftpe', scheme: 'minecraft', color: 'bg-[#5d8a3a]', letter: '⛏', alt: 'craft', cat: 'jogos' },
  { id: 'roblox', name: 'Roblox', pkg: 'com.roblox.client', scheme: 'roblox', color: 'bg-zinc-700', letter: 'R', cat: 'jogos' },
  { id: 'freefire', name: 'Free Fire', pkg: 'com.dts.freefireth', color: 'bg-orange-600', letter: 'FF', cat: 'jogos' },
  { id: 'freefiremax', name: 'Free Fire MAX', pkg: 'com.dts.freefiremax', color: 'bg-amber-700', letter: 'FM', cat: 'jogos' },
  { id: 'brawlstars', name: 'Brawl Stars', pkg: 'com.supercell.brawlstars', color: 'bg-yellow-500', letter: 'BS', cat: 'jogos' },
  { id: 'clashroyale', name: 'Clash Royale', pkg: 'com.supercell.clashroyale', color: 'bg-blue-700', letter: 'CR', cat: 'jogos' },
  { id: 'clashofclans', name: 'Clash of Clans', pkg: 'com.supercell.clashofclans', color: 'bg-yellow-700', letter: 'CC', cat: 'jogos' },
  { id: 'subway', name: 'Subway Surfers', pkg: 'com.kiloo.subwaysurf', color: 'bg-sky-500', letter: 'SS', cat: 'jogos' },
  { id: 'pubg', name: 'PUBG Mobile', pkg: 'com.tencent.ig', color: 'bg-amber-600', letter: 'PG', cat: 'jogos' },
  { id: 'amongus', name: 'Among Us', pkg: 'com.innersloth.spacemafia', color: 'bg-red-700', letter: 'AU', cat: 'jogos' },
  { id: 'stumble', name: 'Stumble Guys', pkg: 'com.kitkagames.fallbuddies', color: 'bg-fuchsia-600', letter: 'SG', cat: 'jogos' },
  { id: 'mcclassic', name: 'Minecraft Classic', pkg: '', web: 'https://classic.minecraft.net', color: 'bg-[#7a5a3a]', letter: 'MC', note: 'Oficial, no navegador (precisa de teclado)', alt: 'craft', cat: 'jogos' },
  // vídeo
  { id: 'youtube', name: 'YouTube', pkg: 'com.google.android.youtube', https: 'www.youtube.com', color: 'bg-red-600', letter: '▶', inside: 'youtube', cat: 'video' },
  { id: 'netflix', name: 'Netflix', pkg: 'com.netflix.mediaclient', https: 'www.netflix.com/browse', color: 'bg-black', letter: 'N', cat: 'video' },
  { id: 'primevideo', name: 'Prime Video', pkg: 'com.amazon.avod.thirdpartyclient', https: 'www.primevideo.com', color: 'bg-sky-700', letter: 'P', cat: 'video' },
  { id: 'disney', name: 'Disney+', pkg: 'com.disney.disneyplus', https: 'www.disneyplus.com', color: 'bg-indigo-800', letter: 'D+', cat: 'video' },
  { id: 'globoplay', name: 'Globoplay', pkg: 'com.globo.globotv', https: 'globoplay.globo.com', color: 'bg-rose-600', letter: 'G', cat: 'video' },
  { id: 'max', name: 'Max', pkg: 'com.wbd.stream', https: 'play.max.com', color: 'bg-blue-900', letter: 'M', cat: 'video' },
  { id: 'crunchyroll', name: 'Crunchyroll', pkg: 'com.crunchyroll.crunchyroid', https: 'www.crunchyroll.com', color: 'bg-orange-500', letter: 'CR', cat: 'video' },
  { id: 'twitch', name: 'Twitch', pkg: 'tv.twitch.android.app', scheme: 'twitch', color: 'bg-violet-600', letter: 'T', inside: 'twitch', cat: 'video' },
  { id: 'kwai', name: 'Kwai', pkg: 'com.kwai.video', color: 'bg-orange-600', letter: 'K', cat: 'video' },
  // música
  { id: 'spotify', name: 'Spotify', pkg: 'com.spotify.music', scheme: 'spotify', color: 'bg-green-600', letter: '♫', inside: 'spotify', cat: 'musica' },
  { id: 'deezer', name: 'Deezer', pkg: 'deezer.android.app', color: 'bg-purple-700', letter: 'Dz', cat: 'musica' },
  { id: 'radio', name: 'Rádios', pkg: '', color: 'bg-orange-500', letter: '📻', inside: 'radio', cat: 'musica' },
  // social
  { id: 'whatsapp', name: 'WhatsApp', pkg: 'com.whatsapp', scheme: 'whatsapp', color: 'bg-emerald-600', letter: 'W', cat: 'social' },
  { id: 'instagram', name: 'Instagram', pkg: 'com.instagram.android', https: 'www.instagram.com', color: 'bg-pink-600', letter: 'IG', cat: 'social' },
  { id: 'tiktok', name: 'TikTok', pkg: 'com.zhiliaoapp.musically', https: 'www.tiktok.com', color: 'bg-zinc-900', letter: '♪', cat: 'social' },
  { id: 'facebook', name: 'Facebook', pkg: 'com.facebook.katana', https: 'www.facebook.com', color: 'bg-blue-600', letter: 'f', cat: 'social' },
  { id: 'messenger', name: 'Messenger', pkg: 'com.facebook.orca', color: 'bg-indigo-500', letter: 'Ms', cat: 'social' },
  { id: 'telegram', name: 'Telegram', pkg: 'org.telegram.messenger', scheme: 'tg', color: 'bg-sky-500', letter: 'Tg', cat: 'social' },
  { id: 'discord', name: 'Discord', pkg: 'com.discord', https: 'discord.com/app', color: 'bg-indigo-500', letter: 'Dc', cat: 'social' },
  { id: 'x', name: 'X (Twitter)', pkg: 'com.twitter.android', https: 'x.com', color: 'bg-black', letter: '𝕏', cat: 'social' },
  { id: 'snapchat', name: 'Snapchat', pkg: 'com.snapchat.android', scheme: 'snapchat', color: 'bg-yellow-400', letter: 'S', cat: 'social' },
  { id: 'pinterest', name: 'Pinterest', pkg: 'com.pinterest', https: 'www.pinterest.com', color: 'bg-red-700', letter: 'P', cat: 'social' },
  // utilidades
  { id: 'gmaps', name: 'Google Maps', pkg: 'com.google.android.apps.maps', https: 'maps.google.com', color: 'bg-emerald-700', letter: '📍', inside: 'maps', cat: 'util' },
  { id: 'waze', name: 'Waze', pkg: 'com.waze', scheme: 'waze', color: 'bg-cyan-500', letter: 'Wz', inside: 'browser', url: 'https://embed.waze.com/iframe?zoom=12&lat=-23.55&lon=-46.63&ct=livemap', cat: 'util' },
  { id: 'chrome', name: 'Chrome', pkg: 'com.android.chrome', color: 'bg-white', letter: '🌐', inside: 'browser', cat: 'util' },
  { id: 'wikipedia', name: 'Wikipédia', pkg: 'org.wikipedia', color: 'bg-zinc-200', letter: 'W', inside: 'browser', url: 'wiki:', cat: 'util' },
  { id: 'lichess', name: 'Lichess', pkg: 'org.lichess.mobileapp', color: 'bg-stone-700', letter: '♞', inside: 'chess', cat: 'util' },
  { id: 'uber', name: 'Uber', pkg: 'com.ubercab', scheme: 'uber', color: 'bg-black', letter: 'U', cat: 'util' },
  { id: '99', name: '99', pkg: 'com.taxis99', color: 'bg-yellow-400', letter: '99', cat: 'util' },
  { id: 'ifood', name: 'iFood', pkg: 'br.com.brainweb.ifood', color: 'bg-red-600', letter: 'iF', cat: 'util' },
  { id: 'nubank', name: 'Nubank', pkg: 'com.nu.production', color: 'bg-purple-700', letter: 'Nu', cat: 'util' },
  { id: 'mercadolivre', name: 'Mercado Livre', pkg: 'com.mercadolibre', color: 'bg-yellow-300', letter: 'ML', cat: 'util' },
  { id: 'shopee', name: 'Shopee', pkg: 'com.shopee.br', color: 'bg-orange-600', letter: 'S', cat: 'util' },
  { id: 'gmail', name: 'Gmail', pkg: 'com.google.android.gm', https: 'mail.google.com', color: 'bg-red-500', letter: 'M', cat: 'util' },
  { id: 'duolingo', name: 'Duolingo', pkg: 'com.duolingo', color: 'bg-lime-500', letter: 'D', cat: 'util' },
  { id: 'capcut', name: 'CapCut', pkg: 'com.lemon.lvoverseas', color: 'bg-zinc-800', letter: 'CC', cat: 'util' },
  { id: 'playstore', name: 'Play Store', pkg: 'com.android.vending', https: 'play.google.com/store/apps', color: 'bg-teal-600', letter: '▷', cat: 'util' },
];

export const droid = (id: string) => DROID.find((d) => d.id === id);
export const opensInside = (a: DroidApp) => !!a.inside;

const isAndroid = () => /Android/i.test(navigator.userAgent);

function intentUrl(a: DroidApp): string {
  const fb = encodeURIComponent(`https://play.google.com/store/apps/details?id=${a.pkg}`);
  if (a.scheme) return `intent://open#Intent;scheme=${a.scheme};package=${a.pkg};S.browser_fallback_url=${fb};end`;
  if (a.https) return `intent://${a.https}#Intent;scheme=https;package=${a.pkg};S.browser_fallback_url=${fb};end`;
  // no public deep link: open its Play Store page (it has the "Abrir/Jogar" button when installed)
  return `intent://details?id=${a.pkg}#Intent;scheme=market;package=com.android.vending;S.browser_fallback_url=${fb};end`;
}

let pending: { a: DroidApp; at: number } | null = null;

function go(a: DroidApp) {
  if (a.web) {
    const w = window.open(a.web, '_blank', 'noopener');
    if (!w) S().toast('O navegador bloqueou a nova aba', 'warn');
    return;
  }
  S().toast(`Abrindo ${a.name} no celular (fora do BLVR)…`, 'info');
  location.href = intentUrl(a);
}

/** Opens the REAL Android app (outside BLVR). */
export function launchAndroid(id: string) {
  const a = droid(id);
  if (!a) return;
  if (!a.pkg && !a.web) return;
  if (!a.web && !isAndroid()) { S().toast(`${a.name}: disponível só no Android`, 'warn'); return; }
  const ua = (navigator as Navigator & { userActivation?: { isActive: boolean } }).userActivation;
  if (ua && !ua.isActive) {
    pending = { a, at: performance.now() };
    S().toast(`${a.name} abre fora do BLVR: toque na tela uma vez para confirmar`, 'info');
    return;
  }
  go(a);
}

/** Opens a "meu app": inside BLVR (window) when there is a BLVR version, otherwise the real phone app. */
export function openMyApp(id: string) {
  const a = droid(id);
  if (!a) return;
  if (a.inside) {
    openApp(a.inside);
    if (a.url) browserGo(a.url);
    return;
  }
  launchAndroid(id);
}

export function toggleMyApp(id: string) {
  const cur = S().myApps;
  const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
  localStorage.setItem(LS_MYAPPS, JSON.stringify(next));
  S().set({ myApps: next });
}

/** Called from the real pointerup handler (a user gesture): runs a launch requested by pinch. */
export function flushLaunch() {
  if (!pending) return;
  const p = pending;
  pending = null;
  if (performance.now() - p.at < 20000) go(p.a);
}
