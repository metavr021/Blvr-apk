/**
 * Overlays per eye.
 *  - Cursor = ONE dot (DOM element moved with transform → compositor only, no CSS transitions).
 *  - Canvas: neon hand outlines (Metaverso), menu-gesture ring, hold/dwell rings, optional debug skeleton.
 *    No animations, no ripples. The canvas is redrawn ONLY when something it shows changed
 *    (new hand detection, ring progress) – never every frame for nothing.
 *
 * Neon hand (like a neon-sign hand): the hand silhouette (finger capsules + palm polygon + wrist) is stroked
 * in 3 widening layers (glow → core) and then its interior is cut out with 'destination-out', leaving a
 * glowing outline. No shadowBlur (very slow on mobile GPUs) – the glow is just 2 wider translucent strokes.
 */
import { S } from './store';
import { handFrame, isHandTrackingActive, type HandInfo } from './hands';
import { eyes, view, type EyeReg } from './view';
import { perf } from './perf';
import { cursor, isHovering, cursorShift, type Gesture } from './input';

const BONES = [0, 1, 1, 2, 2, 3, 3, 4, 0, 5, 5, 6, 6, 7, 7, 8, 5, 9, 9, 10, 10, 11, 11, 12, 9, 13, 13, 14, 14, 15, 15, 16, 13, 17, 17, 18, 18, 19, 19, 20, 0, 17];
const FINGERS = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16], [17, 18, 19, 20]];
const PALM = [0, 1, 5, 9, 13, 17];
const TAU = Math.PI * 2;
const BLUE = '#60a5fa';

/* ---------- DOM cursor dot ---------- */
const dotState = new WeakMap<HTMLDivElement, { tr: string; mode: string; hover: string; pinch: string }>();

function updateDot(e: EyeReg) {
  const d = e.dot;
  let st = dotState.get(d);
  if (!st) { st = { tr: '', mode: '', hover: '', pinch: '' }; dotState.set(d, st); }
  const src = cursor.source;
  const mode = src === 'none' ? 'none' : src === 'hand' ? 'hand' : src === 'poke' ? 'poke' : 'gaze';
  if (mode !== st.mode) { d.dataset.mode = mode; st.mode = mode; }
  if (mode === 'none') return;
  const hand = mode === 'hand' || mode === 'poke';
  const base = hand && !isHovering() ? 0 : cursorShift();
  const sh = e.eye === 'L' ? base : e.eye === 'R' ? -base : 0;
  const x = cursor.x * view.w + sh, y = cursor.y * view.h;
  const tr = `translate3d(${x.toFixed(1)}px,${y.toFixed(1)}px,0)`;
  if (tr !== st.tr) { d.style.transform = tr; st.tr = tr; }
  const hover = isHovering() ? '1' : '0';
  if (hover !== st.hover) { d.dataset.hover = hover; st.hover = hover; }
  const pinch = cursor.pinchPt || cursor.pressing ? '1' : '0';
  if (pinch !== st.pinch) { d.dataset.pinch = pinch; st.pinch = pinch; }
}

/* ---------- Neon hand ---------- */
function drawNeonHand(ctx: CanvasRenderingContext2D, h: HandInfo, W: number, H: number, color: string, glow: boolean, wmul: number) {
  const P = h.pts;
  const x = (i: number) => P[i * 2] * W, y = (i: number) => P[i * 2 + 1] * H;
  const hs = Math.hypot((P[0] - P[18]) * W, (P[1] - P[19]) * H) || 1;
  const fw = Math.max(3, hs * 0.14 * wmul);
  const core = h.pinching ? '#ffffff' : color;

  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  // 1. Soft glowing outer stroke (cheap single pass)
  if (glow) {
    ctx.strokeStyle = color;
    ctx.lineWidth = fw + 6;
    ctx.globalAlpha = 0.28;
    ctx.beginPath();
    for (const f of FINGERS) {
      ctx.moveTo(x(f[0]), y(f[0]));
      ctx.lineTo(x(f[1]), y(f[1])); ctx.lineTo(x(f[2]), y(f[2])); ctx.lineTo(x(f[3]), y(f[3]));
    }
    ctx.moveTo(x(PALM[0]), y(PALM[0]));
    for (let k = 1; k < PALM.length; k++) ctx.lineTo(x(PALM[k]), y(PALM[k]));
    ctx.closePath();
    ctx.stroke();
  }

  // 2. Crisp bright neon core stroke
  ctx.globalAlpha = 1;
  ctx.strokeStyle = core;
  ctx.lineWidth = fw;
  ctx.beginPath();
  for (const f of FINGERS) {
    ctx.moveTo(x(f[0]), y(f[0]));
    ctx.lineTo(x(f[1]), y(f[1])); ctx.lineTo(x(f[2]), y(f[2])); ctx.lineTo(x(f[3]), y(f[3]));
  }
  ctx.moveTo(x(PALM[0]), y(PALM[0]));
  for (let k = 1; k < PALM.length; k++) ctx.lineTo(x(PALM[k]), y(PALM[k]));
  ctx.closePath();
  ctx.stroke();
}

/* ---------- Canvas ---------- */
function ring(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, p: number, color: string, w: number) {
  ctx.lineWidth = w;
  ctx.lineCap = 'round';
  ctx.strokeStyle = 'rgba(255,255,255,0.22)';
  ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke();
  if (p <= 0) return;
  ctx.strokeStyle = color;
  ctx.beginPath(); ctx.arc(x, y, r, -Math.PI / 2, -Math.PI / 2 + TAU * p); ctx.stroke();
}

function gestureRing(ctx: CanvasRenderingContext2D, g: Gesture, W: number, H: number, label: string) {
  const x = g.x * W, y = g.y * H - 46, c = '#38bdf8';
  ctx.fillStyle = 'rgba(10,15,30,0.7)';
  ctx.beginPath(); ctx.arc(x, y, 21, 0, TAU); ctx.fill();
  ring(ctx, x, y, 21, g.progress, c, 3.5);
  for (let i = 1; i <= 4; i++) { // 25/50/75/100 %
    const a = -Math.PI / 2 + (TAU * i) / 4;
    ctx.fillStyle = g.progress >= i / 4 ? c : 'rgba(255,255,255,0.35)';
    ctx.beginPath(); ctx.arc(x + Math.cos(a) * 21, y + Math.sin(a) * 21, 2.6, 0, TAU); ctx.fill();
  }
  ctx.fillStyle = '#e0f2fe';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = '600 9px system-ui, sans-serif';
  ctx.fillText(`${Math.round(g.progress * 100)}%`, x, y - 3);
  ctx.font = '500 7px system-ui, sans-serif';
  ctx.fillText(label, x, y + 7);
}

interface Need { neon: boolean; debug: boolean; gesture: boolean; holdP: number; dwell: number }

function drawCanvas(e: EyeReg, n: Need) {
  const c = e.canvas;
  const dpr = e.eye !== 'M' ? Math.min(perf.dpr, 1) : perf.dpr;
  const W = view.w, H = view.h;
  const cw = Math.round(W * dpr), ch = Math.round(H * dpr);
  if (c.width !== cw || c.height !== ch) { c.width = cw; c.height = ch; }
  const ctx = c.getContext('2d');
  if (!ctx) return;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, cw, ch);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const set = S().settings;

  if (n.neon) {
    for (const s of ['left', 'right'] as const) {
      const h = handFrame[s];
      if (h) drawNeonHand(ctx, h, W, H, set.handColor, set.handGlow && perf.tier < 2, set.handWidth);
    }
  }
  if (n.debug) {
    ctx.lineWidth = 1.2;
    ctx.strokeStyle = 'rgba(255,255,255,0.3)';
    ctx.beginPath();
    for (const s of ['left', 'right'] as const) {
      const h = handFrame[s];
      if (!h) continue;
      for (let i = 0; i < BONES.length; i += 2) {
        const a = BONES[i] * 2, b = BONES[i + 1] * 2;
        ctx.moveTo(h.pts[a] * W, h.pts[a + 1] * H);
        ctx.lineTo(h.pts[b] * W, h.pts[b + 1] * H);
      }
    }
    ctx.stroke();
  }
  if (n.gesture) gestureRing(ctx, cursor.menuG, W, H, S().meta ? 'MENU META' : 'MENU');
  const handLike = cursor.source === 'hand' || cursor.source === 'poke';
  const base = handLike && !isHovering() ? 0 : cursorShift();
  const sh = e.eye === 'L' ? base : e.eye === 'R' ? -base : 0;
  const cx = cursor.x * W + sh, cy = cursor.y * H;
  if (n.holdP > 0) ring(ctx, cx, cy, 16, n.holdP, BLUE, 3);
  if (n.dwell > 0.02) ring(ctx, cx, cy, 18, n.dwell, '#fbbf24', 3);
}

/* ---------- dirty check: redraw only when the picture would change ---------- */
const SIG = 10;
const sig = new Float64Array(SIG);
const prev = new Float64Array(SIG).fill(NaN);
let wasDrawn = false;

export function drawOverlays(_now: number) {
  const st = S();
  const set = st.settings;
  const hands = isHandTrackingActive() && !!(handFrame.left || handFrame.right);
  const n: Need = {
    neon: st.meta && hands,
    debug: hands && set.showHandSkeleton,
    gesture: !!cursor.menuG.side && cursor.menuG.progress > 0,
    holdP: cursor.holdProgress > 0.3 && !cursor.dragging ? (cursor.holdProgress - 0.3) / 0.7 : 0,
    dwell: cursor.dwellProgress,
  };
  eyes.forEach(updateDot);

  const need = n.neon || n.debug || n.gesture || n.holdP > 0 || n.dwell > 0.02;
  if (!need) {
    if (wasDrawn) {
      eyes.forEach((e) => { const ctx = e.canvas.getContext('2d'); ctx?.setTransform(1, 0, 0, 1, 0, 0); ctx?.clearRect(0, 0, e.canvas.width, e.canvas.height); });
      wasDrawn = false;
      prev.fill(NaN);
    }
    return;
  }
  const rings = n.holdP > 0 || n.dwell > 0.02;
  sig[0] = n.neon || n.debug ? handFrame.seq : -1;
  sig[1] = Math.round(cursor.menuG.progress * 60) + (n.gesture ? 1000 : 0);
  sig[2] = Math.round(n.holdP * 60);
  sig[3] = Math.round(n.dwell * 60);
  sig[4] = rings ? Math.round(cursor.x * view.w) : 0;
  sig[5] = rings ? Math.round(cursor.y * view.h) : 0;
  sig[6] = view.w * 10000 + view.h;
  sig[7] = perf.dpr;
  sig[8] = (n.neon ? 1 : 0) + (n.debug ? 2 : 0);
  sig[9] = set.handWidth * 100 + (set.handGlow ? 1 : 0) + set.handColor.length;
  let diff = false;
  for (let i = 0; i < SIG; i++) if (sig[i] !== prev[i]) { diff = true; prev[i] = sig[i]; }
  if (!diff) return;
  eyes.forEach((e) => drawCanvas(e, n));
  wasDrawn = true;
}
