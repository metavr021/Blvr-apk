/**
 * App data + services (shared by both stereo eyes – state must be global, never per component).
 *  - YouTube: official embed player controlled via its postMessage API (play/pause/seek/mute work by pinch).
 *  - Rádio: Radio Browser public API + ONE global <audio> (never duplicated per eye).
 *  - Clima: Open-Meteo (no key) + BigDataCloud reverse geocoding.
 *  - NASA: APOD API (DEMO_KEY, rate-limited by NASA – cached for the session).
 *  - Hacker News: official Firebase API.
 */
import { create } from 'zustand';
import { S } from './store';
import { registerKb, openKb, closeKb } from './keyboard';

/* ================= YouTube ================= */
export interface YtVideo { id: string; title: string; ch: string }
export const YT_CATS: { id: string; label: string; videos: YtVideo[] }[] = [
  {
    id: 'music', label: 'Música', videos: [
      { id: 'kJQP7kiw5Fk', title: 'Despacito ft. Daddy Yankee', ch: 'Luis Fonsi' },
      { id: 'JGwWNGJdvx8', title: 'Shape of You', ch: 'Ed Sheeran' },
      { id: 'fJ9rUzIMcZQ', title: 'Bohemian Rhapsody', ch: 'Queen' },
      { id: 'OPf0YbXqDm0', title: 'Uptown Funk ft. Bruno Mars', ch: 'Mark Ronson' },
      { id: 'hT_nvWreIhg', title: 'Counting Stars', ch: 'OneRepublic' },
      { id: 'RgKAFK5djSk', title: 'See You Again ft. Charlie Puth', ch: 'Wiz Khalifa' },
      { id: '9bZkp7q19f0', title: 'Gangnam Style', ch: 'PSY' },
      { id: 'L_jWHffIx5E', title: 'All Star', ch: 'Smash Mouth' },
      { id: 'dQw4w9WgXcQ', title: 'Never Gonna Give You Up', ch: 'Rick Astley' },
    ],
  },
  {
    id: 'live', label: 'Ao vivo', videos: [
      { id: 'jfKfPfyJRdk', title: 'lofi hip hop radio – beats to relax/study to', ch: 'Lofi Girl' },
      { id: '21X5lGlDOfg', title: 'NASA Live: Official Stream', ch: 'NASA' },
    ],
  },
  {
    id: 'films', label: 'Filmes abertos', videos: [
      { id: 'aqz-KE-bpKQ', title: 'Big Buck Bunny 60fps 4K', ch: 'Blender' },
      { id: 'eRsGyueVLvQ', title: 'Sintel – Open Movie', ch: 'Blender' },
      { id: 'R6MlUcmOul8', title: 'Tears of Steel', ch: 'Blender' },
    ],
  },
  {
    id: 'classic', label: 'Clássicos', videos: [
      { id: 'jNQXAC9IVRw', title: 'Me at the zoo (1º vídeo do YouTube)', ch: 'jawed' },
    ],
  },
];

/** Extracts a YouTube video id from any link format (watch, youtu.be, shorts, embed, live) or a bare id. */
export function parseYouTube(s: string): string | null {
  const t = s.trim();
  if (/^[\w-]{11}$/.test(t)) return t;
  const m = t.match(/(?:youtube\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/|live\/|v\/)|youtu\.be\/)([\w-]{11})/i);
  return m ? m[1] : null;
}

export const ytTime = { current: 0, duration: 0 }; // high-frequency: kept out of React
/** true once the official player inside the iframe has answered → videos can be switched without reloading it */
export const ytPlayer = { ready: false };

/* ---------- Free YouTube search ----------
 * YouTube offers no key-less search API, so search goes through public open-source YouTube front-ends
 * (Piped / Invidious), which query YouTube and return real results. Instances come and go, so we race
 * several, remember the one that worked, and auto-discover fresh instances if all fail. Playback always
 * uses the OFFICIAL YouTube embed player. */
export interface YtResult { id: string; title: string; ch: string; dur: number }
const PIPED = ['https://pipedapi.kavin.rocks', 'https://api.piped.private.coffee', 'https://pipedapi.leptons.xyz', 'https://pipedapi.adminforge.de',
  'https://pipedapi.reallyaweso.me', 'https://pipedapi.ducks.party', 'https://pipedapi.drgns.space', 'https://api.piped.yt', 'https://pipedapi.orangenet.cc'];
const INVID = ['https://inv.nadeko.net', 'https://invidious.nerdvpn.de', 'https://yewtu.be', 'https://invidious.privacyredirect.com',
  'https://iv.melmac.space', 'https://invidious.f5.si', 'https://inv.tux.pizza', 'https://invidious.jing.rocks'];
const LS_YT = 'blvr.yt.instance';

async function getJSON(url: string, ms = 6500): Promise<unknown> {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), ms);
  try {
    const r = await fetch(url, { signal: ac.signal });
    if (!r.ok) throw new Error(String(r.status));
    return await r.json();
  } finally { clearTimeout(t); }
}

type Src = { kind: 'piped' | 'invid'; base: string };
async function searchOn(s: Src, q: string): Promise<YtResult[]> {
  const enc = encodeURIComponent(q);
  if (s.kind === 'piped') {
    const j = await getJSON(`${s.base}/search?q=${enc}&filter=videos`) as { items?: { type?: string; url?: string; title?: string; uploaderName?: string; duration?: number }[] };
    const out = (j.items ?? []).filter((it) => (it.type ?? 'stream') === 'stream' && it.url).map((it) => ({
      id: (it.url!.match(/[?&]v=([\w-]{11})/) ?? [])[1] ?? '', title: it.title ?? '', ch: it.uploaderName ?? '', dur: it.duration ?? 0,
    })).filter((x) => x.id);
    if (!out.length) throw new Error('vazio');
    return out;
  }
  const j = await getJSON(`${s.base}/api/v1/search?q=${enc}&type=video`) as { type?: string; videoId?: string; title?: string; author?: string; lengthSeconds?: number }[];
  const out = (Array.isArray(j) ? j : []).filter((v) => v.videoId && (v.type ?? 'video') === 'video').map((v) => ({
    id: v.videoId!, title: v.title ?? '', ch: v.author ?? '', dur: v.lengthSeconds ?? 0,
  }));
  if (!out.length) throw new Error('vazio');
  return out;
}

/** First success wins (Promise.any equivalent – also works on older Android WebViews). */
function race(srcs: Src[], q: string): Promise<{ res: YtResult[]; src: Src }> {
  return new Promise((resolve, reject) => {
    let left = srcs.length;
    if (!left) { reject(new Error('sem servidores')); return; }
    srcs.forEach((s) => {
      searchOn(s, q).then((res) => resolve({ res, src: s }), () => { if (--left === 0) reject(new Error('todos falharam')); });
    });
  });
}

async function discover(): Promise<Src[]> {
  const out: Src[] = [];
  await Promise.allSettled([
    getJSON('https://piped-instances.kavin.rocks/', 6000).then((j) => {
      (Array.isArray(j) ? j : []).forEach((i: { api_url?: string }) => { if (i.api_url?.startsWith('https://')) out.push({ kind: 'piped', base: i.api_url.replace(/\/$/, '') }); });
    }),
    getJSON('https://api.invidious.io/instances.json?sort_by=health', 6000).then((j) => {
      (Array.isArray(j) ? j : []).forEach((e: [string, { api?: boolean; cors?: boolean; type?: string; uri?: string }]) => {
        const m = e?.[1];
        if (m?.api && m.cors && m.type === 'https' && m.uri) out.push({ kind: 'invid', base: m.uri.replace(/\/$/, '') });
      });
    }),
  ]);
  return out.slice(0, 20);
}

export async function ytSearch(q: string) {
  const query = q.trim();
  if (!query) return;
  setA('yt', { searching: true, searchError: '', query, results: [], keyboard: false, tab: 'search' });
  const statics: Src[] = [...PIPED.map((b) => ({ kind: 'piped' as const, base: b })), ...INVID.map((b) => ({ kind: 'invid' as const, base: b }))];
  let cached: Src | null = null;
  try { cached = JSON.parse(localStorage.getItem(LS_YT) || 'null'); } catch { /* ignore */ }
  const done = (r: { res: YtResult[]; src: Src }) => {
    localStorage.setItem(LS_YT, JSON.stringify(r.src));
    if (A().yt.query === query) setA('yt', { results: r.res.slice(0, 30), searching: false });
  };
  try {
    if (cached) { try { done({ res: await searchOn(cached, query), src: cached }); return; } catch { /* stale */ } }
    done(await race(statics, query));
  } catch {
    try {
      const found = await discover();
      if (!found.length) throw new Error();
      done(await race(found, query));
    } catch {
      if (A().yt.query === query) {
        setA('yt', { searching: false, searchError: 'Os servidores de busca estão fora do ar agora. Tente de novo em instantes, ou use “Colar link”.' });
      }
    }
  }
}

export function ytCmd(func: string, args: unknown[] = [], mainOnly = false) {
  const sel = mainOnly ? 'iframe[data-yt="main"]' : 'iframe[data-yt]';
  document.querySelectorAll<HTMLIFrameElement>(sel).forEach((f) => {
    f.contentWindow?.postMessage(JSON.stringify({ event: 'command', func, args }), '*');
  });
}
/** Ask the player to stream state updates (infoDelivery) to us. */
export function ytListen(f: HTMLIFrameElement) {
  f.contentWindow?.postMessage(JSON.stringify({ event: 'listening', id: 1, channel: 'widget' }), '*');
}

/* ================= Rádio ================= */
export interface Station { id: string; name: string; url: string; favicon: string; tags: string; country: string; codec: string; bitrate: number }
const RB_HOSTS = ['de1.api.radio-browser.info', 'fi1.api.radio-browser.info', 'at1.api.radio-browser.info'];
let audio: HTMLAudioElement | null = null;

/* ================= Clima ================= */
export interface Weather {
  place: string; lat: number; lon: number;
  current: { temp: number; feels: number; hum: number; wind: number; code: number };
  days: { date: string; max: number; min: number; code: number; rain: number }[];
}
export const CITIES = [
  { n: 'São Paulo', lat: -23.55, lon: -46.63 },
  { n: 'Rio de Janeiro', lat: -22.91, lon: -43.17 },
  { n: 'Brasília', lat: -15.79, lon: -47.88 },
  { n: 'Salvador', lat: -12.97, lon: -38.5 },
  { n: 'Manaus', lat: -3.12, lon: -60.02 },
  { n: 'Lisboa', lat: 38.72, lon: -9.14 },
];
export function wmo(code: number): [string, string] {
  if (code === 0) return ['☀️', 'Céu limpo'];
  if (code <= 2) return ['🌤️', 'Parcialmente nublado'];
  if (code === 3) return ['☁️', 'Nublado'];
  if (code <= 48) return ['🌫️', 'Neblina'];
  if (code <= 57) return ['🌦️', 'Garoa'];
  if (code <= 67) return ['🌧️', 'Chuva'];
  if (code <= 77) return ['🌨️', 'Neve'];
  if (code <= 82) return ['🌧️', 'Pancadas de chuva'];
  if (code <= 86) return ['🌨️', 'Pancadas de neve'];
  return ['⛈️', 'Tempestade'];
}

/* ================= NASA / News ================= */
export interface Apod { date: string; title: string; explanation: string; url: string; hdurl?: string; media_type: string; thumbnail_url?: string; copyright?: string }
export interface Story { id: number; title: string; url?: string; score: number; by: string; descendants?: number; time: number }

interface AppsState {
  yt: {
    id: string; srcId: string; startAt: number; title: string; cat: string; input: string; keyboard: boolean; playing: boolean; muted: boolean;
    tab: 'cats' | 'search'; query: string; results: YtResult[]; searching: boolean; searchError: string;
  };
  radio: { list: Station[]; scope: 'br' | 'world'; loading: boolean; error: string; current: Station | null; playing: boolean; buffering: boolean };
  weather: { data: Weather | null; loading: boolean; error: string; tab: 'forecast' | 'radar' };
  nasa: { list: Apod[]; sel: number; loading: boolean; error: string };
  news: { list: Story[]; loading: boolean; error: string };
  spotify: number;
  twitch: number;
  chess: 'tv' | 'puzzle';
}

export const useApps = create<AppsState>(() => ({
  yt: {
    id: YT_CATS[0].videos[0].id, srcId: YT_CATS[0].videos[0].id, startAt: 0, title: YT_CATS[0].videos[0].title, cat: 'music', input: '', keyboard: false, playing: false, muted: false,
    tab: 'cats', query: '', results: [], searching: false, searchError: '',
  },
  radio: { list: [], scope: 'br', loading: false, error: '', current: null, playing: false, buffering: false },
  weather: { data: null, loading: false, error: '', tab: 'forecast' },
  nasa: { list: [], sel: 0, loading: false, error: '' },
  news: { list: [], loading: false, error: '' },
  spotify: 0,
  twitch: 0,
  chess: 'tv',
}));
const A = () => useApps.getState();
const setA = <K extends keyof AppsState>(k: K, p: Partial<AppsState[K]>) =>
  useApps.setState({ [k]: { ...(A()[k] as object), ...p } } as Pick<AppsState, K>);

/* ---------- YouTube actions ---------- */
export function ytOpen(id: string, title = 'Vídeo do YouTube') {
  ytTime.current = 0; ytTime.duration = 0;
  const mounted = !!document.querySelector('iframe[data-yt]');
  if (mounted && ytPlayer.ready) {
    // Switch video INSIDE the running player (no iframe reload → no stutter)
    ytCmd('loadVideoById', [{ videoId: id, startSeconds: 0 }]);
    setA('yt', { id, title, playing: true, keyboard: false, input: '' });
  } else {
    ytPlayer.ready = false;
    setA('yt', { id, srcId: id, startAt: 0, title, playing: true, keyboard: false, input: '' });
  }
}

/** The player moves between the YouTube window and the telão: the new player resumes at the same second. */
export function ytHandover() {
  const y = A().yt;
  ytPlayer.ready = false;
  setA('yt', { srcId: y.id, startAt: Math.floor(ytTime.current), playing: true });
}
export const ytTab = (tab: 'cats' | 'search') => setA('yt', { tab });
export function ytToggle() {
  const p = A().yt.playing;
  ytCmd(p ? 'pauseVideo' : 'playVideo');
  setA('yt', { playing: !p });
}
export function ytSeek(delta: number) { ytCmd('seekTo', [Math.max(0, ytTime.current + delta), true]); }
export function ytMute() {
  const m = !A().yt.muted;
  ytCmd(m ? 'mute' : 'unMute', [], true);
  setA('yt', { muted: m });
}
export function ytKey(k: string): 'search' | null {
  const y = A().yt;
  if (k === '⌫') setA('yt', { input: y.input.slice(0, -1) });
  else if (k === 'clear') setA('yt', { input: '' });
  else if (k === '↵') {
    const id = parseYouTube(y.input);
    if (id) { ytOpen(id); return null; }
    if (y.input.trim()) { void ytSearch(y.input); return 'search'; }
    return null;
  } else setA('yt', { input: y.input + k });
  return null;
}
export const ytSetCat = (cat: string) => setA('yt', { cat });
export function ytKeyboard(v?: boolean) {
  const nv = v ?? !A().yt.keyboard;
  setA('yt', { keyboard: nv });
  if (nv) openKb('youtube'); else if (S().kbTarget === 'youtube') closeKb();
}
registerKb('youtube', {
  key: (k) => { ytKey(k); }, open: () => A().yt.keyboard, value: () => A().yt.input,
  label: 'YouTube', hint: 'Enter = pesquisar · cole/digite um link do YouTube para tocar direto',
});

// Player state updates from the official embed (infoDelivery / onStateChange)
window.addEventListener('message', (e) => {
  let host = '';
  try { host = new URL(e.origin).hostname; } catch { return; }
  if (!/(^|\.)youtube(-nocookie)?\.com$/.test(host)) return;
  ytPlayer.ready = true;
  let d: { event?: string; info?: { currentTime?: number; duration?: number; playerState?: number } | number } | null = null;
  try { d = typeof e.data === 'string' ? JSON.parse(e.data) : e.data; } catch { return; }
  if (!d) return;
  const info = typeof d.info === 'object' && d.info ? d.info : null;
  if (info) {
    if (typeof info.currentTime === 'number') ytTime.current = info.currentTime;
    if (typeof info.duration === 'number' && info.duration > 0) ytTime.duration = info.duration;
  }
  const state = d.event === 'onStateChange' && typeof d.info === 'number' ? d.info : info?.playerState;
  if (typeof state === 'number' && (state === 1 || state === 2 || state === 0)) {
    const playing = state === 1;
    if (A().yt.playing !== playing) setA('yt', { playing });
  }
});

/* ---------- Rádio actions ---------- */
export async function radioLoad(scope: 'br' | 'world' = A().radio.scope) {
  setA('radio', { scope, loading: true, error: '' });
  const q = scope === 'br'
    ? 'stations/search?countrycode=BR&order=clickcount&reverse=true&limit=60&hidebroken=true'
    : 'stations/search?order=clickcount&reverse=true&limit=60&hidebroken=true';
  for (const host of RB_HOSTS) {
    try {
      const r = await fetch(`https://${host}/json/${q}`);
      if (!r.ok) continue;
      const j = (await r.json()) as { stationuuid: string; name: string; url_resolved: string; favicon: string; tags: string; country: string; codec: string; bitrate: number }[];
      // https only: http streams are blocked as mixed content on https pages
      const list = j.filter((s) => s.url_resolved?.startsWith('https://')).slice(0, 40).map((s) => ({
        id: s.stationuuid, name: s.name.trim(), url: s.url_resolved, favicon: s.favicon?.startsWith('https://') ? s.favicon : '',
        tags: (s.tags || '').split(',').slice(0, 3).join(' · '), country: s.country, codec: s.codec, bitrate: s.bitrate,
      }));
      setA('radio', { list, loading: false, error: list.length ? '' : 'Nenhuma rádio compatível encontrada.' });
      return;
    } catch { /* try next mirror */ }
  }
  setA('radio', { loading: false, error: 'Sem conexão com o diretório de rádios.' });
}
export function radioPlay(s: Station) {
  if (!audio) {
    audio = new Audio();
    audio.preload = 'none';
    audio.addEventListener('playing', () => setA('radio', { playing: true, buffering: false }));
    audio.addEventListener('waiting', () => setA('radio', { buffering: true }));
    audio.addEventListener('pause', () => setA('radio', { playing: false, buffering: false }));
    audio.addEventListener('error', () => setA('radio', { playing: false, buffering: false, error: 'Esta rádio não pôde ser reproduzida. Tente outra.' }));
  }
  const cur = A().radio.current;
  if (cur?.id === s.id && !audio.paused) { audio.pause(); return; }
  if (cur?.id !== s.id) audio.src = s.url;
  setA('radio', { current: s, buffering: true, error: '' });
  audio.play().catch(() => setA('radio', { buffering: false, error: 'Toque na tela uma vez para liberar o áudio.' }));
}
export function radioStop() { audio?.pause(); }

/* ---------- Clima actions ---------- */
export async function weatherLoad(lat: number, lon: number, place?: string) {
  setA('weather', { loading: true, error: '' });
  try {
    const u = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=7`;
    const [r, name] = await Promise.all([
      fetch(u).then((x) => x.json()),
      place ? Promise.resolve(place) : fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lon}&localityLanguage=pt`)
        .then((x) => x.json()).then((g) => g.city || g.locality || g.principalSubdivision || 'Minha localização').catch(() => 'Minha localização'),
    ]);
    const c = r.current, d = r.daily;
    const data: Weather = {
      place: name, lat, lon,
      current: { temp: c.temperature_2m, feels: c.apparent_temperature, hum: c.relative_humidity_2m, wind: c.wind_speed_10m, code: c.weather_code },
      days: d.time.map((t: string, i: number) => ({ date: t, max: d.temperature_2m_max[i], min: d.temperature_2m_min[i], code: d.weather_code[i], rain: d.precipitation_probability_max?.[i] ?? 0 })),
    };
    setA('weather', { data, loading: false });
  } catch {
    setA('weather', { loading: false, error: 'Não foi possível obter a previsão (sem internet?).' });
  }
}
export function weatherHere() {
  if (!navigator.geolocation) { void weatherLoad(CITIES[0].lat, CITIES[0].lon, CITIES[0].n); return; }
  setA('weather', { loading: true });
  navigator.geolocation.getCurrentPosition(
    (p) => void weatherLoad(p.coords.latitude, p.coords.longitude),
    () => { setA('weather', { error: 'Localização negada — mostrando São Paulo.' }); void weatherLoad(CITIES[0].lat, CITIES[0].lon, CITIES[0].n); },
    { timeout: 8000, maximumAge: 600000 },
  );
}
export const weatherTab = (tab: 'forecast' | 'radar') => setA('weather', { tab });

/* ---------- NASA ---------- */
export async function nasaLoad() {
  if (A().nasa.list.length || A().nasa.loading) return;
  const cached = sessionStorage.getItem('blvr.apod');
  if (cached) { try { setA('nasa', { list: JSON.parse(cached) }); return; } catch { /* refetch */ } }
  setA('nasa', { loading: true, error: '' });
  try {
    const base = 'https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY&thumbs=true';
    const [today, more] = await Promise.all([
      fetch(base).then((r) => (r.ok ? r.json() : null)),
      fetch(`${base}&count=11`).then((r) => (r.ok ? r.json() : [])),
    ]);
    const list = [today, ...(Array.isArray(more) ? more : [])].filter((x): x is Apod => !!x && !!x.url);
    if (!list.length) throw new Error();
    sessionStorage.setItem('blvr.apod', JSON.stringify(list));
    setA('nasa', { list, loading: false });
  } catch {
    // The public DEMO_KEY is often rate-limited → fall back to the NASA Image Library (no key needed)
    try {
      const j = await fetch('https://images-api.nasa.gov/search?q=nebula%20galaxy%20hubble&media_type=image&page_size=30').then((r) => r.json()) as {
        collection: { items: { data: { title: string; description?: string; date_created?: string }[]; links?: { href: string }[] }[] };
      };
      const list: Apod[] = j.collection.items.filter((i) => i.links?.[0]?.href).slice(0, 14).map((i) => ({
        date: (i.data[0].date_created || '').slice(0, 10), title: i.data[0].title, explanation: i.data[0].description || '',
        url: i.links![0].href, media_type: 'image',
      }));
      if (!list.length) throw new Error();
      setA('nasa', { list, loading: false, error: '' });
    } catch {
      setA('nasa', { loading: false, error: 'Os serviços da NASA não responderam (sem internet?). Tente mais tarde.' });
    }
  }
}
export const nasaSel = (sel: number) => setA('nasa', { sel });

/* ---------- Hacker News ---------- */
export async function newsLoad(force = false) {
  if ((A().news.list.length && !force) || A().news.loading) return;
  setA('news', { loading: true, error: '' });
  try {
    const ids: number[] = await fetch('https://hacker-news.firebaseio.com/v0/topstories.json').then((r) => r.json());
    const items = await Promise.all(ids.slice(0, 30).map((id) => fetch(`https://hacker-news.firebaseio.com/v0/item/${id}.json`).then((r) => r.json()).catch(() => null)));
    setA('news', { list: items.filter((x): x is Story => !!x && !!x.title), loading: false });
  } catch {
    setA('news', { loading: false, error: 'Sem conexão com o Hacker News.' });
  }
}

export const setSpotify = (i: number) => useApps.setState({ spotify: i });
export const setTwitch = (i: number) => useApps.setState({ twitch: i });
export const setChess = (c: 'tv' | 'puzzle') => useApps.setState({ chess: c });
