/**
 * BLVR Craft – an original voxel sandbox game that runs INSIDE a BLVR window (raw WebGL, no libraries).
 *  - 64×64×32 world in 16×16 chunks, procedural terrain (hills, beaches, water, snow, trees), saved locally.
 *  - Walk (gravity + step-up) or fly; break / place 11 block types at the crosshair.
 *  - Render ON DEMAND only (nothing is drawn while you just look at the window) → light on low-end phones.
 *  - Stereo: only ONE WebGL renderer exists; the other eye's canvas copies the image after each render.
 * (The official Minecraft is an Android app and cannot be embedded in a web window.)
 */
import { create } from 'zustand';
import { S } from './store';

export const W = 64, D = 64, H = 32, NCX = W / 16, NCZ = D / 16;
export const EYE = 1.6;
const SEA = 11;
export const AIR = 0, GRASS = 1, DIRT = 2, STONE = 3, SAND = 4, LOG = 5, LEAVES = 6, PLANKS = 7, BRICK = 8, GLASS = 9, WATER = 10, SNOW = 11, COBBLE = 12, BEDROCK = 13;
export const PALETTE = [GRASS, DIRT, STONE, COBBLE, SAND, LOG, PLANKS, LEAVES, BRICK, GLASS, SNOW];
export const NAMES: Record<number, string> = {
  [GRASS]: 'Grama', [DIRT]: 'Terra', [STONE]: 'Pedra', [COBBLE]: 'Pedregulho', [SAND]: 'Areia', [LOG]: 'Tronco',
  [PLANKS]: 'Tábuas', [LEAVES]: 'Folhas', [BRICK]: 'Tijolos', [GLASS]: 'Vidro', [SNOW]: 'Neve',
};
type RGB = [number, number, number];
const COL: Record<number, [RGB, RGB, RGB]> = { // top, side, bottom
  [GRASS]: [[0.36, 0.66, 0.26], [0.47, 0.42, 0.25], [0.48, 0.34, 0.22]],
  [DIRT]: [[0.50, 0.36, 0.23], [0.50, 0.36, 0.23], [0.46, 0.33, 0.21]],
  [STONE]: [[0.54, 0.54, 0.56], [0.50, 0.50, 0.52], [0.46, 0.46, 0.48]],
  [COBBLE]: [[0.44, 0.44, 0.46], [0.42, 0.42, 0.44], [0.40, 0.40, 0.42]],
  [SAND]: [[0.88, 0.82, 0.58], [0.85, 0.79, 0.55], [0.80, 0.74, 0.50]],
  [LOG]: [[0.70, 0.56, 0.35], [0.42, 0.30, 0.17], [0.70, 0.56, 0.35]],
  [PLANKS]: [[0.76, 0.60, 0.37], [0.72, 0.56, 0.34], [0.68, 0.52, 0.31]],
  [LEAVES]: [[0.22, 0.52, 0.18], [0.20, 0.48, 0.17], [0.18, 0.44, 0.15]],
  [BRICK]: [[0.66, 0.30, 0.24], [0.62, 0.28, 0.22], [0.58, 0.26, 0.20]],
  [GLASS]: [[0.75, 0.90, 0.96], [0.70, 0.86, 0.93], [0.66, 0.82, 0.90]],
  [WATER]: [[0.22, 0.45, 0.82], [0.20, 0.42, 0.78], [0.18, 0.38, 0.72]],
  [SNOW]: [[0.96, 0.97, 1.0], [0.86, 0.88, 0.92], [0.80, 0.82, 0.86]],
  [BEDROCK]: [[0.18, 0.18, 0.2], [0.18, 0.18, 0.2], [0.18, 0.18, 0.2]],
};
export const swatch = (b: number, face = 0) => `rgb(${COL[b][face].map((v) => Math.round(v * 255)).join(',')})`;

/* ============================ World ============================ */
export const world = new Uint8Array(W * D * H);
const I = (x: number, y: number, z: number) => (y * D + z) * W + x;
export function get(x: number, y: number, z: number) {
  if (y < 0) return BEDROCK;
  if (x < 0 || z < 0 || x >= W || z >= D || y >= H) return AIR;
  return world[I(x, y, z)];
}
const solid = (b: number) => b !== AIR && b !== WATER;
export const dirty = new Set<number>();
const allDirty = () => { for (let i = 0; i < NCX * NCZ; i++) dirty.add(i); };
function markChunk(x: number, z: number) {
  const cx = x >> 4, cz = z >> 4;
  dirty.add(cz * NCX + cx);
  if ((x & 15) === 0 && cx > 0) dirty.add(cz * NCX + cx - 1);
  if ((x & 15) === 15 && cx < NCX - 1) dirty.add(cz * NCX + cx + 1);
  if ((z & 15) === 0 && cz > 0) dirty.add((cz - 1) * NCX + cx);
  if ((z & 15) === 15 && cz < NCZ - 1) dirty.add((cz + 1) * NCX + cx);
}
function setBlock(x: number, y: number, z: number, b: number) { world[I(x, y, z)] = b; markChunk(x, z); scheduleSave(); }

function hash(x: number, z: number, s: number) {
  let h = (Math.imul(x, 374761393) + Math.imul(z, 668265263) + Math.imul(s, 1442695041)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}
function noise(x: number, z: number, scale: number, s: number) {
  const fx = x / scale, fz = z / scale;
  const x0 = Math.floor(fx), z0 = Math.floor(fz);
  const tx = fx - x0, tz = fz - z0;
  const sx = tx * tx * (3 - 2 * tx), sz = tz * tz * (3 - 2 * tz);
  const a = hash(x0, z0, s), b = hash(x0 + 1, z0, s), c = hash(x0, z0 + 1, s), d = hash(x0 + 1, z0 + 1, s);
  return (a + (b - a) * sx) + ((c + (d - c) * sx) - (a + (b - a) * sx)) * sz;
}

let seed = 1;
function generate(s: number) {
  seed = s;
  world.fill(0);
  for (let x = 0; x < W; x++) for (let z = 0; z < D; z++) {
    const h = Math.max(2, Math.min(H - 8, Math.floor(7 + noise(x, z, 18, s) * 10 + noise(x, z, 6, s + 7) * 4)));
    for (let y = 0; y <= h; y++) {
      let b = STONE;
      if (y === 0) b = BEDROCK;
      else if (y === h) b = h <= SEA + 1 ? SAND : h >= 19 ? SNOW : GRASS;
      else if (y > h - 3) b = h <= SEA + 1 ? SAND : DIRT;
      world[I(x, y, z)] = b;
    }
    for (let y = h + 1; y <= SEA; y++) world[I(x, y, z)] = WATER;
  }
  // trees
  for (let x = 3; x < W - 3; x++) for (let z = 3; z < D - 3; z++) {
    if (hash(x, z, s + 99) > 0.018) continue;
    let top = H - 1;
    while (top > 0 && world[I(x, top, z)] === AIR) top--;
    if (world[I(x, top, z)] !== GRASS || top > H - 9) continue;
    const th = 4 + Math.floor(hash(x, z, s + 5) * 2);
    for (let y = top + 1; y <= top + th; y++) world[I(x, y, z)] = LOG;
    for (let dy = th - 2; dy <= th + 1; dy++) {
      const r = dy > th - 1 ? 1 : 2;
      for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) {
        if (Math.abs(dx) === r && Math.abs(dz) === r && r === 2) continue;
        const yy = top + dy;
        if (world[I(x + dx, yy, z + dz)] === AIR) world[I(x + dx, yy, z + dz)] = LEAVES;
      }
    }
  }
  allDirty();
}

/* ============================ Player ============================ */
export const cam = { x: W / 2 + 0.5, y: 20, z: D / 2 + 0.5, yaw: 0, pitch: -0.25, fly: false };
const clampXZ = (v: number, max: number) => Math.max(0.3, Math.min(max - 0.3, v));
const free = (x: number, feet: number, z: number) =>
  !solid(get(Math.floor(x), Math.floor(feet), Math.floor(z))) && !solid(get(Math.floor(x), Math.floor(feet) + 1, Math.floor(z)));

function settle(feet: number) {
  let f = Math.floor(feet);
  const fx = Math.floor(cam.x), fz = Math.floor(cam.z);
  while (f < H - 2 && (solid(get(fx, f, fz)) || solid(get(fx, f + 1, fz)))) f++; // stuck inside → push up
  while (f > 1 && !solid(get(fx, f - 1, fz))) f--; // gravity
  return f;
}
function spawn() {
  cam.x = W / 2 + 0.5; cam.z = D / 2 + 0.5; cam.fly = false;
  cam.y = settle(H - 2) + EYE;
}
export function fwd(): [number, number, number] {
  const cp = Math.cos(cam.pitch);
  return [-Math.sin(cam.yaw) * cp, Math.sin(cam.pitch), -Math.cos(cam.yaw) * cp];
}

export function move(f: number, s: number, up: number) {
  let feet = cam.y - EYE;
  const sy = Math.sin(cam.yaw), cy = Math.cos(cam.yaw);
  const dx = -sy * f + cy * s, dz = -cy * f - sy * s;
  const N = 4;
  for (let i = 0; i < N; i++) {
    const tx = clampXZ(cam.x + dx / N, W), tz = clampXZ(cam.z + dz / N, D);
    if (free(tx, feet, tz)) { cam.x = tx; cam.z = tz; }
    else if (!cam.fly && free(tx, feet + 1, tz) && free(cam.x, feet + 1, cam.z)) { feet = Math.floor(feet) + 1; cam.x = tx; cam.z = tz; }
    else break;
  }
  if (cam.fly && up) {
    const t = feet + up;
    if (t >= 1 && t < H - 1 && free(cam.x, t, cam.z)) feet = t;
  }
  if (!cam.fly) feet = settle(feet);
  cam.y = feet + EYE;
  hud();
  request();
}
export function toggleFly() {
  cam.fly = !cam.fly;
  if (!cam.fly) cam.y = settle(cam.y - EYE) + EYE;
  useCraft.setState({ fly: cam.fly });
  request();
}

const RAD = Math.PI / 180;
export function turn(deg: number) { cam.yaw += deg * RAD; request(); }
export function tilt(deg: number) { cam.pitch = Math.max(-1.5, Math.min(1.5, cam.pitch + deg * RAD)); request(); }
let look0 = { yaw: 0, pitch: 0, ay: 0, ap: 0 };
export function lookStart(a: { yaw: number; pitch: number }) { look0 = { yaw: cam.yaw, pitch: cam.pitch, ay: a.yaw, ap: a.pitch }; }
export function lookMove(a: { yaw: number; pitch: number }) {
  cam.yaw = look0.yaw + (a.yaw - look0.ay) * RAD * 3;
  cam.pitch = Math.max(-1.5, Math.min(1.5, look0.pitch + (a.pitch - look0.ap) * RAD * 3));
  request();
}

/* ============================ Interaction ============================ */
interface Hit { x: number; y: number; z: number; px: number; py: number; pz: number }
export function raycast(max = 7): Hit | null {
  const [dx, dy, dz] = fwd();
  let x = Math.floor(cam.x), y = Math.floor(cam.y), z = Math.floor(cam.z);
  const sx = Math.sign(dx), sy = Math.sign(dy), sz = Math.sign(dz);
  const tdx = dx ? Math.abs(1 / dx) : Infinity, tdy = dy ? Math.abs(1 / dy) : Infinity, tdz = dz ? Math.abs(1 / dz) : Infinity;
  let tmx = dx > 0 ? (x + 1 - cam.x) / dx : dx < 0 ? (cam.x - x) / -dx : Infinity;
  let tmy = dy > 0 ? (y + 1 - cam.y) / dy : dy < 0 ? (cam.y - y) / -dy : Infinity;
  let tmz = dz > 0 ? (z + 1 - cam.z) / dz : dz < 0 ? (cam.z - z) / -dz : Infinity;
  let px = x, py = y, pz = z, t = 0;
  while (t <= max) {
    if (solid(get(x, y, z))) return { x, y, z, px, py, pz };
    px = x; py = y; pz = z;
    if (tmx < tmy && tmx < tmz) { x += sx; t = tmx; tmx += tdx; }
    else if (tmy < tmz) { y += sy; t = tmy; tmy += tdy; }
    else { z += sz; t = tmz; tmz += tdz; }
  }
  return null;
}
export function breakBlock() {
  const h = raycast();
  if (!h || h.y < 1 || h.y >= H || h.x < 0 || h.z < 0 || h.x >= W || h.z >= D) return;
  setBlock(h.x, h.y, h.z, AIR);
  if (!cam.fly) cam.y = settle(cam.y - EYE) + EYE;
  request();
}
export function placeBlock() {
  const h = raycast();
  if (!h) return;
  const { px, py, pz } = h;
  if (px < 0 || pz < 0 || px >= W || pz >= D || py < 1 || py >= H) return;
  const feet = Math.floor(cam.y - EYE);
  if (Math.floor(cam.x) === px && Math.floor(cam.z) === pz && (py === feet || py === feet + 1)) return; // not inside yourself
  const cur = get(px, py, pz);
  if (cur !== AIR && cur !== WATER) return;
  setBlock(px, py, pz, useCraft.getState().sel);
  request();
}
export function act() { if (useCraft.getState().mode === 'break') breakBlock(); else placeBlock(); }

export function newWorld() {
  generate(Math.floor(Math.random() * 1e6));
  spawn();
  save();
  hud();
  request();
  S().toast('Novo mundo gerado', 'ok');
}

/** Keyboard (physical/Bluetooth) – returns true when consumed. */
export function craftKey(k: string): boolean {
  const key = k.length === 1 ? k.toLowerCase() : k;
  if (key === 'w') move(1, 0, 0);
  else if (key === 's') move(-1, 0, 0);
  else if (key === 'a') move(0, -1, 0);
  else if (key === 'd') move(0, 1, 0);
  else if (key === ' ') { if (cam.fly) move(0, 0, 1); else move(1, 0, 0); }
  else if (key === 'Shift') move(0, 0, -1);
  else if (key === 'ArrowLeft') turn(15);
  else if (key === 'ArrowRight') turn(-15);
  else if (key === 'ArrowUp') tilt(10);
  else if (key === 'ArrowDown') tilt(-10);
  else if (key === 'q') breakBlock();
  else if (key === 'e' || key === 'Enter') placeBlock();
  else if (key === 'f') toggleFly();
  else if (/^[1-9]$/.test(key)) useCraft.setState({ sel: PALETTE[Number(key) - 1] });
  else return false;
  return true;
}

/* ============================ UI state / save ============================ */
export const useCraft = create(() => ({ sel: GRASS as number, mode: 'place' as 'place' | 'break', fly: false, err: '', hud: '' }));
function hud() { useCraft.setState({ hud: `X ${Math.floor(cam.x)}  Y ${Math.floor(cam.y - EYE)}  Z ${Math.floor(cam.z)}` }); }

const LS = 'blvr.craft.v1';
let saveT = 0;
function scheduleSave() { clearTimeout(saveT); saveT = window.setTimeout(save, 1500); }
function save() {
  try {
    let bin = '';
    for (let i = 0; i < world.length; i += 8192) bin += String.fromCharCode.apply(null, world.subarray(i, i + 8192) as unknown as number[]);
    localStorage.setItem(LS, JSON.stringify({ seed, w: btoa(bin), cam: { x: cam.x, y: cam.y, z: cam.z, yaw: cam.yaw, pitch: cam.pitch, fly: cam.fly } }));
  } catch { /* storage full → world just isn't saved */ }
}
function load(): boolean {
  try {
    const j = JSON.parse(localStorage.getItem(LS) || 'null') as { seed: number; w: string; cam: typeof cam } | null;
    if (!j?.w) return false;
    const bin = atob(j.w);
    if (bin.length !== world.length) return false;
    for (let i = 0; i < bin.length; i++) world[i] = bin.charCodeAt(i);
    seed = j.seed;
    Object.assign(cam, j.cam);
    useCraft.setState({ fly: cam.fly });
    allDirty();
    return true;
  } catch { return false; }
}
let ready = false;
export function ensureWorld() {
  if (ready) return;
  ready = true;
  if (!load()) { generate(Math.floor(Math.random() * 1e6)); spawn(); }
  hud();
}

/* ============================ Renderer (raw WebGL) ============================ */
const DIRS = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
const QUADS = [
  [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]],
  [[0, 0, 1], [0, 1, 1], [0, 1, 0], [0, 0, 0]],
  [[0, 1, 0], [0, 1, 1], [1, 1, 1], [1, 1, 0]],
  [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]],
  [[1, 0, 1], [1, 1, 1], [0, 1, 1], [0, 0, 1]],
  [[0, 0, 0], [0, 1, 0], [1, 1, 0], [1, 0, 0]],
];
const TRI = [0, 1, 2, 0, 2, 3];
const SHADE = [0.8, 0.8, 1.0, 0.55, 0.68, 0.68];
function showFace(b: number, n: number) {
  if (n === AIR) return true;
  if (b === WATER) return false;
  if (n === WATER) return true;
  if (n === GLASS || n === LEAVES) return b !== n;
  return false;
}
function meshChunk(cx: number, cz: number): Float32Array {
  const out: number[] = [];
  for (let y = 0; y < H; y++) for (let z = cz * 16; z < cz * 16 + 16; z++) for (let x = cx * 16; x < cx * 16 + 16; x++) {
    const b = world[I(x, y, z)];
    if (!b) continue;
    for (let f = 0; f < 6; f++) {
      const d = DIRS[f];
      if (!showFace(b, get(x + d[0], y + d[1], z + d[2]))) continue;
      const col = COL[b][f === 2 ? 0 : f === 3 ? 2 : 1];
      const sh = SHADE[f] * (0.9 + hash(x, y * 7 + z * 13, b) * 0.2);
      const r = col[0] * sh, g = col[1] * sh, bl = col[2] * sh;
      const q = QUADS[f];
      const drop = b === WATER && f === 2 ? -0.12 : 0;
      for (const k of TRI) {
        const c = q[k];
        out.push(x + c[0], y + c[1] + (c[1] === 1 ? drop : 0), z + c[2], r, g, bl);
      }
    }
  }
  return new Float32Array(out);
}

function perspective(fovy: number, aspect: number, n: number, f: number) {
  const t = 1 / Math.tan(fovy / 2);
  return new Float32Array([t / aspect, 0, 0, 0, 0, t, 0, 0, 0, 0, (f + n) / (n - f), -1, 0, 0, (2 * f * n) / (n - f), 0]);
}
function lookAt(e: number[], c: number[], u: number[]) {
  let zx = e[0] - c[0], zy = e[1] - c[1], zz = e[2] - c[2];
  let l = Math.hypot(zx, zy, zz) || 1; zx /= l; zy /= l; zz /= l;
  let xx = u[1] * zz - u[2] * zy, xy = u[2] * zx - u[0] * zz, xz = u[0] * zy - u[1] * zx;
  l = Math.hypot(xx, xy, xz) || 1; xx /= l; xy /= l; xz /= l;
  const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
  return new Float32Array([xx, yx, zx, 0, xy, yy, zy, 0, xz, yz, zz, 0,
    -(xx * e[0] + xy * e[1] + xz * e[2]), -(yx * e[0] + yy * e[1] + yz * e[2]), -(zx * e[0] + zy * e[1] + zz * e[2]), 1]);
}
function mul(a: Float32Array, b: Float32Array) {
  const o = new Float32Array(16);
  for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
    let s = 0;
    for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k];
    o[c * 4 + r] = s;
  }
  return o;
}

const VS = 'attribute vec3 aP;attribute vec3 aC;uniform mat4 uM;uniform vec3 uE;varying vec3 vC;varying float vD;void main(){vC=aC;vD=distance(aP,uE);gl_Position=uM*vec4(aP,1.0);}';
const FS = 'precision mediump float;varying vec3 vC;varying float vD;uniform vec3 uS;uniform vec2 uF;void main(){float f=clamp((vD-uF.x)/(uF.y-uF.x),0.0,1.0);gl_FragColor=vec4(mix(vC,uS,f),1.0);}';
const SKY: RGB = [0.53, 0.75, 0.95];

export class CraftRenderer {
  gl: WebGLRenderingContext;
  canvas: HTMLCanvasElement;
  private prog: WebGLProgram;
  private aP: number; private aC: number;
  private uM: WebGLUniformLocation | null; private uE: WebGLUniformLocation | null;
  private uS: WebGLUniformLocation | null; private uF: WebGLUniformLocation | null;
  private chunks = new Map<number, { buf: WebGLBuffer | null; n: number }>();

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const gl = canvas.getContext('webgl', { antialias: false, alpha: false, depth: true, powerPreference: 'low-power' }) as WebGLRenderingContext | null;
    if (!gl) throw new Error('WebGL indisponível neste aparelho');
    this.gl = gl;
    const sh = (type: number, src: string) => {
      const s = gl.createShader(type)!;
      gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('shader: ' + gl.getShaderInfoLog(s));
      return s;
    };
    const p = gl.createProgram()!;
    gl.attachShader(p, sh(gl.VERTEX_SHADER, VS));
    gl.attachShader(p, sh(gl.FRAGMENT_SHADER, FS));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('program: ' + gl.getProgramInfoLog(p));
    this.prog = p;
    this.aP = gl.getAttribLocation(p, 'aP'); this.aC = gl.getAttribLocation(p, 'aC');
    this.uM = gl.getUniformLocation(p, 'uM'); this.uE = gl.getUniformLocation(p, 'uE');
    this.uS = gl.getUniformLocation(p, 'uS'); this.uF = gl.getUniformLocation(p, 'uF');
    for (let i = 0; i < NCX * NCZ; i++) this.build(i);
    dirty.clear();
  }

  private build(ci: number) {
    const gl = this.gl;
    const data = meshChunk(ci % NCX, Math.floor(ci / NCX));
    let e = this.chunks.get(ci);
    if (!e) { e = { buf: gl.createBuffer(), n: 0 }; this.chunks.set(ci, e); }
    gl.bindBuffer(gl.ARRAY_BUFFER, e.buf);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
    e.n = data.length / 6;
  }

  render() {
    const gl = this.gl;
    dirty.forEach((ci) => this.build(ci));
    dirty.clear();
    const w = this.canvas.width, h = this.canvas.height;
    gl.viewport(0, 0, w, h);
    gl.clearColor(SKY[0], SKY[1], SKY[2], 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.DEPTH_TEST);
    gl.useProgram(this.prog);
    const f = fwd();
    const eye = [cam.x, cam.y, cam.z];
    const m = mul(perspective(1.15, w / h, 0.08, 120), lookAt(eye, [eye[0] + f[0], eye[1] + f[1], eye[2] + f[2]], [0, 1, 0]));
    gl.uniformMatrix4fv(this.uM, false, m);
    gl.uniform3f(this.uE, eye[0], eye[1], eye[2]);
    gl.uniform3f(this.uS, SKY[0], SKY[1], SKY[2]);
    gl.uniform2f(this.uF, 26, 54);
    gl.enableVertexAttribArray(this.aP);
    gl.enableVertexAttribArray(this.aC);
    this.chunks.forEach((e) => {
      if (!e.n) return;
      gl.bindBuffer(gl.ARRAY_BUFFER, e.buf);
      gl.vertexAttribPointer(this.aP, 3, gl.FLOAT, false, 24, 0);
      gl.vertexAttribPointer(this.aC, 3, gl.FLOAT, false, 24, 12);
      gl.drawArrays(gl.TRIANGLES, 0, e.n);
    });
  }

  destroy() {
    const gl = this.gl;
    this.chunks.forEach((e) => gl.deleteBuffer(e.buf));
    this.chunks.clear();
    gl.getExtension('WEBGL_lose_context')?.loseContext();
  }
}

/* ============================ On-demand render scheduling ============================ */
let renderer: CraftRenderer | null = null;
let rafId = 0;
export const mirrors = new Set<HTMLCanvasElement>();
export function request() {
  if (!renderer || rafId) return;
  rafId = requestAnimationFrame(() => {
    rafId = 0;
    const r = renderer;
    if (!r) return;
    r.render();
    // copy to the other stereo eye in the same task (the WebGL buffer is still valid here)
    mirrors.forEach((m) => {
      if (m.width !== r.canvas.width || m.height !== r.canvas.height) { m.width = r.canvas.width; m.height = r.canvas.height; }
      m.getContext('2d')?.drawImage(r.canvas, 0, 0);
    });
  });
}
export function attachRenderer(r: CraftRenderer) { renderer = r; request(); }
export function detachRenderer(r: CraftRenderer) {
  if (renderer !== r) return;
  renderer = null;
  if (rafId) cancelAnimationFrame(rafId);
  rafId = 0;
}
