/**
 * Global floating keyboard (one big keyboard for the whole system, OUTSIDE the app windows).
 * Apps register a key handler + "is open" check; the keyboard panel (components/GlobalKeyboard.tsx) and the
 * physical keyboard both send keys to the active target.
 */
import { S, type KbTarget } from './store';
import { pose } from './orientation';
import { setAnchor } from './spatial';
import { clamp } from './math';

type T = Exclude<KbTarget, ''>;
const handlers: Partial<Record<T, { key: (k: string) => void; open: () => boolean; value: () => string; label: string; hint?: string }>> = {};

export function registerKb(t: T, h: { key: (k: string) => void; open: () => boolean; value: () => string; label: string; hint?: string }) { handlers[t] = h; }

export const KB_W = 1200;
export const KB_H = 700;

/** Opens the keyboard for an app, floating low in front of the user (comfortable to pinch). */
export function openKb(t: T) {
  setAnchor('keyboard', { yaw: pose.yaw, pitch: clamp(pose.pitch - 20, -48, 8), dist: 1100, scale: 1.1, w: KB_W, h: KB_H });
  if (S().kbTarget !== t) S().set({ kbTarget: t });
}
export function closeKb() { if (S().kbTarget) S().set({ kbTarget: '' }); }

export function kbInfo() {
  const t = S().kbTarget;
  return t ? handlers[t] ?? null : null;
}
export function isKbOpen(): boolean {
  const h = kbInfo();
  return !!h && h.open();
}
export function kbSend(k: string) { kbInfo()?.key(k); }
