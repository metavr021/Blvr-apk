/**
 * VR Renderer loop (requestAnimationFrame).
 * Frame phases – keeps the browser from doing forced synchronous layouts:
 *   1. READ    : input + hit testing (uses last frame's clean layout)
 *   2. COMPUTE : head pose, menu follow, bottom bar, game
 *   3. WRITE   : eye/world transforms + spatial anchors (string-compared, no redundant writes)
 *   4. DRAW    : canvas overlays (ray, cursor, hands)
 * Hand detection is NOT here – it runs in its own worker/schedule (hands.ts).
 */
import { S } from './store';
import { updatePose, pose, headQ } from './orientation';
import { updateInput } from './input';
import { drawOverlays } from './overlay';
import { samplePerf } from './perf';
import { syncHandRate } from './hands';
import { gameTick, dragState } from './actions';
import { eyes, view, observePrimary } from './view';
import { getAnchor, setAnchor, flushAnchors, menuGeo, barGeo, MENU_BASE } from './spatial';
import { RAD, DEG, wrap180, clamp, quatAngle, quatNlerp, type Quat } from './math';

/** Distance (authored px at scale 1) from the menu center down to the bar anchor. */
const BAR_OFFSET = 418;
const BAR_HALF = 85; // half height of the bar group (authored px)
const lastWorld = new WeakMap<HTMLElement, string>();
const lastPersp = new WeakMap<HTMLElement, string>();
let following = false;
const bar = { yaw: 0, pitch: -29, dist: 1000, scale: 1, followYaw: 0, init: false };
let wq: Quat = [0, 0, 0, 1]; // rotation actually written to the DOM
let wInit = false;
const DB = 0.12; // degrees

/**
 * World transform = inverse head rotation, converted from three.js coords (Y up) to CSS coords (Y down):
 * N = C·Mᵀ·C with C = diag(1,−1,1). matrix3d is column-major → column j = row j of M with signs sᵢ·sⱼ.
 * (Equivalent to the old "rotateZ(roll) rotateX(pitch) rotateY(−yaw)", but exact at every orientation.)
 */
function cssWorldMatrix(q: Quat): string {
  const [x, y, z, w] = q;
  const m00 = 1 - 2 * (y * y + z * z), m01 = 2 * (x * y - z * w), m02 = 2 * (x * z + y * w);
  const m10 = 2 * (x * y + z * w), m11 = 1 - 2 * (x * x + z * z), m12 = 2 * (y * z - x * w);
  const m20 = 2 * (x * z - y * w), m21 = 2 * (y * z + x * w), m22 = 1 - 2 * (x * x + y * y);
  const f = (v: number) => v.toFixed(5);
  return `matrix3d(${f(m00)},${f(-m01)},${f(m02)},0,${f(-m10)},${f(m11)},${f(-m12)},0,${f(m20)},${f(-m21)},${f(m22)},0,0,0,0,1)`;
}

export function startRenderer() {
  let raf = 0;
  let last = performance.now();
  let frames = 0;
  let fpsT = last;

  const frame = (now: number) => {
    raf = requestAnimationFrame(frame);
    const dt = Math.min(0.1, Math.max(0.001, (now - last) / 1000));
    last = now;
    const st = S();
    const set = st.settings;

    // 1. READ
    observePrimary();
    updateInput(dt);

    // 2. COMPUTE
    updatePose(dt);
    const stereo = set.displayMode === 'stereo';
    // Field of view: vertical 90° (VR Box) / 72° (landscape) ; portrait screens use a 75° HORIZONTAL fov
    const portraitScreen = !stereo && view.h > view.w * 1.05;
    const base = portraitScreen ? view.w / 2 / Math.tan((75 * RAD) / 2) : view.h / 2 / Math.tan(((stereo ? 90 : 72) * RAD) / 2);
    const P = Math.round(base * set.zoom * 10) / 10;
    view.P = P;
    view.uiDist = menuGeo.dist;
    view.shift = stereo ? ((set.ipd / 2) * P) / view.uiDist : 0;

    // "Seguir visão": lazy follow (only when the menu drifts out of the comfortable zone)
    const m = getAnchor('menu');
    if (st.menuOpen && m && set.menuFollow && dragState.kind !== 'menu') {
      const dy = wrap180(pose.yaw - m.yaw);
      const tp = clamp(pose.pitch, -20, 20) * 0.85;
      const dp = tp - m.pitch;
      if (!following && (Math.abs(dy) > 12 || Math.abs(dp) > 10)) following = true;
      if (following) {
        const k = 1 - Math.exp(-dt * 4);
        setAnchor('menu', { yaw: m.yaw + dy * k, pitch: m.pitch + dp * k });
        if (Math.abs(dy) < 1 && Math.abs(dp) < 1) following = false;
      }
    } else following = false;

    // Bottom system bar: under the menu when open, otherwise low in the field of view following the body.
    if (!bar.init) { bar.init = true; bar.followYaw = pose.yaw; bar.yaw = pose.yaw; }
    const lookingDown = pose.pitch < -17;
    if (!lookingDown && !st.menuOpen && Math.abs(wrap180(pose.yaw - bar.followYaw)) > 30) bar.followYaw = pose.yaw;
    // Under the menu it follows the menu's size (--ms) and depth (--md) live, also while dragging them.
    const mScale = MENU_BASE * menuGeo.scale;
    const bs = barGeo.scale;
    // Bar top must stay below the menu even when the bar is enlarged: offset grows with the bar size
    const ty = st.menuOpen && m ? m.yaw : bar.followYaw;
    const tp = st.menuOpen && m ? m.pitch - (((BAR_OFFSET + BAR_HALF * (bs - 1)) * mScale) / menuGeo.dist) * DEG : -29 - (bs - 1) * 4;
    const td = st.menuOpen ? menuGeo.dist : 1000;
    const ts = (st.menuOpen ? mScale : 1) * bs;
    const geoDragging = dragState.kind === 'menuSize' || dragState.kind === 'menuDepth' || dragState.kind === 'barSize';
    const kb = geoDragging ? 1 : 1 - Math.exp(-dt * 7);
    const ny = bar.yaw + wrap180(ty - bar.yaw) * kb, np = bar.pitch + (tp - bar.pitch) * kb;
    const nd = bar.dist + (td - bar.dist) * kb, ns = bar.scale + (ts - bar.scale) * kb;
    if (Math.abs(ny - bar.yaw) > 0.005 || Math.abs(np - bar.pitch) > 0.005 || Math.abs(nd - bar.dist) > 0.2 || Math.abs(ns - bar.scale) > 0.0005 || !getAnchor('bar')) {
      bar.yaw = ny; bar.pitch = np; bar.dist = nd; bar.scale = ns;
      setAnchor('bar', { yaw: ny, pitch: np, dist: nd, scale: ns });
    }
    if (lookingDown !== st.lookingDown) st.set({ lookingDown });

    gameTick(dt);

    // 3. WRITE
    // World stabilization on the full rotation (quaternion, no Euler → no gimbal glitches):
    // soft deadband → sensor micro-tremor is absorbed, menus/windows stand perfectly still when the head
    // is still, real movement is followed with only DB° of lag. A still scene writes nothing (idle GPU).
    if (!wInit) { wq = [headQ[0], headQ[1], headQ[2], headQ[3]]; wInit = true; }
    const ang = quatAngle(wq, headQ);
    if (ang > DB) wq = quatNlerp(wq, headQ, (ang - DB) / ang);
    const rot = cssWorldMatrix(wq);
    const pStr = `${P}px`;
    eyes.forEach((e) => {
      if (lastPersp.get(e.stage) !== pStr) { e.stage.style.perspective = pStr; lastPersp.set(e.stage, pStr); }
      const off = e.eye === 'L' ? set.ipd / 2 : e.eye === 'R' ? -set.ipd / 2 : 0;
      const tr = `translateZ(${P}px) translateX(${off}px) ${rot}`;
      if (lastWorld.get(e.world) !== tr) { e.world.style.transform = tr; lastWorld.set(e.world, tr); }
    });
    flushAnchors();

    // 4. DRAW
    drawOverlays(now);
    samplePerf(dt, now);

    frames++;
    if (now - fpsT >= 1000) {
      const fps = Math.round((frames * 1000) / (now - fpsT));
      frames = 0; fpsT = now;
      syncHandRate(); // keep the worker's detection rate in sync with the performance tier
      // FPS is only shown in the system panel → don't re-render anything for it otherwise
      if (fps !== st.fps && st.quickOpen) st.set({ fps });
    }
  };
  raf = requestAnimationFrame(frame);
  return () => cancelAnimationFrame(raf);
}
