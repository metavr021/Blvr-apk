export type Quat = [number, number, number, number];

export const DEG = 180 / Math.PI;
export const RAD = Math.PI / 180;
export const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
export const wrap180 = (d: number) => {
  let x = ((d + 180) % 360 + 360) % 360 - 180;
  if (x === -180) x = 180;
  return x;
};

export function quatFromEulerYXZ(x: number, y: number, z: number): Quat {
  const c1 = Math.cos(x / 2), c2 = Math.cos(y / 2), c3 = Math.cos(z / 2);
  const s1 = Math.sin(x / 2), s2 = Math.sin(y / 2), s3 = Math.sin(z / 2);
  return [
    s1 * c2 * c3 + c1 * s2 * s3,
    c1 * s2 * c3 - s1 * c2 * s3,
    c1 * c2 * s3 - s1 * s2 * c3,
    c1 * c2 * c3 + s1 * s2 * s3,
  ];
}

export function quatMul(a: Quat, b: Quat): Quat {
  const [ax, ay, az, aw] = a; const [bx, by, bz, bw] = b;
  return [
    ax * bw + aw * bx + ay * bz - az * by,
    ay * bw + aw * by + az * bx - ax * bz,
    az * bw + aw * bz + ax * by - ay * bx,
    aw * bw - ax * bx - ay * by - az * bz,
  ];
}

/** Returns [pitch(x), yaw(y), roll(z)] in radians, YXZ order (three.js convention). */
export function eulerYXZFromQuat(q: Quat): [number, number, number] {
  const [x, y, z, w] = q;
  const m11 = 1 - 2 * (y * y + z * z);
  const m13 = 2 * (x * z + w * y);
  const m21 = 2 * (x * y + w * z);
  const m22 = 1 - 2 * (x * x + z * z);
  const m23 = 2 * (y * z - w * x);
  const m31 = 2 * (x * z - w * y);
  const m33 = 1 - 2 * (x * x + y * y);
  const ex = Math.asin(-clamp(m23, -1, 1));
  let ey: number, ez: number;
  if (Math.abs(m23) < 0.9999) { ey = Math.atan2(m13, m33); ez = Math.atan2(m21, m22); }
  else { ey = Math.atan2(-m31, m11); ez = 0; }
  return [ex, ey, ez];
}

const Q1: Quat = [-Math.sqrt(0.5), 0, 0, Math.sqrt(0.5)];

/** Device orientation (degrees) -> camera quaternion (three.js style, -Z forward, Y up). */
export function deviceQuat(alpha: number, beta: number, gamma: number, orient: number): Quat {
  const q = quatFromEulerYXZ(beta * RAD, alpha * RAD, -gamma * RAD);
  const a = quatMul(q, Q1);
  const o = -orient * RAD;
  return quatMul(a, [0, 0, Math.sin(o / 2), Math.cos(o / 2)]);
}

export const quatConj = (q: Quat): Quat => [-q[0], -q[1], -q[2], q[3]];
export function quatNorm(q: Quat): Quat {
  const l = Math.hypot(q[0], q[1], q[2], q[3]) || 1;
  return [q[0] / l, q[1] / l, q[2] / l, q[3] / l];
}
/** Rotation about world Y (degrees). */
export const quatY = (deg: number): Quat => { const h = (deg * RAD) / 2; return [0, Math.sin(h), 0, Math.cos(h)]; };
/** Rotation about X (degrees). */
export const quatX = (deg: number): Quat => { const h = (deg * RAD) / 2; return [Math.sin(h), 0, 0, Math.cos(h)]; };
/** Angle between two rotations (degrees). */
export function quatAngle(a: Quat, b: Quat): number {
  const d = Math.abs(a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3]);
  return 2 * Math.acos(Math.min(1, d)) * DEG;
}
/** Normalized lerp along the shortest path (accurate for the small per-frame steps used here). */
export function quatNlerp(a: Quat, b: Quat, t: number): Quat {
  const s = a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3] < 0 ? -1 : 1;
  return quatNorm([
    a[0] + (s * b[0] - a[0]) * t,
    a[1] + (s * b[1] - a[1]) * t,
    a[2] + (s * b[2] - a[2]) * t,
    a[3] + (s * b[3] - a[3]) * t,
  ]);
}

/** Rotate vector v by quaternion q. */
export function quatRotate(q: Quat, v: [number, number, number]): [number, number, number] {
  const [x, y, z, w] = q;
  const [vx, vy, vz] = v;
  const ix = w * vx + y * vz - z * vy;
  const iy = w * vy + z * vx - x * vz;
  const iz = w * vz + x * vy - y * vx;
  const iw = -x * vx - y * vy - z * vz;
  return [
    ix * w + iw * -x + iy * -z - iz * -y,
    iy * w + iw * -y + iz * -x - ix * -z,
    iz * w + iw * -z + ix * -y - iy * -x,
  ];
}

/**
 * Gimbal-free head angles (degrees) from a camera quaternion (three.js convention: -Z forward, +Y up).
 *  - yaw: heading of (forward − sign(pitch)·up) projected on the floor. Unlike the Euler yaw, this stays
 *    well defined when looking straight up/down (the screen's top edge then gives the heading).
 *  - roll: the exact residual so that  Ry(yaw)·Rx(pitch)·Rz(roll) == q  → the rendered view is always
 *    identical to the real device orientation, no jumps.
 */
export function headAngles(q: Quat): [number, number, number] {
  const f = quatRotate(q, [0, 0, -1]);
  const u = quatRotate(q, [0, 1, 0]);
  const pitch = Math.asin(clamp(f[1], -1, 1));
  const s = pitch >= 0 ? 1 : -1;
  const hx = f[0] - s * u[0];
  const hz = f[2] - s * u[2];
  const yaw = Math.atan2(-hx, -hz);
  // residual roll: q_r = (Ry·Rx)^-1 · q
  const qy: Quat = [0, Math.sin(yaw / 2), 0, Math.cos(yaw / 2)];
  const qx: Quat = [Math.sin(pitch / 2), 0, 0, Math.cos(pitch / 2)];
  const yx = quatMul(qy, qx);
  const inv: Quat = [-yx[0], -yx[1], -yx[2], yx[3]];
  const r = quatMul(inv, q);
  const roll = 2 * Math.atan2(r[2], r[3]);
  return [pitch * DEG, yaw * DEG, wrap180(roll * DEG)];
}

/** One Euro filter – adaptive smoothing for jitter-free pointers. */
export class OneEuro {
  private x: number | null = null;
  private dx = 0;
  private t = 0;
  constructor(public minCutoff = 1.2, public beta = 0.02, public dCutoff = 1) {}
  private alpha(cutoff: number, dt: number) {
    const tau = 1 / (2 * Math.PI * cutoff);
    return 1 / (1 + tau / dt);
  }
  reset() { this.x = null; }
  filter(v: number, t: number) {
    if (this.x === null) { this.x = v; this.t = t; return v; }
    const dt = Math.max(1e-3, t - this.t);
    this.t = t;
    const d = (v - this.x) / dt;
    const ad = this.alpha(this.dCutoff, dt);
    this.dx = this.dx + ad * (d - this.dx);
    const cutoff = this.minCutoff + this.beta * Math.abs(this.dx);
    const a = this.alpha(cutoff, dt);
    this.x = this.x + a * (v - this.x);
    return this.x;
  }
}
