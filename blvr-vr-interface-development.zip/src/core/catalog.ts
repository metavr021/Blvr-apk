import type { AppId } from './store';

/**
 * App catalog. Every entry is a REAL service or a real working feature – no fake clones:
 *  - native apps use public APIs (Open-Meteo, Radio Browser, NASA APOD, Hacker News, Wikipedia)
 *  - embedded apps use the services' official embed players (YouTube, Spotify, Twitch, Lichess,
 *    OpenStreetMap, Windy, Photopea).
 * Limitation (browser security): pinch/gaze cannot click INSIDE third-party iframes. YouTube is fully
 * controllable by pinch through its official postMessage API; other embeds need direct touch (tela única).
 */
export interface CatalogItem {
  id: string;
  name: string;
  kind: 'app' | 'game' | 'env';
  desc: string;
  icon: string; // key of ICONS in components/ui.tsx
  gradient: string;
  cover?: string;
  builtin?: boolean;
  removable?: boolean;
  comingSoon?: boolean;
  appId?: AppId;
  url?: string; // opened in the browser after launching
  size?: string;
  touchOnly?: boolean; // embed that needs direct touch inside
  source?: string;
  android?: string; // launches a real installed Android app (core/launcher.ts)
}

export const CATALOG: CatalogItem[] = [
  { id: 'browser', name: 'Navegador', kind: 'app', desc: 'Pesquise e leia a web em janelas virtuais.', icon: 'globe', gradient: 'from-sky-500 to-blue-700', builtin: true, appId: 'browser' },
  { id: 'meta', name: 'Metaverso', kind: 'app', desc: 'Entre num mundo virtual com mãos neon, mundos e atividades.', icon: 'orbit', gradient: 'from-sky-500 to-fuchsia-700', cover: 'img/meta.jpg', builtin: true, appId: 'meta' },
  { id: 'pokedex', name: 'Pokédex', kind: 'app', desc: 'Os 151 Pokémon originais com tipos e atributos.', icon: 'circledot', gradient: 'from-red-500 to-rose-800', removable: true, appId: 'pokedex', size: 'web', source: 'pokeapi.co' },
  { id: 'piano', name: 'Piano & Bateria', kind: 'app', desc: 'Toque piano e bateria com a pinça.', icon: 'piano', gradient: 'from-slate-500 to-slate-900', removable: true, appId: 'piano', size: '1 MB' },
  { id: 'quiz', name: 'Quiz BLVR', kind: 'game', desc: 'Perguntas de conhecimentos gerais, em português.', icon: 'brain', gradient: 'from-sky-500 to-blue-800', removable: true, appId: 'quiz', size: '1 MB' },
  { id: 'g2048', name: '2048', kind: 'game', desc: 'Junte os números até chegar ao 2048.', icon: 'grid', gradient: 'from-amber-500 to-yellow-700', removable: true, appId: 'g2048', size: '1 MB' },
  { id: 'recipes', name: 'Receitas', kind: 'app', desc: 'Receitas do mundo todo com ingredientes e preparo.', icon: 'chef', gradient: 'from-orange-500 to-red-700', removable: true, appId: 'recipes', size: 'web', source: 'themealdb.com' },
  { id: 'countries', name: 'Países', kind: 'app', desc: 'Bandeiras, capitais e dados de todos os países.', icon: 'flag', gradient: 'from-emerald-500 to-cyan-700', removable: true, appId: 'countries', size: 'web', source: 'restcountries.com' },
  { id: 'quakes', name: 'Terremotos', kind: 'app', desc: 'Terremotos das últimas 24 h no mundo, ao vivo.', icon: 'activity', gradient: 'from-yellow-600 to-red-800', removable: true, appId: 'quakes', size: 'web', source: 'USGS' },
  { id: 'books', name: 'Biblioteca', kind: 'app', desc: 'Milhões de livros da Open Library com capas.', icon: 'library', gradient: 'from-teal-600 to-slate-800', removable: true, appId: 'books', size: 'web', source: 'openlibrary.org' },
  { id: 'android', name: 'Meus apps do celular', kind: 'app', desc: 'Escolha os apps do seu celular que aparecem no menu do BLVR.', icon: 'smartphone', gradient: 'from-lime-500 to-emerald-800', builtin: true, appId: 'android' },
  { id: 'blockblast', name: 'Block Blast 3D', kind: 'game', desc: 'Arraste blocos 3D com a pinça, exploda linhas e avance nas 10 fases!', icon: 'sparkles', gradient: 'from-fuchsia-600 via-purple-600 to-indigo-800', cover: 'img/blockblast.jpg', builtin: true, appId: 'blockblast' },
  { id: 'craft', name: 'BLVR Craft', kind: 'game', desc: 'Jogo de blocos em 3D que roda DENTRO do BLVR: construa, quebre, ande e voe.', icon: 'box', gradient: 'from-green-600 to-sky-700', cover: 'img/craft.jpg', builtin: true, appId: 'craft' },
  { id: 'tetris', name: 'Tetris VR', kind: 'game', desc: 'Clássico jogo de encaixar blocos em VR com controle pela pinça.', icon: 'grid', gradient: 'from-cyan-500 to-blue-700', builtin: true, appId: 'tetris' },
  { id: 'snake', name: 'Cobrinha 3D', kind: 'game', desc: 'Jogo da cobrinha em arena neon com controles rápidos.', icon: 'zap', gradient: 'from-emerald-500 to-teal-800', removable: true, appId: 'snake' },
  { id: 'paint', name: 'BLVR Paint', kind: 'app', desc: 'Estúdio de desenho em VR: cores, tamanhos de pincel e exportar em PNG.', icon: 'palette', gradient: 'from-fuchsia-500 to-pink-700', removable: true, appId: 'paint', size: '1 MB' },
  { id: 'synth', name: 'Laboratório de Áudio', kind: 'app', desc: 'Sintetizador e sequenciador de 8 passos com bateria eletrônica.', icon: 'music', gradient: 'from-purple-600 to-indigo-900', removable: true, appId: 'synth', size: '1 MB' },
  { id: 'code', name: 'Code Playground', kind: 'app', desc: 'Editor HTML, CSS e JavaScript com prévia ao vivo em VR.', icon: 'terminal', gradient: 'from-blue-600 to-slate-900', removable: true, appId: 'code', size: '1 MB' },
  { id: 'shizuku', name: 'Shizuku & Android', kind: 'app', desc: 'Diagnóstico técnico: entenda como o Shizuku e o Android funcionam.', icon: 'terminal', gradient: 'from-blue-900 to-slate-950', builtin: true, appId: 'shizuku' },
  { id: 'minecraft', name: 'Minecraft', kind: 'game', desc: 'App oficial do Android: abre no celular, fora do BLVR (não pode rodar numa janela de site). Para jogar aqui dentro use o BLVR Craft.', icon: 'box', gradient: 'from-green-600 to-amber-800', removable: true, android: 'minecraft', size: 'app Android' },
  { id: 'telao', name: 'Telão YouTube', kind: 'app', desc: 'Um telão gigante no cenário só para o YouTube. Mova, aumente e afaste com a pinça.', icon: 'monitor', gradient: 'from-red-600 to-zinc-900', builtin: true, appId: 'telao' },
  { id: 'youtube', name: 'YouTube', kind: 'app', desc: 'Player oficial do YouTube controlado pela pinça. Pesquisa livre e lista de categorias.', icon: 'youtube', gradient: 'from-red-500 to-red-700', removable: true, appId: 'youtube', size: 'web', source: 'youtube.com (embed oficial)' },
  { id: 'cinema', name: 'Cinema VR', kind: 'app', desc: 'Filmes abertos da Blender Foundation numa tela gigante.', icon: 'film', gradient: 'from-rose-500 to-red-800', builtin: true, appId: 'cinema' },
  { id: 'balloons', name: 'Balões 360', kind: 'game', desc: 'Estoure balões ao seu redor usando a pinça ou o olhar.', icon: 'target', gradient: 'from-amber-400 to-orange-600', cover: 'img/hero.jpg', builtin: true, appId: 'balloons' },
  { id: 'radio', name: 'Rádio', kind: 'app', desc: 'Milhares de rádios ao vivo do Brasil e do mundo.', icon: 'radio', gradient: 'from-orange-500 to-pink-600', removable: true, appId: 'radio', size: 'web', source: 'radio-browser.info' },
  { id: 'weather', name: 'Clima', kind: 'app', desc: 'Previsão do tempo real de 7 dias + radar de chuva.', icon: 'cloud', gradient: 'from-sky-400 to-indigo-600', removable: true, appId: 'weather', size: 'web', source: 'Open-Meteo + Windy' },
  { id: 'spotify', name: 'Spotify', kind: 'app', desc: 'Playlists oficiais do Spotify (prévia sem login).', icon: 'music', gradient: 'from-green-500 to-emerald-700', removable: true, appId: 'spotify', size: 'web', touchOnly: true, source: 'open.spotify.com (embed)' },
  { id: 'twitch', name: 'Twitch', kind: 'app', desc: 'Lives da Twitch em tela grande.', icon: 'tv', gradient: 'from-violet-500 to-purple-800', removable: true, appId: 'twitch', size: 'web', source: 'player.twitch.tv (embed)' },
  { id: 'nasa', name: 'NASA · Foto do Dia', kind: 'app', desc: 'Astronomy Picture of the Day, direto da NASA.', icon: 'telescope', gradient: 'from-indigo-600 to-slate-900', removable: true, appId: 'nasa', size: 'web', source: 'api.nasa.gov (APOD)' },
  { id: 'chess', name: 'Lichess', kind: 'app', desc: 'Partidas ao vivo e quebra-cabeças de xadrez do Lichess.', icon: 'crown', gradient: 'from-stone-500 to-stone-800', removable: true, appId: 'chess', size: 'web', touchOnly: true, source: 'lichess.org (embed)' },
  { id: 'news', name: 'Hacker News', kind: 'app', desc: 'As notícias de tecnologia mais votadas agora.', icon: 'newspaper', gradient: 'from-orange-500 to-amber-700', removable: true, appId: 'news', size: 'web', source: 'news.ycombinator.com (API)' },
  { id: 'wikipedia', name: 'Wikipédia', kind: 'app', desc: 'A enciclopédia livre com leitura nativa em VR.', icon: 'book', gradient: 'from-zinc-300 to-zinc-600', removable: true, appId: 'browser', url: 'wiki:', size: 'web', source: 'pt.wikipedia.org (API)' },
  { id: 'maps', name: 'Mapas', kind: 'app', desc: 'Explore o mundo com OpenStreetMap.', icon: 'map', gradient: 'from-emerald-500 to-teal-700', removable: true, appId: 'maps', size: 'web', touchOnly: true, source: 'openstreetmap.org' },
  { id: 'photopea', name: 'Photopea', kind: 'app', desc: 'Editor de imagens completo na web (pesado).', icon: 'image', gradient: 'from-cyan-600 to-slate-800', removable: true, appId: 'photopea', size: 'web', touchOnly: true, source: 'photopea.com' },
  { id: 'calc', name: 'Calculadora', kind: 'app', desc: 'Calculadora com botões grandes para a pinça.', icon: 'calculator', gradient: 'from-zinc-500 to-zinc-800', removable: true, appId: 'calc', size: '1 MB' },
  { id: 'clock', name: 'Relógio', kind: 'app', desc: 'Horário mundial, cronômetro com voltas e timer.', icon: 'clock', gradient: 'from-slate-600 to-indigo-900', removable: true, appId: 'clock', size: '1 MB' },
  { id: 'fx', name: 'Câmbio', kind: 'app', desc: 'Cotações ao vivo: dólar, euro, libra, bitcoin e mais.', icon: 'coins', gradient: 'from-emerald-600 to-green-900', removable: true, appId: 'fx', size: 'web', source: 'AwesomeAPI (economia.awesomeapi.com.br)' },
  { id: 'museum', name: 'Museu de Arte', kind: 'app', desc: 'Obras de domínio público do Art Institute of Chicago.', icon: 'landmark', gradient: 'from-amber-700 to-stone-900', removable: true, appId: 'museum', size: 'web', source: 'api.artic.edu' },
  { id: 'tictactoe', name: 'Jogo da Velha', kind: 'game', desc: 'Você contra o BLVR. Fácil de jogar com a pinça.', icon: 'hash', gradient: 'from-sky-500 to-indigo-700', removable: true, appId: 'tictactoe', size: '1 MB' },
  { id: 'memory', name: 'Memória', kind: 'game', desc: 'Encontre os pares no menor número de jogadas.', icon: 'brain', gradient: 'from-pink-500 to-purple-700', removable: true, appId: 'memory', size: '1 MB' },
  { id: 'notes', name: 'Notas', kind: 'app', desc: 'Bloco de notas com teclado virtual.', icon: 'notebook', gradient: 'from-yellow-400 to-amber-600', removable: true, appId: 'notes', size: '1 MB' },
  { id: 'neonpop', name: 'Neon Pop', kind: 'game', desc: 'Versão neon e rápida: alvos menores, mais pontos.', icon: 'zap', gradient: 'from-fuchsia-500 to-indigo-700', cover: 'img/neonpop.jpg', removable: true, appId: 'neonpop', size: '4 MB' },
  { id: 'env-night', name: 'Ambiente: Noite', kind: 'env', desc: 'Transforme o terraço num cenário noturno.', icon: 'moon', gradient: 'from-indigo-600 to-slate-900', removable: true, size: '3 MB' },
  { id: 'env-void', name: 'Ambiente: Vazio', kind: 'env', desc: 'Um espaço escuro e minimalista para foco.', icon: 'circle', gradient: 'from-slate-600 to-black', removable: true, size: '1 MB' },
];

export const byId = (id: string) => CATALOG.find((c) => c.id === id);

/** Default window size per app (px ≈ mm at window scale). */
export const APP_WIN: Record<AppId, { w: number; h: number; title: string }> = {
  browser: { w: 1040, h: 700, title: 'Navegador' },
  cinema: { w: 1180, h: 740, title: 'Cinema VR' },
  maps: { w: 960, h: 660, title: 'Mapas' },
  notes: { w: 760, h: 600, title: 'Notas' },
  balloons: { w: 600, h: 400, title: 'Balões 360' },
  neonpop: { w: 600, h: 400, title: 'Neon Pop' },
  youtube: { w: 1260, h: 720, title: 'YouTube' },
  spotify: { w: 900, h: 700, title: 'Spotify' },
  twitch: { w: 1180, h: 740, title: 'Twitch' },
  radio: { w: 980, h: 680, title: 'Rádio' },
  weather: { w: 1040, h: 700, title: 'Clima' },
  nasa: { w: 1100, h: 720, title: 'NASA · Foto do Dia' },
  chess: { w: 900, h: 740, title: 'Lichess' },
  photopea: { w: 1280, h: 760, title: 'Photopea' },
  news: { w: 940, h: 720, title: 'Hacker News' },
  telao: { w: 1280, h: 830, title: 'Telão' },
  calc: { w: 520, h: 740, title: 'Calculadora' },
  clock: { w: 780, h: 600, title: 'Relógio' },
  fx: { w: 860, h: 640, title: 'Câmbio' },
  museum: { w: 1120, h: 740, title: 'Museu de Arte' },
  tictactoe: { w: 620, h: 720, title: 'Jogo da Velha' },
  memory: { w: 760, h: 760, title: 'Memória' },
  meta: { w: 600, h: 400, title: 'Metaverso' },
  pokedex: { w: 1100, h: 740, title: 'Pokédex' },
  piano: { w: 1180, h: 640, title: 'Piano & Bateria' },
  quiz: { w: 820, h: 640, title: 'Quiz BLVR' },
  g2048: { w: 620, h: 780, title: '2048' },
  recipes: { w: 1100, h: 740, title: 'Receitas' },
  countries: { w: 1100, h: 740, title: 'Países' },
  quakes: { w: 900, h: 700, title: 'Terremotos' },
  books: { w: 1100, h: 740, title: 'Biblioteca' },
  android: { w: 1100, h: 740, title: 'Meus apps do celular' },
  craft: { w: 1240, h: 820, title: 'BLVR Craft' },
  tetris: { w: 860, h: 740, title: 'Tetris VR' },
  snake: { w: 720, h: 720, title: 'Cobrinha 3D' },
  paint: { w: 1100, h: 760, title: 'BLVR Paint' },
  synth: { w: 1140, h: 720, title: 'Laboratório de Áudio' },
  code: { w: 1180, h: 740, title: 'Code Playground' },
  solitaire: { w: 880, h: 700, title: 'Paciência VR' },
  shizuku: { w: 1040, h: 720, title: 'Shizuku & Android' },
  blockblast: { w: 1140, h: 800, title: 'Block Blast 3D' },
};

export const VIDEOS = [
  { title: 'Big Buck Bunny', src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' },
  { title: 'Sintel', src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4' },
  { title: 'Elephants Dream', src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4' },
  { title: 'Tears of Steel', src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4' },
];

export const QUICK_LINKS = [
  { name: 'YouTube', url: 'app:youtube', color: 'bg-red-600', letter: '▶' },
  { name: 'Wikipédia', url: 'wiki:', color: 'bg-slate-200 text-slate-900', letter: 'W' },
  { name: 'OpenStreetMap', url: 'https://www.openstreetmap.org/export/embed.html?bbox=-46.75,-23.65,-46.55,-23.5&layer=mapnik', color: 'bg-emerald-500', letter: 'M' },
  { name: 'Hacker News', url: 'app:news', color: 'bg-orange-500', letter: 'Y' },
];
