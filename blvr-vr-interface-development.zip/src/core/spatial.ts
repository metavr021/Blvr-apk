/**
 * Spatial anchors – world-locked positions (yaw/pitch/dist on a sphere around the user).
 * Positions are mutated imperatively (drag, follow, open) and written straight to the DOM
 * in the render loop (flushAnchors). React never re-renders because something moved.
 * 1 world px ≈ 1 mm.
 */
export interface Anchor { yaw: number; pitch: number; dist: number; scale: number; w?: number; h?: number }

const anchors = new Map<string, Anchor>();
const els = new Map<string, Set<HTMLElement>>();
const dirty = new Set<string>();

export function getAnchor(id: string): Anchor | undefined { return anchors.get(id); }

export function setAnchor(id: string, p: Partial<Anchor>) {
  const a = anchors.get(id);
  if (a) Object.assign(a, p);
  else anchors.set(id, { yaw: 0, pitch: 0, dist: 1400, scale: 1, ...p });
  dirty.add(id);
}

export function ensureAnchor(id: string, init: Anchor) {
  if (!anchors.has(id)) { anchors.set(id, { ...init }); dirty.add(id); }
}

export function deleteAnchor(id: string) { anchors.delete(id); dirty.delete(id); }

function apply(el: HTMLElement, a: Anchor) {
  el.style.transform = `rotateY(${a.yaw.toFixed(3)}deg) rotateX(${(-a.pitch).toFixed(3)}deg) translateZ(${(-a.dist).toFixed(1)}px) scale(${a.scale})`;
  if (a.dist > 0) {
    // depth (mm) → the stereo cursor is drawn at the depth of the panel it points at
    const d = String(Math.round(a.dist));
    if (el.dataset.depth !== d) { el.dataset.depth = d; el.style.setProperty('--d', d); }
  }
  if (a.w !== undefined && a.h !== undefined) {
    el.style.width = `${a.w}px`;
    el.style.height = `${a.h}px`;
    el.style.marginLeft = `${-a.w / 2}px`;
    el.style.marginTop = `${-a.h / 2}px`;
  }
}

/**
 * Menu geometry – size (corner handle) and depth (slider under the menu).
 * Written as CSS variables --ms (scale) and --md (distance, mm) on the menu + bar groups;
 * panels use calc() transforms, so resizing / moving in depth never re-renders React.
 */
export const menuGeo = { scale: 1, dist: 1400 };
/** Hotbar size (end handles). Applied by the renderer to the bar anchor's scale – no React work. */
export const barGeo = { scale: 1 };
export function setBarGeo(scale: number) { barGeo.scale = scale; }
export const MENU_BASE = 1.4; // world scale of the menu at scale 1 (authored at 1 m)
const VAR_IDS = ['menu', 'bar'];
let varsDirty = true;

export function setMenuGeo(p: Partial<typeof menuGeo>) {
  if ((p.scale === undefined || p.scale === menuGeo.scale) && (p.dist === undefined || p.dist === menuGeo.dist)) return;
  Object.assign(menuGeo, p);
  varsDirty = true;
}

function applyVars(el: HTMLElement, id: string) {
  if (id === 'menu') el.dataset.depth = String(Math.round(menuGeo.dist));
  el.style.setProperty('--ms', menuGeo.scale.toFixed(4));
  el.style.setProperty('--md', menuGeo.dist.toFixed(1));
  const txt = `${(menuGeo.dist / 1000).toFixed(2)} m`;
  el.querySelectorAll<HTMLElement>('[data-md-label]').forEach((l) => { if (l.textContent !== txt) l.textContent = txt; });
}

export function registerEl(id: string, el: HTMLElement) {
  let set = els.get(id);
  if (!set) { set = new Set(); els.set(id, set); }
  set.add(el);
  const a = anchors.get(id);
  if (a) apply(el, a);
  if (VAR_IDS.includes(id)) applyVars(el, id);
}

export function unregisterEl(id: string, el: HTMLElement) {
  els.get(id)?.delete(el);
}

/** Write changed anchors to the DOM (called once per frame, in the write phase). */
export function flushAnchors() {
  if (varsDirty) {
    varsDirty = false;
    VAR_IDS.forEach((id) => els.get(id)?.forEach((el) => applyVars(el, id)));
  }
  if (!dirty.size) return;
  dirty.forEach((id) => {
    const a = anchors.get(id);
    const set = els.get(id);
    if (a && set) set.forEach((el) => apply(el, a));
  });
  dirty.clear();
}
