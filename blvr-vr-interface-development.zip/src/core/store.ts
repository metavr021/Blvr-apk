import { create } from 'zustand';

/**
 * Low-frequency UI state only.
 * High-frequency data (head pose, hand landmarks, cursor, drag positions) lives in
 * mutable modules (orientation.ts, hands.ts, input.ts, spatial.ts) and NEVER goes through React per frame.
 */

export type Section = 'home' | 'browser' | 'apps' | 'games' | 'store' | 'settings';
export type AppId = 'browser' | 'cinema' | 'maps' | 'balloons' | 'neonpop' | 'notes'
  | 'youtube' | 'spotify' | 'twitch' | 'radio' | 'weather' | 'nasa' | 'chess' | 'photopea' | 'news'
  | 'telao' | 'calc' | 'clock' | 'fx' | 'museum' | 'tictactoe' | 'memory'
  | 'meta' | 'pokedex' | 'recipes' | 'countries' | 'quakes' | 'books' | 'piano' | 'g2048' | 'quiz' | 'android' | 'craft'
  | 'tetris' | 'snake' | 'paint' | 'synth' | 'code' | 'solitaire' | 'shizuku' | 'blockblast';
export type KbTarget = '' | 'browser' | 'youtube' | 'notes' | 'twitch';
export type MetaWorld = 'neon' | 'space' | 'sunset' | 'matrix' | 'forest' | 'meadow';
export type MetaTab = 'home' | 'worlds' | 'activities' | 'hands';
export type HandFollow = 'slow' | 'normal' | 'fast' | 'instant';

export interface Settings {
  displayMode: 'single' | 'stereo';
  ipd: number; // mm (1 world px = 1 mm)
  separation: number; // px offset between eye centers
  zoom: number; // field-of-view scale for virtual UI
  distortion: boolean;
  distortionStrength: number;
  gyroEnabled: boolean;
  /** camera prefs to restore when leaving the pure 3DoF mode */
  mixedPrefs: { passthrough: boolean; handTracking: boolean };
  sensitivity: number;
  smoothing: number;
  invertH: boolean;
  invertV: boolean;
  handTracking: boolean;
  handFps: number;
  camera: 'environment' | 'user';
  cameraRes: '480' | '720';
  dominantHand: 'right' | 'left';
  swapHands: boolean;
  menuGestureTime: number; // seconds
  rayGain: number;
  raySmoothing: number;
  showHandSkeleton: boolean;
  poke: boolean;
  gazeCursor: boolean;
  gazeSelect: 'tap' | 'dwell';
  dwellTime: number;
  holdTime: number;
  sound: boolean;
  passthrough: boolean;
  ptZoom: number;
  ptBrightness: number;
  menuFollow: boolean;
  menuDistance: number; // mm
  menuScale: number; // menu size multiplier (corner handle)
  barScale: number; // hotbar size multiplier (end handles)
  metaWorld: MetaWorld; // metaverse scene
  handColor: string; // neon hand color (metaverse)
  handGlow: boolean; // neon glow layers
  handWidth: number; // neon finger thickness multiplier
  telaoDist: number; // YouTube big screen distance (mm)
  telaoScale: number; // YouTube big screen size multiplier
  handFollow: HandFollow; // hand cursor follow speed
  handDelegate: 'auto' | 'cpu' | 'gpu'; // MediaPipe processor (auto: benchmark GPU vs CPU)
  handsNum: 'auto' | '1' | '2'; // hands tracked (1 = much faster on low-end phones)
  doubleTap: boolean; // Quest-style: double-tap the headset → passthrough
  portrait: boolean; // vertical test mode (single screen)
  environment: 'sunset' | 'night' | 'void';
  perfMode: 'auto' | 'low' | 'high';
}

export const defaultSettings: Settings = {
  displayMode: 'single',
  ipd: 63,
  separation: 0,
  zoom: 1,
  distortion: false,
  distortionStrength: 0.22,
  gyroEnabled: true,
  mixedPrefs: { passthrough: true, handTracking: true },
  sensitivity: 1,
  smoothing: 0.4,
  invertH: false,
  invertV: false,
  handTracking: true,
  handFps: 30,
  camera: 'environment',
  cameraRes: '480',
  dominantHand: 'right',
  swapHands: false,
  menuGestureTime: 1.75,
  rayGain: 1, // 1 = cursor dot exactly on the index fingertip
  raySmoothing: 0.5,
  showHandSkeleton: false,
  poke: false,
  gazeCursor: true,
  gazeSelect: 'tap',
  dwellTime: 1.4,
  holdTime: 0.8,
  sound: true,
  passthrough: true,
  ptZoom: 1,
  ptBrightness: 1,
  menuFollow: false,
  menuDistance: 1400,
  menuScale: 1,
  barScale: 1,
  metaWorld: 'neon',
  handColor: '#3b82f6',
  handGlow: true,
  handWidth: 1,
  telaoDist: 3000,
  telaoScale: 1,
  handFollow: 'instant',
  handDelegate: 'auto',
  handsNum: 'auto',
  doubleTap: true,
  portrait: false,
  environment: 'sunset',
  perfMode: 'auto',
};

export interface WinState {
  id: string;
  app: AppId;
  title: string;
  minimized: boolean;
}

export type HandStatus = 'off' | 'starting' | 'loading' | 'searching' | 'tracking' | 'error' | 'unsupported';
export type GyroStatus = 'off' | 'waiting' | 'active' | 'unavailable' | 'denied';
export type CameraStatus = 'off' | 'starting' | 'active' | 'error' | 'unsupported';

export interface HandSide {
  present: boolean;
  pinch: number;
  pinching: boolean;
  palmUp: boolean;
  pointing: boolean;
  dir: number;
}

export interface Toast { id: number; text: string; kind: 'info' | 'ok' | 'warn' }

export interface BrowserState {
  mode: 'home' | 'search' | 'article' | 'web';
  url: string;
  input: string;
  keyboard: boolean;
  loading: boolean;
  error: string;
  results: { title: string; snippet: string }[];
  article: { title: string; html: string; thumb?: string } | null;
  history: { mode: BrowserState['mode']; url: string; title?: string }[];
}

export interface CinemaState { src: number; playing: boolean; time: number; duration: number }

export interface Target { id: number; yaw: number; pitch: number; hue: number; size: number; popped: boolean }
export interface GameState {
  active: boolean;
  mode: 'balloons' | 'neonpop';
  score: number;
  timeLeft: number;
  yaw: number;
  targets: Target[];
  best: Record<string, number>;
  finished: boolean;
}

const LS_KEY = 'blvr.settings.v7';
const LS_APPS = 'blvr.apps.v2';
const DEFAULT_APPS = ['browser', 'meta', 'blockblast', 'telao', 'youtube', 'android', 'minecraft', 'twitch', 'cinema', 'balloons', 'radio', 'weather', 'maps', 'calc', 'clock', 'tictactoe', 'piano', 'quiz', 'pokedex'];
const ALWAYS = ['browser', 'meta', 'blockblast', 'telao', 'android', 'craft', 'cinema', 'balloons']; // built-ins (cannot be uninstalled)

export const LS_MYAPPS = 'blvr.myapps.v1';
function loadMyApps(): string[] {
  try {
    const a = JSON.parse(localStorage.getItem(LS_MYAPPS) || 'null');
    if (Array.isArray(a)) return a;
  } catch { /* ignore */ }
  return ['minecraft', 'youtube', 'spotify', 'whatsapp', 'instagram', 'tiktok', 'freefire', 'roblox'];
}

function loadSettings(): Settings {
  try {
    const cur = localStorage.getItem(LS_KEY);
    if (cur) return { ...defaultSettings, ...JSON.parse(cur) };
    // Migration: keep user prefs, apply the new defaults (light camera, no skeleton, cursor dot on the finger).
    const old = JSON.parse(localStorage.getItem('blvr.settings.v6') || localStorage.getItem('blvr.settings.v5') || localStorage.getItem('blvr.settings.v4') || '{}');
    // New hand pipeline defaults: no cursor animation (instant), max detection rate, auto engine benchmark
    return { ...defaultSettings, ...old, cameraRes: '480', perfMode: 'auto', showHandSkeleton: false, portrait: false, rayGain: 1, handFollow: 'instant', handDelegate: 'auto', handFps: 30 };
  } catch { return { ...defaultSettings }; }
}
function loadApps(): string[] {
  try {
    const a = JSON.parse(localStorage.getItem(LS_APPS) || 'null');
    if (Array.isArray(a)) return Array.from(new Set([...ALWAYS, ...a]));
    const old = JSON.parse(localStorage.getItem('blvr.apps.v1') || 'null');
    if (Array.isArray(old)) return Array.from(new Set([...DEFAULT_APPS, ...old]));
  } catch { /* ignore */ }
  return [...DEFAULT_APPS];
}

interface Store {
  started: boolean;
  settings: Settings;
  menuOpen: boolean;
  quickOpen: boolean;
  telaoOpen: boolean;
  canInstall: boolean; // Chrome offered the "install app" prompt
  kbTarget: KbTarget; // which app the big floating keyboard types into
  myApps: string[]; // phone apps the user marked to show in the BLVR menu
  cinemaDim: boolean; // Quest-style theater dimming of the passthrough
  reclined: boolean; // Quest-style lying-down mode
  meta: boolean; // inside the BLVR Metaverso
  metaHubOpen: boolean;
  metaTab: MetaTab;
  section: Section;
  windows: WinState[];
  focused: string | null;
  installed: string[];
  wishlist: string[];
  handStatus: HandStatus;
  handMsg: string;
  handEngine: string;
  hands: { left: HandSide; right: HandSide };
  cameraStatus: CameraStatus;
  cameraMsg: string;
  gyroStatus: GyroStatus;
  battery: { level: number; charging: boolean } | null;
  online: boolean;
  netType: string;
  lookingDown: boolean;
  fps: number;
  perfTier: number;
  toasts: Toast[];
  browser: BrowserState;
  cinema: CinemaState;
  notes: string;
  mapCity: number;
  kbCaps: boolean;
  introDone: boolean;
  game: GameState;
  set: (p: Partial<Store>) => void;
  setSetting: <K extends keyof Settings>(k: K, v: Settings[K]) => void;
  resetSettings: () => void;
  toast: (text: string, kind?: Toast['kind']) => void;
}

export const emptyHand: HandSide = { present: false, pinch: 0, pinching: false, palmUp: false, pointing: false, dir: 0 };

let toastId = 1;

export const useStore = create<Store>((set, get) => ({
  started: false,
  settings: loadSettings(),
  menuOpen: false,
  quickOpen: false,
  telaoOpen: false,
  canInstall: false,
  kbTarget: '',
  myApps: loadMyApps(),
  cinemaDim: false,
  reclined: false,
  meta: false,
  metaHubOpen: false,
  metaTab: 'home',
  section: 'home',
  windows: [],
  focused: null,
  installed: loadApps(),
  wishlist: [],
  handStatus: 'off',
  handMsg: 'Desligado',
  handEngine: '',
  hands: { left: emptyHand, right: emptyHand },
  cameraStatus: 'off',
  cameraMsg: 'Desligada',
  gyroStatus: 'off',
  battery: null,
  online: navigator.onLine,
  netType: '',
  lookingDown: false,
  fps: 0,
  perfTier: 0,
  toasts: [],
  browser: {
    mode: 'home', url: '', input: '', keyboard: false, loading: false, error: '',
    results: [], article: null, history: [],
  },
  cinema: { src: 0, playing: false, time: 0, duration: 0 },
  notes: '',
  mapCity: 0,
  kbCaps: false,
  introDone: false,
  game: { active: false, mode: 'balloons', score: 0, timeLeft: 0, yaw: 0, targets: [], best: {}, finished: false },
  set: (p) => set(p),
  setSetting: (k, v) => {
    if (get().settings[k] === v) return;
    const settings = { ...get().settings, [k]: v };
    localStorage.setItem(LS_KEY, JSON.stringify(settings));
    set({ settings });
  },
  resetSettings: () => {
    localStorage.setItem(LS_KEY, JSON.stringify(defaultSettings));
    set({ settings: { ...defaultSettings } });
  },
  toast: (text, kind = 'info') => {
    const id = toastId++;
    set({ toasts: [...get().toasts.slice(-2), { id, text, kind }] });
    setTimeout(() => set({ toasts: get().toasts.filter((t) => t.id !== id) }), 3400);
  },
}));

export function saveInstalled(list: string[]) {
  localStorage.setItem(LS_APPS, JSON.stringify(list));
}

export const S = () => useStore.getState();
