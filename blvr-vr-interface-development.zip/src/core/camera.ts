/**
 * Camera / Passthrough module.
 * ONE MediaStream is shared by every consumer (passthrough display in each eye + hand tracking).
 * The stream is only (re)opened when the facing mode or resolution actually changes.
 *
 * NOTE (honest limitation): phones expose a single usable back camera to the browser,
 * so passthrough is MONOCULAR: in stereo mode both eyes show the same image (no real depth).
 */
import { S } from './store';

type Consumer = 'hands' | 'passthrough';

export const camera = {
  stream: null as MediaStream | null,
  facing: '' as '' | 'environment' | 'user',
  res: '',
  /** hidden <video> used as the source for hand detection (never re-created) */
  video: null as HTMLVideoElement | null,
  listeners: new Set<() => void>(),
};

const consumers = new Set<Consumer>();
let chain: Promise<unknown> = Promise.resolve();

export function desiredFacing(): 'environment' | 'user' {
  const s = S().settings;
  return s.passthrough ? 'environment' : s.camera;
}

function notify() { camera.listeners.forEach((l) => l()); }

function getVideo(): HTMLVideoElement {
  if (!camera.video) {
    const v = document.createElement('video');
    v.playsInline = true;
    v.muted = true;
    v.autoplay = true;
    v.setAttribute('playsinline', '');
    // Kept in the DOM (invisible) so mobile browsers never pause it.
    v.style.cssText = 'position:fixed;left:0;top:0;width:2px;height:2px;opacity:0;pointer-events:none;z-index:-1';
    document.body.appendChild(v);
    camera.video = v;
  }
  return camera.video;
}

function close() {
  camera.stream?.getTracks().forEach((t) => t.stop());
  camera.stream = null;
  camera.facing = '';
  camera.res = '';
  if (camera.video) camera.video.srcObject = null;
  S().set({ cameraStatus: 'off', cameraMsg: 'Desligada' });
  notify();
}

async function open(): Promise<MediaStream> {
  const facing = desiredFacing();
  // Camera image not shown (hands only: metaverse / passthrough off) → 320×240 is plenty for hand tracking
  // and much cheaper to capture, convert and analyse.
  const st0 = S();
  const handsOnly = !st0.settings.passthrough || st0.meta;
  const res = handsOnly ? '240' : st0.settings.cameraRes;
  if (camera.stream && camera.facing === facing && camera.res === res && camera.stream.active) return camera.stream;
  if (!window.isSecureContext) {
    S().set({ cameraStatus: 'unsupported', cameraMsg: 'Requer HTTPS' });
    throw new Error('A câmera exige conexão segura (HTTPS).');
  }
  if (!navigator.mediaDevices?.getUserMedia) {
    S().set({ cameraStatus: 'unsupported', cameraMsg: 'Navegador sem acesso à câmera' });
    throw new Error('Este navegador não permite acesso à câmera.');
  }
  camera.stream?.getTracks().forEach((t) => t.stop());
  S().set({ cameraStatus: 'starting', cameraMsg: 'Abrindo câmera…' });
  const big = res === '720';
  let stream: MediaStream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        facingMode: { ideal: facing },
        width: { ideal: big ? 1280 : res === '240' ? 320 : 640 },
        height: { ideal: big ? 720 : res === '240' ? 240 : 480 },
        frameRate: { ideal: 30, max: 30 },
      },
    });
  } catch (e) {
    const err = e as Error & { name?: string };
    let msg = err?.message || 'erro desconhecido';
    if (err?.name === 'NotAllowedError') msg = 'permissão da câmera negada';
    if (err?.name === 'NotFoundError' || err?.name === 'OverconstrainedError') msg = 'nenhuma câmera encontrada';
    if (err?.name === 'NotReadableError') msg = 'câmera em uso por outro app';
    camera.stream = null;
    S().set({ cameraStatus: 'error', cameraMsg: msg });
    notify();
    throw new Error(msg);
  }
  const v = getVideo();
  v.srcObject = stream;
  await v.play().catch(() => undefined);
  camera.stream = stream;
  camera.facing = facing;
  camera.res = res;
  const st = stream.getVideoTracks()[0]?.getSettings?.();
  S().set({ cameraStatus: 'active', cameraMsg: `Ativa · ${st?.width ?? '?'}×${st?.height ?? '?'} · ${facing === 'environment' ? 'traseira' : 'frontal'}` });
  notify();
  return stream;
}

/** Serialize all camera operations to avoid racing getUserMedia calls. */
function enqueue<T>(fn: () => Promise<T> | T): Promise<T> {
  const p = chain.then(fn, fn);
  chain = p.catch(() => undefined);
  return p;
}

export function acquireCamera(c: Consumer): Promise<MediaStream> {
  consumers.add(c);
  return enqueue(open);
}

export function releaseCamera(c: Consumer) {
  consumers.delete(c);
  void enqueue(() => { if (!consumers.size) close(); });
}

/** Re-open only if facing/resolution changed and someone is using the camera. */
export function refreshCamera() {
  if (!consumers.size) return Promise.resolve(null);
  return enqueue(open).catch(() => null);
}

export const cameraInUse = (c: Consumer) => consumers.has(c);
