import { S } from './store';

let ctx: AudioContext | null = null;

export function unlockAudio() {
  try {
    if (!ctx) ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
  } catch { /* no audio */ }
}

function tone(freq: number, dur: number, type: OscillatorType = 'sine', vol = 0.08, slide = 0) {
  if (!S().settings.sound || !ctx) return;
  const t = ctx.currentTime;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(freq * slide, t + dur);
  g.gain.setValueAtTime(vol, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(ctx.destination);
  o.start(t);
  o.stop(t + dur + 0.02);
}

/* ---------- Instruments (Piano & Bateria app) – synthesized, always audible (not UI sounds) ---------- */
export function playNote(freq: number, dur = 0.9) {
  if (!ctx) unlockAudio();
  if (!ctx) return;
  const t = ctx.currentTime;
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(0.22, t + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  g.connect(ctx.destination);
  [[1, 'triangle', 1], [2, 'sine', 0.35], [3, 'sine', 0.12]].forEach(([mul, type, vol]) => {
    const o = ctx!.createOscillator();
    const og = ctx!.createGain();
    o.type = type as OscillatorType;
    o.frequency.value = freq * (mul as number);
    og.gain.value = vol as number;
    o.connect(og).connect(g);
    o.start(t);
    o.stop(t + dur + 0.05);
  });
}

let noiseBuf: AudioBuffer | null = null;
function noise(c: AudioContext) {
  if (!noiseBuf) {
    noiseBuf = c.createBuffer(1, c.sampleRate * 0.5, c.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  }
  const s = c.createBufferSource();
  s.buffer = noiseBuf;
  return s;
}
export function playDrum(kind: 'kick' | 'snare' | 'hat' | 'clap' | 'tom' | 'crash') {
  if (!ctx) unlockAudio();
  if (!ctx) return;
  const c = ctx, t = c.currentTime;
  const out = c.createGain();
  out.connect(c.destination);
  if (kind === 'kick' || kind === 'tom') {
    const o = c.createOscillator();
    const f0 = kind === 'kick' ? 150 : 220;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(kind === 'kick' ? 40 : 90, t + 0.25);
    out.gain.setValueAtTime(0.9, t);
    out.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
    o.connect(out); o.start(t); o.stop(t + 0.4);
    return;
  }
  const n = noise(c);
  const f = c.createBiquadFilter();
  const len = kind === 'hat' ? 0.06 : kind === 'crash' ? 0.9 : kind === 'clap' ? 0.18 : 0.2;
  f.type = kind === 'hat' || kind === 'crash' ? 'highpass' : 'bandpass';
  f.frequency.value = kind === 'hat' ? 7000 : kind === 'crash' ? 5000 : kind === 'clap' ? 1500 : 1800;
  out.gain.setValueAtTime(kind === 'crash' ? 0.35 : 0.6, t);
  out.gain.exponentialRampToValueAtTime(0.001, t + len);
  n.connect(f).connect(out);
  n.start(t); n.stop(t + len + 0.05);
}

export const sfx = {
  click: () => tone(880, 0.07, 'sine', 0.07, 1.4),
  hover: () => tone(1500, 0.025, 'sine', 0.015),
  hold: () => { tone(520, 0.12, 'triangle', 0.07, 1.5); setTimeout(() => tone(780, 0.14, 'triangle', 0.07, 1.5), 90); },
  open: () => { tone(420, 0.18, 'sine', 0.07, 2); },
  close: () => { tone(700, 0.16, 'sine', 0.06, 0.5); },
  pop: () => tone(300 + Math.random() * 300, 0.12, 'square', 0.05, 2.5),
  grab: () => tone(330, 0.06, 'triangle', 0.06),
};
