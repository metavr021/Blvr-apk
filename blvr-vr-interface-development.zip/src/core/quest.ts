/**
 * Meta Quest 3S–style system features, implemented for real on a phone:
 *  - Toque duplo no óculos → passthrough on/off (accelerometer tap detection, like the Quest double-tap).
 *    Inside the Metaverso a double-tap brings you back to the real world.
 *  - Organizar janelas → open windows lined up side by side in a curve in front of you (Quest multitasking).
 *  - Modo deitado → the current look direction (also up/down) becomes "forward" (lying down / reclined use).
 *  - Modo cinema → dims the passthrough while watching (Quest theater dimming).
 *  - Recentralizar → already in actions.recenter.
 */
import { S } from './store';
import { pose, manual } from './orientation';
import { setAnchor, getAnchor } from './spatial';
import { sfx } from './sound';
import { clamp } from './math';
import { exitMeta } from './meta';
import { WIN_DIST } from './actions';

/* ---------- double-tap on the headset (accelerometer) ---------- */
let inited = false;
let lastSpike = 0;
let lockUntil = 0;
const TAP = 13; // m/s² (linear acceleration) – a knock on the VR Box; normal head turns stay well below

function onMotion(e: DeviceMotionEvent) {
  const st = S();
  if (!st.started || !st.settings.doubleTap) return;
  const a = e.acceleration;
  if (!a || a.x == null || a.y == null || a.z == null) return;
  const now = performance.now();
  if (now < lockUntil) return;
  if (Math.hypot(a.x, a.y, a.z) < TAP) return;
  lockUntil = now + 90; // ignore the ringing of the same knock
  const gap = now - lastSpike;
  if (gap > 110 && gap < 480) { lastSpike = 0; lockUntil = now + 900; onDoubleTap(); }
  else lastSpike = now;
}

function onDoubleTap() {
  const st = S();
  sfx.click();
  if (st.meta) { exitMeta(); return; }
  const v = !st.settings.passthrough;
  st.setSetting('passthrough', v);
  st.toast(v ? 'Passthrough ligado (toque duplo)' : 'Passthrough desligado (toque duplo)', 'info');
}

export function initQuest() {
  if (inited || typeof DeviceMotionEvent === 'undefined') return;
  inited = true;
  window.addEventListener('devicemotion', onMotion, { passive: true });
}

/* ---------- organize windows ---------- */
export function arrangeWindows() {
  const st = S();
  const vis = st.windows.filter((w) => !w.minimized);
  if (!vis.length) { st.toast('Nenhuma janela aberta', 'info'); return; }
  const GAP = 3; // degrees
  const widths = vis.map((w) => {
    const a = getAnchor(`win:${w.id}`);
    const px = (a?.w ?? 1000) * (a?.scale ?? 1.25);
    return ((2 * Math.atan(px / 2 / WIN_DIST)) * 180) / Math.PI;
  });
  const total = widths.reduce((s, x) => s + x, 0) + GAP * (vis.length - 1);
  let yaw = pose.yaw + total / 2;
  const pitch = clamp(pose.pitch, -10, 15);
  vis.forEach((w, i) => {
    yaw -= widths[i] / 2;
    setAnchor(`win:${w.id}`, { yaw, pitch, dist: WIN_DIST });
    yaw -= widths[i] / 2 + GAP;
  });
  st.toast(`${vis.length} janela(s) organizadas lado a lado`, 'ok');
  sfx.open();
}

/* ---------- lying-down mode ---------- */
export function toggleReclined() {
  const st = S();
  if (st.reclined) {
    manual.pitch = 0;
    st.set({ reclined: false });
    st.toast('Modo deitado desligado', 'info');
  } else {
    const devicePitch = pose.pitch - manual.pitch;
    manual.pitch = clamp(-devicePitch, -80, 80);
    st.set({ reclined: true });
    st.toast('Modo deitado: a direção para onde você olha virou a frente', 'ok');
  }
}

/* ---------- theater dimming ---------- */
export function toggleCinemaDim() {
  const v = !S().cinemaDim;
  S().set({ cinemaDim: v });
  S().toast(v ? 'Modo cinema: ambiente escurecido' : 'Modo cinema desligado', 'info');
}
