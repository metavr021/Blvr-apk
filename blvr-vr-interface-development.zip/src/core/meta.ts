/**
 * BLVR Metaverso mode.
 *  - Enter: the camera image is hidden and a virtual world surrounds you; your hands are drawn as neon
 *    outlines (hand tracking stays on – the camera is still used, but only for the hands).
 *  - The Metaverso hub (menus) opens in front of you; palm-up + pinch (non-dominant hand), double-tap or
 *    key H toggles it. The normal BLVR menu, windows, telão and games all work inside the metaverse.
 *  - Exit: restores exactly the previous mode (passthrough / hand tracking as they were).
 */
import { S } from './store';
import { pose } from './orientation';
import { setAnchor } from './spatial';
import { sfx } from './sound';
import { clamp } from './math';
import { closeMenu, closeQuick, openMenu } from './actions';

let prevHandTracking: boolean | null = null;

export function openMetaHub(tab?: ReturnType<typeof S>['metaTab']) {
  setAnchor('metahub', { yaw: pose.yaw, pitch: clamp(pose.pitch, -20, 20) * 0.85, dist: 1400, scale: 1.4 });
  closeMenu();
  closeQuick();
  S().set({ metaHubOpen: true, ...(tab ? { metaTab: tab } : {}) });
  sfx.open();
}
export function closeMetaHub() {
  if (!S().metaHubOpen) return;
  S().set({ metaHubOpen: false });
  sfx.close();
}
export const toggleMetaHub = () => (S().metaHubOpen ? closeMetaHub() : openMetaHub());

export function enterMeta() {
  const st = S();
  if (st.meta) { openMetaHub(); return; }
  prevHandTracking = st.settings.handTracking;
  if (!st.settings.handTracking) st.setSetting('handTracking', true); // neon hands need the camera (hands only)
  closeMenu();
  closeQuick();
  st.set({ meta: true, introDone: true });
  openMetaHub('home');
  st.toast('Bem-vindo ao Metaverso BLVR · palma ↑ + pinça abre o menu do metaverso', 'ok');
}

export function exitMeta() {
  const st = S();
  if (!st.meta) return;
  st.set({ meta: false, metaHubOpen: false });
  if (prevHandTracking !== null && prevHandTracking !== st.settings.handTracking) st.setSetting('handTracking', prevHandTracking);
  prevHandTracking = null;
  sfx.close();
  // Like closing an app: you land back on the BLVR menu (Aplicativos)
  setTimeout(() => openMenu('apps'), 50);
  st.toast('Metaverso fechado', 'info');
}
