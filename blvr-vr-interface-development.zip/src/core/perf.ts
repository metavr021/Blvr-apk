/**
 * Performance governor – keeps BLVR smooth on any phone.
 * Tier 0 = high, 1 = medium, 2 = low. In 'auto' mode the tier starts from a device heuristic
 * (RAM / CPU cores) and adapts to the measured FPS (with hysteresis to avoid oscillation).
 * Only affects cost knobs: overlay resolution, hand-detection rate/size, hover hit-test rate,
 * hand skeleton detail and heavy CSS shadows. Menu layout and 3DOF are untouched.
 */
import { S } from './store';

export const perf = {
  tier: 0,
  dpr: 1.5,
  detectW: 384,
  handCap: 30,
  hoverMs: 33,
  skeleton: true,
};

const DPR = [1.5, 1.1, 0.85];
const DETECT = [384, 288, 224];
const HAND_CAP = [30, 22, 15];
const HOVER = [33, 50, 80];

/**
 * Start LOW on modest phones (≤4 GB RAM, e.g. Oppo A6k / Helio P35 class) and only climb if the
 * device proves it has headroom – starting high and dropping causes visible stutter at launch.
 */
export function heuristicTier(): number {
  const nav = navigator as Navigator & { deviceMemory?: number };
  const mem = nav.deviceMemory ?? 4;
  const cores = navigator.hardwareConcurrency ?? 4;
  if (mem <= 4 || cores <= 4) return 2;
  if (mem <= 6) return 1;
  return 0;
}

export function applyTier(t: number) {
  const tier = Math.max(0, Math.min(2, t));
  perf.tier = tier;
  perf.dpr = Math.min(DPR[tier], window.devicePixelRatio || 1);
  perf.detectW = DETECT[tier];
  perf.handCap = HAND_CAP[tier];
  perf.hoverMs = HOVER[tier];
  perf.skeleton = tier < 2;
  const cl = document.documentElement.classList;
  cl.toggle('perf-1', tier === 1);
  cl.toggle('perf-2', tier === 2);
  if (S().perfTier !== tier) S().set({ perfTier: tier });
}

export function initPerf() {
  const m = S().settings.perfMode;
  applyTier(m === 'high' ? 0 : m === 'low' ? 2 : heuristicTier());
  acc = 0; n = 0; good = 0;
}

let acc = 0, n = 0, good = 0, lastChange = 0, lastDown = 0, upBlockedUntil = 0;

/** Called once per frame with the frame delta (seconds). Cheap. */
export function samplePerf(dt: number, now: number) {
  if (S().settings.perfMode !== 'auto') return;
  acc += dt; n++;
  if (acc < 2) return;
  const fps = n / acc;
  acc = 0; n = 0;
  if (now - lastChange < 3000) return;
  if (fps < 46 && perf.tier < 2) {
    applyTier(perf.tier + 1);
    // Dropped again soon after an upgrade -> this device can't hold the higher tier: stop trying for a while.
    if (now - lastChange < 12000 && lastChange > lastDown) upBlockedUntil = now + 90000;
    lastChange = lastDown = now; good = 0;
  } else if (fps > 58 && perf.tier > 0 && now > upBlockedUntil) {
    if (++good >= 5) { applyTier(perf.tier - 1); lastChange = now; good = 0; }
  } else good = 0;
}
