import { S } from './store';

export type EyeId = 'L' | 'R' | 'M';
export interface EyeReg {
  eye: EyeId;
  stage: HTMLDivElement;
  world: HTMLDivElement;
  root: HTMLDivElement;
  canvas: HTMLCanvasElement;
  /** cursor dot: a tiny DOM layer moved with transform only (compositor-only, no raster per frame) */
  dot: HTMLDivElement;
}

export const eyes = new Map<EyeId, EyeReg>();

/**
 * Shared per-eye viewport geometry (updated by ResizeObserver, never read from layout per frame).
 * P = CSS perspective (px). shift = cursor disparity so the 2D cursor sits at UI depth in stereo.
 */
export const view = { w: 800, h: 600, P: 600, shift: 0, left: 0, top: 0, uiDist: 1400 };

export const isStereo = () => S().settings.displayMode === 'stereo';
export const primaryEye = () => (isStereo() ? eyes.get('L') : eyes.get('M')) ?? null;

const SEL = '[data-hit],[data-drag],[data-hold]';

let ro: ResizeObserver | null = null;
let observed: HTMLElement | null = null;

/** Keep view.w/h/left/top in sync with the primary eye stage without per-frame layout reads. */
export function observePrimary() {
  const pe = primaryEye();
  if (!pe || observed === pe.stage) return;
  if (!ro) ro = new ResizeObserver(() => measure());
  if (observed) ro.unobserve(observed);
  observed = pe.stage;
  ro.observe(pe.stage);
  measure();
}

export function measure() {
  const pe = primaryEye();
  if (!pe) return;
  const r = pe.stage.getBoundingClientRect();
  view.w = r.width || 1;
  view.h = r.height || 1;
  view.left = r.left;
  view.top = r.top;
}
window.addEventListener('resize', () => setTimeout(measure, 50));
window.addEventListener('orientationchange', () => setTimeout(measure, 300));

/** Find the matching element(s) of `el` in all rendered eyes (stereo keeps two identical DOM trees). */
export function mirrors(el: HTMLElement, selector = SEL): HTMLElement[] {
  const out = [el];
  if (!isStereo()) return out;
  const L = eyes.get('L'), R = eyes.get('R');
  if (!L || !R) return out;
  const src = L.root.contains(el) ? L : R.root.contains(el) ? R : null;
  if (!src) return out;
  const dst = src === L ? R : L;
  const idx = Array.prototype.indexOf.call(src.root.querySelectorAll(selector), el);
  if (idx >= 0) {
    const m = dst.root.querySelectorAll(selector)[idx] as HTMLElement | undefined;
    if (m) out.push(m);
  }
  return out;
}

export const INTERACTIVE = SEL;
