/**
 * Input module – unifies hand pointer + pinch, poke, gaze cursor, touch and mouse.
 * Runs in the READ phase of the frame (before any transform is written) so elementFromPoint never
 * forces an extra synchronous layout. Visuals are drawn by core/overlay.ts.
 */
import { S } from './store';
import { handFrame, isHandTrackingActive, FOLLOW, type HandInfo } from './hands';
import { pose, manual } from './orientation';
import { view, isStereo, primaryEye, mirrors, INTERACTIVE } from './view';
import { sfx, unlockAudio } from './sound';
import { perf } from './perf';
import { toggleMetaHub, enterMeta, exitMeta } from './meta';
import { isKbOpen, kbSend } from './keyboard';
import { flushLaunch } from './launcher';
import { craftKey } from './craft';
import { toggleMenu, closeMenu, toggleQuick, closeQuick, recenter, dragStart, dragMove, dragEnd, holdAction, noteKey } from './actions';
import { clamp, DEG } from './math';

export type Source = 'hand' | 'poke' | 'gaze' | 'mouse' | 'touch' | 'none';

export interface Gesture { side: 'left' | 'right' | null; progress: number; x: number; y: number; fired: boolean; lastQuarter: number }
const mkG = (): Gesture => ({ side: null, progress: 0, x: 0, y: 0, fired: false, lastQuarter: 0 });

export const cursor = {
  x: 0.5, y: 0.5, tx: 0.5, ty: 0.5,
  source: 'none' as Source,
  holdProgress: 0,
  dwellProgress: 0,
  pressing: false,
  dragging: false,
  /** pinch point on the hand (stage coords) – only set while the user is actually pinching */
  pinchPt: null as null | { x: number; y: number },
  menuG: mkG(),
  ripples: [] as { x: number; y: number; t: number; big?: boolean }[],
};

let hoverEl: HTMLElement | null = null;
let hoverMirrors: HTMLElement[] = [];
let dwellT = 0;
let dwellLock: HTMLElement | null = null;

export const isHovering = () => hoverEl !== null;

/* ---------- Stereo depth of the cursor ----------
 * The cursor is drawn at the depth of the panel it points at (menu ≈1.4 m, windows 1.5 m, telão 3 m…),
 * so in the VR Box it sits ON the surface instead of floating in front/behind (no double image). */
let hoverDepth = 0;
export function cursorShift(): number {
  if (!isStereo()) return 0;
  const d = hoverDepth || view.uiDist || 1400;
  return ((S().settings.ipd / 2) * view.P) / d;
}

function setHover(el: HTMLElement | null) {
  if (el === hoverEl) return;
  hoverMirrors.forEach((m) => m.removeAttribute('data-hover'));
  const dEl = el?.closest<HTMLElement>('[data-depth]');
  if (dEl) hoverDepth = Number(dEl.dataset.depth) || hoverDepth;
  else if (el) hoverDepth = 0;
  hoverEl = el;
  hoverMirrors = el ? mirrors(el) : [];
  hoverMirrors.forEach((m) => m.setAttribute('data-hover', '1'));
  dwellT = 0;
  if (el !== dwellLock) dwellLock = null;
}

function hitTest(x: number, y: number): { el: HTMLElement | null; raw: Element | null } {
  const e = primaryEye();
  if (!e) return { el: null, raw: null };
  const sx = view.left + x * view.w + cursorShift();
  const sy = view.top + y * view.h;
  const raw = document.elementFromPoint(sx, sy);
  if (!raw || !e.root.contains(raw)) return { el: null, raw: null };
  return { el: raw.closest(INTERACTIVE) as HTMLElement | null, raw };
}

export function cursorAngles() {
  const xpx = (cursor.x - 0.5) * view.w;
  const ypx = (cursor.y - 0.5) * view.h;
  return { yaw: pose.yaw - Math.atan2(xpx, view.P) * DEG, pitch: pose.pitch - Math.atan2(ypx, view.P) * DEG };
}

/* ---------------- Press state machine ---------------- */
type Kind = 'hit' | 'drag' | 'hold' | 'none';
interface Press {
  el: HTMLElement | null; kind: Kind; key: string; t0: number; x0: number; y0: number;
  scrollEl: HTMLElement | null; s0: number; sl0: number; mode: 'pending' | 'drag' | 'scroll' | 'look' | 'done'; real: boolean;
  cx0: number; cy0: number; clicked: boolean;
}
let press: Press | null = null;
let lastEmptyTap = 0;

function kindOf(el: HTMLElement | null): [Kind, string] {
  if (!el) return ['none', ''];
  if (el.hasAttribute('data-drag')) return ['drag', el.dataset.drag || ''];
  if (el.hasAttribute('data-hold')) return ['hold', el.dataset.hold || ''];
  return ['hit', ''];
}

/** Click ripples removed (no hand-tracking animations). Kept as a no-op for call sites. */
function ripple(_big = false, _x = 0, _y = 0) { /* no animation */ }

function click(el: HTMLElement) {
  mirrors(el).forEach((m) => {
    m.setAttribute('data-pressed', '1');
    setTimeout(() => m.removeAttribute('data-pressed'), 260);
  });
  ripple();
  sfx.click();
  el.click();
}

export function pointerDown(real: boolean, cx = 0, cy = 0) {
  if (press) pointerUp();
  let { el, raw } = hitTest(cursor.x, cursor.y);
  // Hand pinch: the act of pinching nudges the hand – use the element that was highlighted just before.
  if (!real && hoverEl && hoverEl.isConnected) { el = hoverEl; raw = hoverEl; }
  const [kind, key] = kindOf(el);
  const scrollEl = (raw?.closest('[data-scroll]') as HTMLElement | null) ?? null;
  press = {
    el, kind, key, t0: performance.now(), x0: cursor.x, y0: cursor.y, scrollEl,
    s0: scrollEl?.scrollTop ?? 0, sl0: scrollEl?.scrollLeft ?? 0, mode: 'pending', real, cx0: cx, cy0: cy, clicked: false,
  };
  cursor.pressing = true;
  if (el) mirrors(el).forEach((m) => m.setAttribute('data-active', '1'));
  // Hand pinch on a plain button (not scrollable, not draggable): click the moment the pinch closes.
  if (!real && kind === 'hit' && el && !scrollEl) { press.clicked = true; press.mode = 'done'; click(el); }
}

export function pointerUp() {
  if (!press) return;
  const p = press;
  press = null;
  cursor.pressing = false;
  cursor.holdProgress = 0;
  if (p.el) mirrors(p.el).forEach((m) => m.removeAttribute('data-active'));
  if (p.mode === 'drag') { dragEnd(); cursor.dragging = false; return; }
  if (p.mode !== 'pending' || p.clicked) return;
  const moved = Math.hypot((cursor.x - p.x0) * view.w, (cursor.y - p.y0) * view.h);
  // Hand pinch released without becoming a scroll/drag -> it was a click.
  if (!p.real && (p.kind === 'hit' || (p.kind === 'drag' && p.el?.hasAttribute('data-hit'))) && p.el) { click(p.el); return; }
  if (p.kind === 'hit' && p.el) {
    const { el } = hitTest(cursor.x, cursor.y);
    if (el === p.el || p.el.contains(el) || moved < 30 || (p.real && performance.now() - p.t0 < 450)) click(p.el);
  } else if (p.kind === 'hold') {
    S().toast('Mantenha a pinça (segure) para confirmar', 'info');
  } else if (p.kind === 'drag' && p.el?.hasAttribute('data-hit')) {
    click(p.el);
  } else if (p.kind === 'none' && p.real) {
    const now = performance.now();
    if (now - lastEmptyTap < 380) { if (S().meta) toggleMetaHub(); else toggleMenu(); lastEmptyTap = 0; } else lastEmptyTap = now;
  }
}

function mirrorScroll(el: HTMLElement) {
  if (!isStereo()) return;
  mirrors(el, '[data-scroll]').slice(1).forEach((m) => { m.scrollTop = el.scrollTop; m.scrollLeft = el.scrollLeft; });
}

/* ---------------- System gestures: palm up + pinch held ---------------- */
function updateGesture(g: Gesture, h: HandInfo | null, dt: number, duration: number, onFire: () => void, busySide: string | null) {
  if (h && h.palmUp && busySide !== h.side) {
    g.side = h.side;
    g.x = (h.pts[8] + h.pts[16]) / 2;
    g.y = (h.pts[9] + h.pts[17]) / 2;
    if (h.pinching && !g.fired) {
      g.progress = Math.min(1, g.progress + dt / duration);
      const q = Math.floor(g.progress * 4);
      if (q > g.lastQuarter && q < 4) { g.lastQuarter = q; sfx.hover(); }
      if (g.progress >= 1) { g.fired = true; onFire(); ripple(true, g.x, g.y); }
    } else if (!h.pinching) {
      g.progress = 0; g.lastQuarter = 0; g.fired = false; // released early -> cancel
    }
  } else {
    g.side = null; g.progress = 0; g.lastQuarter = 0;
    if (!h?.pinching) g.fired = false;
  }
}

/* ---------------- Main update (READ phase of every frame) ---------------- */
let handPressSide: 'left' | 'right' | null = null;
const prevPinch = { left: false, right: false };
const pinchBlocked = { left: false, right: false };
let directPointer: { id: number; type: 'mouse' | 'touch' } | null = null;
let lastMouse = -1e9;
const mousePos = { x: 0.5, y: 0.5 };
const lastHit = { x: -1, y: -1, yaw: 0, pitch: 0, t: 0 };
const pinchPt = { x: 0, y: 0 };
const rs = { fx: 0.5, fy: 0.5, tx: 0.5, ty: 0.5, t0: 0, side: '' as string };
const ex = { x: 0.5, y: 0.5, vx: 0, vy: 0, t: 0, seq: -1, side: '' as string };
let lastHandAt = -1e9;

/** End a press without clicking (hand lost). Drags are finished normally. */
function cancelPress() {
  if (!press) return;
  const p = press;
  press = null;
  cursor.pressing = false;
  cursor.holdProgress = 0;
  if (p.el) mirrors(p.el).forEach((m) => m.removeAttribute('data-active'));
  if (p.mode === 'drag') { dragEnd(); cursor.dragging = false; }
}

export function updateInput(dt: number) {
  const set = S().settings;
  const tracking = isHandTrackingActive();
  const L = tracking ? handFrame.left : null;
  const R = tracking ? handFrame.right : null;
  const hand = (s: 'left' | 'right') => (s === 'left' ? L : R);
  const dom = set.dominantHand;
  const non = dom === 'right' ? 'left' : 'right';
  const now = performance.now();
  const dur = Math.max(0.8, set.menuGestureTime);

  // Non-dominant hand: palm up + pinch held -> BLVR menu.
  // (The dominant hand is ALWAYS a pointer, so its pinch always clicks – the system panel uses the ⋮ button / Q.)
  updateGesture(cursor.menuG, hand(non), dt, dur, () => (S().meta ? toggleMetaHub() : toggleMenu()), handPressSide);

  // A non-dominant pinch that STARTS with the palm up is the menu gesture, never a click.
  const nh = hand(non);
  if (nh && nh.pinching && !prevPinch[non] && nh.palmUp) pinchBlocked[non] = true;
  if (!nh || !nh.pinching) pinchBlocked[non] = false;
  pinchBlocked[dom] = false;

  const nonCand = nh && !nh.palmUp && !pinchBlocked[non] ? nh : null;
  const ph: HandInfo | null = directPointer ? null : (handPressSide ? hand(handPressSide) : null) || hand(dom) || nonCand;

  if (ph) {
    const poke = set.poke && ph.pointing && !handPressSide;
    // Target = stabilized index fingertip (hands.ts: One Euro + sticky deadzone + pinch lock).
    const tx = clamp(ph.ptr.x, 0.01, 0.99), ty = clamp(ph.ptr.y, 0.01, 0.99);
    const fresh = cursor.source !== 'hand' && cursor.source !== 'poke';
    // Render-rate resampling: hand data arrives at 12-30 Hz; instead of jumping (stutter) or lagging
    // (exponential lerp), glide linearly from the shown position to each new sample over a fraction of
    // the measured sample interval → constant-velocity, smooth motion with minimal delay.
    if (set.handFollow === 'instant') {
      // No lag AND no stutter: on a new detection the dot jumps exactly to the fingertip; between detections
      // (phones detect at 10-30 Hz but the screen runs at 60) it keeps moving with the hand's measured velocity
      // (prediction), so it glides instead of stepping. No prediction while pinching (rock-solid clicks).
      if (handFrame.seq !== ex.seq || ph.side !== ex.side) {
        if (ph.side === ex.side && ex.t > 0) {
          const dts = Math.max(16, now - ex.t);
          const cap = 0.004; // max predicted speed: 4 screens / second
          const vx = Math.max(-cap, Math.min(cap, (tx - ex.x) / dts));
          const vy = Math.max(-cap, Math.min(cap, (ty - ex.y) / dts));
          ex.vx = ex.vx * 0.35 + vx * 0.65;
          ex.vy = ex.vy * 0.35 + vy * 0.65;
        } else { ex.vx = 0; ex.vy = 0; }
        ex.x = tx; ex.y = ty; ex.t = now; ex.seq = handFrame.seq; ex.side = ph.side;
      }
      const lead = handPressSide || ph.pinchVal > 0.55 ? 0 : Math.min(now - ex.t, handFrame.interval);
      cursor.x = clamp(ex.x + ex.vx * lead, 0.01, 0.99);
      cursor.y = clamp(ex.y + ex.vy * lead, 0.01, 0.99);
      rs.side = ph.side;
    } else {
      if (fresh || ph.side !== rs.side) { rs.fx = rs.tx = cursor.x = tx; rs.fy = rs.ty = cursor.y = ty; rs.t0 = now; rs.side = ph.side; }
      else if (tx !== rs.tx || ty !== rs.ty) { rs.fx = cursor.x; rs.fy = cursor.y; rs.tx = tx; rs.ty = ty; rs.t0 = now; }
      const interp = (FOLLOW[set.handFollow] ?? FOLLOW.normal).interp;
      const durMs = Math.max(16, handFrame.interval * interp);
      const p = Math.min(1, (now - rs.t0) / durMs);
      cursor.x = rs.fx + (rs.tx - rs.fx) * p;
      cursor.y = rs.fy + (rs.ty - rs.fy) * p;
    }
    cursor.source = poke ? 'poke' : 'hand';
    lastHandAt = now;
    if (ph.pinching) {
      const P = ph.pts;
      pinchPt.x = (P[8] + P[16]) / 2; pinchPt.y = (P[9] + P[17]) / 2;
      cursor.pinchPt = pinchPt;
    } else cursor.pinchPt = null;
    if (ph.pinching && !prevPinch[ph.side] && !pinchBlocked[ph.side] && !press) { handPressSide = ph.side; pointerDown(false); }
    if (!ph.pinching && handPressSide === ph.side) { handPressSide = null; pointerUp(); }
    if (ph.poke && !press) {
      const { el } = hitTest(cursor.x, cursor.y);
      if (el?.hasAttribute('data-hit')) click(el);
    }
  } else if (!directPointer && (cursor.source === 'hand' || cursor.source === 'poke') && now - lastHandAt < 600) {
    // Hand blinked out of the camera for a moment: keep the dot where it is (no jump to the gaze center),
    // and cancel a running pinch WITHOUT clicking (losing the hand is not a release).
    if (handPressSide) { handPressSide = null; cancelPress(); }
    cursor.pinchPt = null;
  } else {
    if (handPressSide) { handPressSide = null; cancelPress(); }
    cursor.pinchPt = null;
    if (directPointer) cursor.source = directPointer.type;
    else if (!isStereo() && now - lastMouse < 4000) { cursor.source = 'mouse'; cursor.x = mousePos.x; cursor.y = mousePos.y; }
    else if (set.gazeCursor) { cursor.source = 'gaze'; cursor.x = 0.5; cursor.y = 0.5; }
    else cursor.source = 'none';
  }
  prevPinch.left = !!L?.pinching;
  prevPinch.right = !!R?.pinching;

  // --- Hover: 3D hit testing is expensive -> only when something moved, rate-limited by the perf tier ---
  if (cursor.source === 'none' && !press) setHover(null);
  else if (!(press && press.mode === 'drag') && (press || now - lastHit.t >= perf.hoverMs)) {
    const moved = Math.abs(cursor.x - lastHit.x) > 0.002 || Math.abs(cursor.y - lastHit.y) > 0.002
      || Math.abs(pose.yaw - lastHit.yaw) > 0.15 || Math.abs(pose.pitch - lastHit.pitch) > 0.15 || now - lastHit.t > 300;
    if (moved) {
      lastHit.x = cursor.x; lastHit.y = cursor.y; lastHit.yaw = pose.yaw; lastHit.pitch = pose.pitch; lastHit.t = now;
      setHover(hitTest(cursor.x, cursor.y).el);
    }
  }

  // --- Press update: hold / drag / scroll ---
  if (press && press.mode !== 'done') {
    const held = (now - press.t0) / 1000;
    const dxp = (cursor.x - press.x0) * view.w;
    const dyp = (cursor.y - press.y0) * view.h;
    const moved = Math.hypot(dxp, dyp);
    if (press.mode === 'pending') {
      if (press.kind === 'drag' && (moved > 8 || held > 0.3)) {
        if (dragStart(press.key, cursorAngles())) { press.mode = 'drag'; cursor.dragging = true; cursor.holdProgress = 0; }
        else press.mode = 'done';
      } else if (press.kind === 'hold') {
        cursor.holdProgress = clamp(held / set.holdTime, 0, 1);
        if (cursor.holdProgress >= 1) { holdAction(press.key); sfx.hold(); ripple(true); press.mode = 'done'; cursor.holdProgress = 0; }
        else if (moved > 50) { press.mode = 'done'; cursor.holdProgress = 0; }
      } else if (press.scrollEl && moved > (press.real ? 12 : Math.max(28, view.h * 0.07))) {
        // Hands jitter: much larger threshold before a pinch becomes a swipe-scroll
        press.mode = 'scroll'; cursor.holdProgress = 0;
      } else if (press.kind === 'hit') {
        cursor.holdProgress = clamp((held - 0.25) / 0.6, 0, 1);
      }
    }
    if (press.mode === 'drag') dragMove(cursorAngles());
    if (press.mode === 'scroll' && press.scrollEl) {
      const f = view.uiDist / view.P;
      const sm = press.scrollEl.dataset.scroll;
      if (sm === 'x' || sm === 'xy') press.scrollEl.scrollLeft = press.sl0 - dxp * f;
      if (sm !== 'x') press.scrollEl.scrollTop = press.s0 - dyp * f;
      mirrorScroll(press.scrollEl);
    }
  }

  // --- Gaze dwell selection ---
  if (cursor.source === 'gaze' && set.gazeSelect === 'dwell' && hoverEl && !press && dwellLock !== hoverEl
    && (hoverEl.hasAttribute('data-hit') || hoverEl.hasAttribute('data-hold'))) {
    dwellT += dt;
    cursor.dwellProgress = clamp(dwellT / set.dwellTime, 0, 1);
    if (cursor.dwellProgress >= 1) {
      const el = hoverEl;
      if (el.hasAttribute('data-hold')) { holdAction(el.dataset.hold || ''); sfx.hold(); ripple(true); }
      else click(el);
      dwellLock = el; dwellT = 0; cursor.dwellProgress = 0;
    }
  } else { cursor.dwellProgress = 0; if (!hoverEl) dwellT = 0; }

  if (cursor.ripples.length) cursor.ripples = cursor.ripples.filter((r) => now - r.t < 450);
}

/* ---------------- Real pointer / keyboard ---------------- */
const toStage = (cx: number, cy: number) => ({ x: (cx - view.left) / view.w, y: (cy - view.top) / view.h });

let lastClient = { x: 0, y: 0 };
let inited = false;

export function initInput() {
  if (inited) return;
  inited = true;
  window.addEventListener('pointerdown', (e) => {
    if (!S().started) return;
    unlockAudio();
    e.preventDefault();
    lastClient = { x: e.clientX, y: e.clientY };
    if (!isStereo()) {
      const p = toStage(e.clientX, e.clientY);
      cursor.x = p.x; cursor.y = p.y;
      directPointer = { id: e.pointerId, type: e.pointerType === 'mouse' ? 'mouse' : 'touch' };
      cursor.source = directPointer.type;
    }
    pointerDown(true, e.clientX, e.clientY);
  }, { passive: false });

  window.addEventListener('pointermove', (e) => {
    if (!S().started) return;
    if (e.pointerType === 'mouse' && !isStereo()) { lastMouse = performance.now(); Object.assign(mousePos, toStage(e.clientX, e.clientY)); }
    if (directPointer && e.pointerId === directPointer.id) Object.assign(cursor, toStage(e.clientX, e.clientY));
    if (press?.real) {
      if (press.mode === 'pending' && press.kind === 'none' && !press.scrollEl && Math.hypot(e.clientX - press.cx0, e.clientY - press.cy0) > 6) press.mode = 'look';
      if (press.mode === 'look') {
        manual.yaw += ((e.clientX - lastClient.x) / view.P) * DEG * 0.9;
        manual.pitch = clamp(manual.pitch + ((e.clientY - lastClient.y) / view.P) * DEG * 0.9, -80, 80);
      }
    }
    lastClient = { x: e.clientX, y: e.clientY };
  }, { passive: true });

  const up = (e: PointerEvent) => {
    if (!S().started) return;
    if (press?.real) pointerUp();
    flushLaunch(); // real tap = user gesture → run an Android app launch requested by pinch
    if (directPointer && e.pointerId === directPointer.id) directPointer = null;
  };
  window.addEventListener('pointerup', up);
  window.addEventListener('pointercancel', up);

  // Only synthetic clicks (from the BLVR input system) reach the UI – unifies hand, gaze, touch and mouse.
  document.addEventListener('click', (e) => {
    if (S().started && e.isTrusted) { e.preventDefault(); e.stopPropagation(); }
  }, true);
  window.addEventListener('contextmenu', (e) => { if (S().started) e.preventDefault(); });

  document.addEventListener('scroll', (e) => {
    const t = e.target as HTMLElement;
    if (t instanceof HTMLElement && t.hasAttribute('data-scroll')) mirrorScroll(t);
  }, true);

  window.addEventListener('keydown', (e) => {
    const st = S();
    if (!st.started) return;
    // Physical / Bluetooth keyboard → whatever the floating keyboard is typing into (YouTube, Navegador, Twitch, Notas)
    const kbOpen = isKbOpen();
    const focusedWin = st.windows.find((w) => w.id === st.focused && !w.minimized);
    const typingNotes = !kbOpen && focusedWin?.app === 'notes';
    if (kbOpen || typingNotes) {
      const fn = kbOpen ? kbSend : noteKey;
      if (e.key === 'Backspace') { fn('⌫'); e.preventDefault(); return; }
      if (e.key === 'Enter') { fn('↵'); e.preventDefault(); return; }
      if (e.key.length === 1 && !e.ctrlKey && !e.metaKey) { fn(e.key); e.preventDefault(); return; }
    }
    // BLVR Craft focused (and menu closed): WASD / arrows / Q-E / 1-9 / F go to the game
    if (!kbOpen && !st.menuOpen && focusedWin?.app === 'craft' && !e.ctrlKey && !e.metaKey && craftKey(e.key)) { e.preventDefault(); return; }
    if (e.key === 'm' || e.key === 'M') toggleMenu();
    else if (e.key === 'q' || e.key === 'Q') toggleQuick();
    else if (e.key === 'h' || e.key === 'H') { if (S().meta) toggleMetaHub(); }
    else if (e.key === 'v' || e.key === 'V') { if (S().meta) exitMeta(); else enterMeta(); }
    else if (e.key === 'Escape') { closeMenu(); closeQuick(); }
    else if (e.key === 'r' || e.key === 'R') recenter();
    else if (e.key === 'ArrowLeft') manual.yaw += 6;
    else if (e.key === 'ArrowRight') manual.yaw -= 6;
    else if (e.key === 'ArrowUp') manual.pitch = clamp(manual.pitch + 5, -80, 80);
    else if (e.key === 'ArrowDown') manual.pitch = clamp(manual.pitch - 5, -80, 80);
    else if ((e.key === 'Enter' || e.key === ' ') && !e.repeat) { unlockAudio(); pointerDown(false); e.preventDefault(); }
  });
  window.addEventListener('keyup', (e) => {
    if (!S().started) return;
    if (e.key === 'Enter' || e.key === ' ') pointerUp();
  });
}
