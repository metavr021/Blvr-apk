import { memo } from 'react';
import { useStore } from '../core/store';

const SEG = 16;
const R = 2400;
const TOP = -1700;
const BOTTOM = 1250;
const H = BOTTOM - TOP;
const SEG_W = 2 * R * Math.tan(Math.PI / SEG);
const HALF_W = SEG_W / 2 + 1.5;
const HALF_H = H / 2;
const YC = (TOP + BOTTOM) / 2;

function EnvironmentInner() {
  const env = useStore((s) => s.settings.environment);
  const filter = env === 'night' ? 'brightness(.32) saturate(.7) hue-rotate(-25deg) contrast(1.1)' : 'none';
  return (
    <>
      {Array.from({ length: SEG }).map((_, i) => {
        const yaw = (SEG / 2 - 0.5 - i) * (360 / SEG);
        const mirrored = i >= SEG / 2;
        const idx = mirrored ? SEG - 1 - i : i;
        return (
          <div
            key={i}
            className="absolute left-0 top-0"
            style={{
              width: HALF_W, height: HALF_H, marginLeft: -HALF_W / 2, marginTop: -HALF_H / 2,
              transform: `rotateY(${yaw}deg) translateY(${YC}px) translateZ(${-R}px) scale(${mirrored ? -2 : 2}, 2)`,
              backgroundImage: env === 'void' ? 'linear-gradient(#05060a, #0b0f1c 60%, #05060a)' : 'url(env/panorama.jpg)',
              backgroundSize: `${(SEG / 2) * (HALF_W - 1.5)}px 100%`,
              backgroundPosition: `${-idx * (HALF_W - 1.5)}px 0`,
              filter,
            }}
          />
        );
      })}
      {env === 'night' && (
        <div
          className="absolute left-0 top-0 rounded-full"
          style={{
            width: 800, height: 800, marginLeft: -400, marginTop: -400,
            transform: `translateY(${TOP + 20}px) rotateX(-90deg) scale(6)`,
            background: 'radial-gradient(circle, #0a1030 0, #050818 70%, transparent 71%)',
            boxShadow: 'inset 0 0 0 0 transparent',
          }}
        >
          {Array.from({ length: 60 }).map((_, i) => (
            <span key={i} className="absolute rounded-full bg-white" style={{
              width: 1, height: 1, left: `${50 + 34 * Math.cos(i * 2.39) * Math.sqrt((i % 10) / 10)}%`,
              top: `${50 + 34 * Math.sin(i * 2.39) * Math.sqrt((i % 10) / 10)}%`, opacity: 0.4 + (i % 5) / 8,
            }} />
          ))}
        </div>
      )}
      {/* Ceiling ring with warm LED edge */}
      <div
        className="absolute left-0 top-0 rounded-full"
        style={{
          // 800px texture ×6 (was 1600×3): same look, 1/4 of the GPU memory (smooth gradients upscale cleanly)
          width: 800, height: 800, marginLeft: -400, marginTop: -400,
          transform: `translateY(${-1250}px) rotateX(-90deg) scale(6)`,
          background: env === 'void'
            ? 'radial-gradient(circle, transparent 0 40%, rgba(59,130,246,.35) 41%, #0a0d16 43%, #05060a 70%, transparent 71%)'
            : 'radial-gradient(circle, transparent 0 36%, rgba(251,191,36,.75) 37%, rgba(120,72,40,.9) 38.5%, #2a1c15 41%, #1a110c 69%, transparent 70%)',
        }}
      />
      <Floor />
    </>
  );
}

function Floor({ dim }: { dim?: boolean }) {
  const env = useStore((s) => s.settings.environment);
  return (
    <div
      className="absolute left-0 top-0 rounded-full"
      style={{
        width: 800, height: 800, marginLeft: -400, marginTop: -400,
        transform: `translateY(${BOTTOM - 40}px) rotateX(90deg) scale(6)`,
        opacity: dim ? 0.35 : 1,
        background: env === 'void'
          ? 'radial-gradient(circle, #10162a 0, #0a0e1a 14%, rgba(59,130,246,.4) 14.4%, #070a12 15%, #05060a 60%, transparent 70%)'
          : 'radial-gradient(circle, #16110e 0, #231a15 13%, #3a2a20 13.5%, #2c211a 22%, #3d2c22 40%, #2a1e17 62%, rgba(25,17,12,.95) 69%, transparent 70%)',
      }}
    />
  );
}

export const Environment = memo(EnvironmentInner);
