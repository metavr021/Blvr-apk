import { useContext, useEffect, useRef } from 'react';
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight, RotateCcw, RotateCw, ChevronsUp, ChevronsDown, Pickaxe, Box as BoxIcon, Plane, Footprints, Eye, ExternalLink } from 'lucide-react';
import {
  useCraft, ensureWorld, CraftRenderer, attachRenderer, detachRenderer, mirrors, request, move, turn, tilt, act,
  toggleFly, PALETTE, NAMES, swatch, GLASS,
} from '../../core/craft';
import { perf } from '../../core/perf';
import { launchAndroid } from '../../core/launcher';
import { Btn, EyeCtx } from '../ui';
import { useDeferred } from './MediaApps';
import { cn } from '../../utils/cn';

/**
 * BLVR Craft window. Look around: pinch + hold on the view and drag (or touch-drag).
 * Tap / pinch on the view = break or place (mode) at the crosshair. Big buttons for walking.
 */
function Pad({ onClick, title, children, className }: { onClick: () => void; title: string; children: React.ReactNode; className?: string }) {
  return (
    <Btn onClick={onClick} title={title} className={cn('hv flex h-[58px] w-[64px] shrink-0 items-center justify-center rounded-2xl bg-white/10 text-white', className)}>
      {children}
    </Btn>
  );
}

export function CraftApp() {
  const eye = useContext(EyeCtx);
  const master = eye !== 'R';
  const ui = useCraft();
  const ok = useDeferred();
  const wrap = useRef<HTMLDivElement>(null);
  const cv = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!ok) return;
    ensureWorld();
    const c = cv.current, w = wrap.current;
    if (!c || !w) return;
    if (!master) { mirrors.add(c); request(); return () => { mirrors.delete(c); }; }
    const size = () => {
      const s = [0.75, 0.6, 0.5][perf.tier] ?? 0.6;
      const cw = Math.max(64, Math.round(w.clientWidth * s)), ch = Math.max(64, Math.round(w.clientHeight * s));
      if (c.width !== cw || c.height !== ch) { c.width = cw; c.height = ch; }
    };
    size();
    let r: CraftRenderer | null = null;
    try { r = new CraftRenderer(c); attachRenderer(r); useCraft.setState({ err: '' }); }
    catch (e) { useCraft.setState({ err: (e as Error)?.message || 'WebGL indisponível' }); }
    const ro = new ResizeObserver(() => { size(); request(); });
    ro.observe(w);
    return () => { ro.disconnect(); if (r) { detachRenderer(r); r.destroy(); } };
  }, [ok, master]);

  return (
    <div className="flex h-full flex-col">
      {/* block palette + mode */}
      <div data-scroll="x" className="flex shrink-0 items-center gap-2 overflow-x-auto border-b border-white/10 px-3 py-2.5">
        <Btn onClick={() => useCraft.setState({ mode: ui.mode === 'place' ? 'break' : 'place' })} title="Trocar ação"
          className={cn('hv flex h-[52px] shrink-0 items-center gap-2 rounded-2xl px-4 text-[16px] font-semibold text-white', ui.mode === 'break' ? 'bg-red-600' : 'bg-emerald-600')}>
          {ui.mode === 'break' ? <><Pickaxe size={22} /> Quebrar</> : <><BoxIcon size={22} /> Colocar</>}
        </Btn>
        <div className="mx-1 h-8 w-px shrink-0 bg-white/15" />
        {PALETTE.map((b, i) => (
          <Btn key={b} onClick={() => useCraft.setState({ sel: b, mode: 'place' })} title={`${NAMES[b]} (${i + 1})`}
            className={cn('hv flex h-[52px] w-[52px] shrink-0 items-end justify-center rounded-xl pb-0.5 text-[10px] font-semibold text-black/70', ui.sel === b && ui.mode === 'place' ? 'ring-4 ring-white' : 'ring-1 ring-black/30')}
            style={{ background: `linear-gradient(${swatch(b, 0)} 0 45%, ${swatch(b, 1)} 45%)`, opacity: b === GLASS ? 0.85 : 1 }}>
            {i + 1}
          </Btn>
        ))}
      </div>

      {/* 3D view */}
      <div ref={wrap} className="relative min-h-0 flex-1 overflow-hidden bg-[#87bff2]">
        <canvas ref={cv} className="h-full w-full" style={{ imageRendering: 'pixelated' }} />
        <Btn drag="craftLook" onClick={act} title="Segure e arraste para olhar · toque para quebrar/colocar" className="absolute inset-0 cursor-crosshair" />
        <div className="pointer-events-none absolute left-1/2 top-1/2 h-7 w-7 -translate-x-1/2 -translate-y-1/2">
          <div className="absolute left-1/2 top-0 h-full w-[3px] -translate-x-1/2 bg-white/90 shadow" />
          <div className="absolute left-0 top-1/2 h-[3px] w-full -translate-y-1/2 bg-white/90 shadow" />
        </div>
        <div className="pointer-events-none absolute left-3 top-3 rounded-lg bg-black/45 px-3 py-1 text-[13px] tabular-nums text-white/90">
          {ui.fly ? 'Voando' : 'Andando'} · {ui.hud} · {NAMES[ui.sel]}
        </div>
        {ui.err && <div className="absolute inset-0 flex items-center justify-center bg-black/80 p-8 text-center text-red-300">{ui.err}</div>}
      </div>

      {/* controls */}
      <div className="flex shrink-0 items-center gap-2 bg-[#0d1322] px-3 py-2.5">
        <Pad onClick={() => turn(30)} title="Girar à esquerda"><RotateCcw size={26} /></Pad>
        <Pad onClick={() => move(0, -1, 0)} title="Esquerda"><ArrowLeft size={28} /></Pad>
        <Pad onClick={() => move(1, 0, 0)} title="Frente" className="bg-white/20"><ArrowUp size={30} /></Pad>
        <Pad onClick={() => move(-1, 0, 0)} title="Trás"><ArrowDown size={28} /></Pad>
        <Pad onClick={() => move(0, 1, 0)} title="Direita"><ArrowRight size={28} /></Pad>
        <Pad onClick={() => turn(-30)} title="Girar à direita"><RotateCw size={26} /></Pad>
        <div className="mx-1 h-10 w-px shrink-0 bg-white/15" />
        <Pad onClick={() => tilt(15)} title="Olhar para cima"><Eye size={20} /><ArrowUp size={16} /></Pad>
        <Pad onClick={() => tilt(-15)} title="Olhar para baixo"><Eye size={20} /><ArrowDown size={16} /></Pad>
        {ui.fly && <>
          <Pad onClick={() => move(0, 0, 1)} title="Subir"><ChevronsUp size={28} /></Pad>
          <Pad onClick={() => move(0, 0, -1)} title="Descer"><ChevronsDown size={28} /></Pad>
        </>}
        <Btn onClick={toggleFly} title="Voar / andar" className={cn('hv flex h-[58px] shrink-0 items-center gap-2 rounded-2xl px-4 text-[15px] text-white', ui.fly ? 'bg-sky-600' : 'bg-white/10')}>
          {ui.fly ? <><Plane size={20} /> Voar</> : <><Footprints size={20} /> Andar</>}
        </Btn>
        <div className="flex-1" />
        <Btn hold="craftnew" title="Segure para gerar um mundo novo" className="hv flex h-[58px] shrink-0 items-center rounded-2xl bg-white/10 px-4 text-[14px] text-white">Novo mundo (segure)</Btn>
        <Btn onClick={() => launchAndroid('minecraft')} title="Minecraft oficial (app do celular)" className="hv flex h-[58px] shrink-0 items-center gap-2 rounded-2xl bg-white/10 px-4 text-[14px] text-white">
          <ExternalLink size={18} /> Minecraft oficial
        </Btn>
      </div>
    </div>
  );
}
