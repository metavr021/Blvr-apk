import { useContext, useEffect, useLayoutEffect, useRef } from 'react';
import { create } from 'zustand';
import { Plus, Minus, Map as MapIcon, Satellite, Loader2 } from 'lucide-react';
import { Btn, EyeCtx } from '../ui';
import { cn } from '../../utils/cn';

/**
 * Native slippy map (no iframe) → pan by pinch-drag / swipe, zoom with buttons, works with hand tracking.
 * Renders a 9×7 grid of 256 px tiles around the center inside a scroll container (data-scroll="xy");
 * when you pan ≥2 tiles the grid re-centers seamlessly. State is global (both stereo eyes identical).
 */
const T = 256, HX = 4, HY = 3; // grid half sizes → 9 × 7 tiles
type Key = 'maps' | 'radar';
interface MapSt { cx: number; cy: number; z: number; rev: number; layer: 'osm' | 'sat' }
interface Radar { host: string; path: string; time: number; loading: boolean; error: string }
const lonX = (lon: number, z: number) => ((lon + 180) / 360) * 2 ** z;
const latY = (lat: number, z: number) => { const r = (lat * Math.PI) / 180; return ((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2) * 2 ** z; };

export const useMaps = create<{ maps: MapSt; radar: MapSt; rad: Radar }>(() => ({
  maps: { cx: lonX(-46.63, 12), cy: latY(-23.55, 12), z: 12, rev: 1, layer: 'osm' },
  radar: { cx: lonX(-50, 5), cy: latY(-15, 5), z: 5, rev: 1, layer: 'osm' },
  rad: { host: '', path: '', time: 0, loading: false, error: '' },
}));
const M = () => useMaps.getState();
const setM = (k: Key, p: Partial<MapSt>) => useMaps.setState({ [k]: { ...M()[k], ...p } } as Pick<ReturnType<typeof M>, Key>);

export function centerOn(k: Key, lat: number, lon: number, z?: number) {
  const zz = z ?? M()[k].z;
  setM(k, { z: zz, cx: lonX(lon, zz), cy: latY(lat, zz), rev: M()[k].rev + 1 });
}

async function radarLoad() {
  if (M().rad.loading) return;
  useMaps.setState({ rad: { ...M().rad, loading: true, error: '' } });
  try {
    const r = await fetch('https://api.rainviewer.com/public/weather-maps.json');
    const j = (await r.json()) as { host: string; radar: { past: { time: number; path: string }[] } };
    const last = j.radar.past[j.radar.past.length - 1];
    useMaps.setState({ rad: { host: j.host, path: last.path, time: last.time, loading: false, error: '' } });
  } catch {
    useMaps.setState({ rad: { ...M().rad, loading: false, error: 'Radar indisponível agora (sem internet?).' } });
  }
}

function TileMap({ k, base, overlay, minZ, maxZ, attribution }: {
  k: Key; base: (z: number, x: number, y: number) => string; overlay?: (z: number, x: number, y: number) => string;
  minZ: number; maxZ: number; attribution: string;
}) {
  const eye = useContext(EyeCtx);
  const st = useMaps((s) => s[k]);
  const ref = useRef<HTMLDivElement>(null);
  const ix = Math.floor(st.cx), iy = Math.floor(st.cy);
  const last = useRef({ ix, iy, rev: -1 });

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const L = last.current;
    if (L.rev !== st.rev) {
      el.scrollLeft = (st.cx - (ix - HX)) * T - el.clientWidth / 2;
      el.scrollTop = (st.cy - (iy - HY)) * T - el.clientHeight / 2;
    } else if (L.ix !== ix || L.iy !== iy) {
      el.scrollLeft -= (ix - L.ix) * T;
      el.scrollTop -= (iy - L.iy) * T;
    }
    last.current = { ix, iy, rev: st.rev };
  }, [ix, iy, st.rev, st.cx, st.cy]);

  const viewCenter = () => {
    const el = ref.current;
    if (!el) return { x: st.cx, y: st.cy };
    return { x: ix - HX + (el.scrollLeft + el.clientWidth / 2) / T, y: iy - HY + (el.scrollTop + el.clientHeight / 2) / T };
  };
  const onScroll = () => {
    if (eye === 'R') return; // left/mono eye drives the re-centering (scroll is mirrored to the right eye)
    const c = viewCenter();
    if (Math.abs(Math.floor(c.x) - ix) >= 2 || Math.abs(Math.floor(c.y) - iy) >= 2) setM(k, { cx: c.x, cy: Math.max(0, Math.min(2 ** st.z, c.y)) });
  };
  const zoom = (d: number) => {
    const z = Math.max(minZ, Math.min(maxZ, st.z + d));
    if (z === st.z) return;
    const c = viewCenter();
    const f = 2 ** (z - st.z);
    setM(k, { z, cx: c.x * f, cy: c.y * f, rev: st.rev + 1 });
  };

  const n = 2 ** st.z;
  const tiles: { key: string; left: number; top: number; x: number; y: number }[] = [];
  for (let r = 0; r <= HY * 2; r++) for (let c = 0; c <= HX * 2; c++) {
    const y = iy - HY + r;
    if (y < 0 || y >= n) continue;
    const x = (((ix - HX + c) % n) + n) % n;
    tiles.push({ key: `${st.z}-${x}-${y}-${c}`, left: c * T, top: r * T, x, y });
  }

  return (
    <div className="relative min-h-0 flex-1 overflow-hidden bg-[#1b2430]">
      <div ref={ref} data-scroll="xy" onScroll={onScroll} className="h-full w-full overflow-hidden">
        <div className="relative" style={{ width: (HX * 2 + 1) * T, height: (HY * 2 + 1) * T }}>
          {tiles.map((t) => <img key={t.key} src={base(st.z, t.x, t.y)} alt="" draggable={false} loading="lazy" className="absolute" style={{ left: t.left, top: t.top, width: T, height: T }} />)}
          {overlay && tiles.map((t) => <img key={'o' + t.key} src={overlay(st.z, t.x, t.y)} alt="" draggable={false} loading="lazy" className="absolute opacity-80" style={{ left: t.left, top: t.top, width: T, height: T }} />)}
        </div>
      </div>
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-5 w-5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white/80" />
      <div className="absolute right-3 top-3 flex flex-col gap-2">
        <Btn onClick={() => zoom(1)} title="Aproximar" className="hv flex h-14 w-14 items-center justify-center rounded-2xl bg-[#0d1322]/90 text-white"><Plus size={28} /></Btn>
        <Btn onClick={() => zoom(-1)} title="Afastar" className="hv flex h-14 w-14 items-center justify-center rounded-2xl bg-[#0d1322]/90 text-white"><Minus size={28} /></Btn>
        <div className="rounded-xl bg-[#0d1322]/90 py-1 text-center text-[12px] text-white/70">z{st.z}</div>
      </div>
      <div className="absolute bottom-0 right-0 rounded-tl-lg bg-black/60 px-2 py-0.5 text-[11px] text-white/70">{attribution}</div>
    </div>
  );
}

/* ============================ Mapas ============================ */
const CITIES = [
  { n: 'São Paulo', lat: -23.55, lon: -46.63 }, { n: 'Rio de Janeiro', lat: -22.91, lon: -43.17 }, { n: 'Brasília', lat: -15.79, lon: -47.88 },
  { n: 'Salvador', lat: -12.97, lon: -38.5 }, { n: 'Lisboa', lat: 38.72, lon: -9.14 }, { n: 'Nova York', lat: 40.71, lon: -74.0 },
  { n: 'Tóquio', lat: 35.68, lon: 139.76 }, { n: 'Paris', lat: 48.86, lon: 2.35 },
];
export function MapsApp() {
  const layer = useMaps((s) => s.maps.layer);
  const here = () => navigator.geolocation?.getCurrentPosition((p) => centerOn('maps', p.coords.latitude, p.coords.longitude, 15), () => undefined, { timeout: 8000 });
  return (
    <div className="flex h-full flex-col">
      <div data-scroll="x" className="flex shrink-0 gap-2 overflow-x-auto border-b border-white/10 px-4 py-3">
        <Btn onClick={() => setM('maps', { layer: layer === 'osm' ? 'sat' : 'osm' })} className="hv flex shrink-0 items-center gap-2 rounded-full bg-emerald-600 px-4 py-2 text-[14px] text-white">
          {layer === 'osm' ? <><Satellite size={16} /> Satélite</> : <><MapIcon size={16} /> Mapa</>}
        </Btn>
        <Btn onClick={here} className="hv shrink-0 rounded-full bg-white/10 px-4 py-2 text-[14px] text-white">📍 Onde estou</Btn>
        {CITIES.map((c) => (
          <Btn key={c.n} onClick={() => centerOn('maps', c.lat, c.lon, 13)} className="hv shrink-0 rounded-full bg-white/10 px-4 py-2 text-[14px] text-white/85">{c.n}</Btn>
        ))}
      </div>
      <TileMap k="maps" minZ={3} maxZ={18}
        base={layer === 'osm'
          ? (z, x, y) => `https://tile.openstreetmap.org/${z}/${x}/${y}.png`
          : (z, x, y) => `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${x}`}
        attribution={layer === 'osm' ? '© OpenStreetMap' : 'Imagens © Esri'} />
      <div className="shrink-0 bg-white/5 px-4 py-1.5 text-center text-[12px] text-white/50">Segure a pinça e arraste para mover o mapa · + / − para zoom</div>
    </div>
  );
}

/* ============================ Radar (Clima) ============================ */
export function RadarView({ lat, lon }: { lat?: number; lon?: number }) {
  const eye = useContext(EyeCtx);
  const rad = useMaps((s) => s.rad);
  useEffect(() => { if (eye !== 'R' && !M().rad.path) void radarLoad(); }, [eye]);
  useEffect(() => { if (eye !== 'R' && lat !== undefined && lon !== undefined) centerOn('radar', lat, lon, 6); }, [eye, lat, lon]);
  return (
    <div className="relative flex min-h-0 flex-1 flex-col">
      <TileMap k="radar" minZ={3} maxZ={7}
        base={(z, x, y) => `https://basemaps.cartocdn.com/dark_all/${z}/${x}/${y}.png`}
        overlay={rad.path ? (z, x, y) => `${rad.host}${rad.path}/256/${z}/${x}/${y}/2/1_1.png` : undefined}
        attribution="Radar © RainViewer · mapa © CARTO/OSM" />
      <div className={cn('pointer-events-none absolute left-3 top-3 rounded-xl bg-[#0d1322]/90 px-3 py-1.5 text-[13px]', rad.error ? 'text-red-300' : 'text-white/75')}>
        {rad.loading ? <span className="flex items-center gap-2"><Loader2 size={14} className="animate-spin" /> Carregando radar…</span>
          : rad.error || (rad.time ? `Chuva às ${new Date(rad.time * 1000).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}` : '')}
      </div>
    </div>
  );
}
