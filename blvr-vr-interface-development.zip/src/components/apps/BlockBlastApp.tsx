import { useState, useEffect, useRef } from 'react';
import { RotateCcw, Trophy, Star, Sparkles, Flame, Check, ArrowRight, Zap, Target, Gem, Snowflake, Grid3x3 } from 'lucide-react';
import { playNote, sfx } from '../../core/sound';
import { Btn } from '../ui';
import { cn } from '../../utils/cn';

/* =========================================================================
 * BLOCK BLAST 3D – VR FLOATING PUZZLE ENGINE
 * ========================================================================= */

const GRID_SIZE = 8;

export type BlockType =
  | 'cyan'
  | 'blue'
  | 'purple'
  | 'magenta'
  | 'amber'
  | 'emerald'
  | 'red'
  | 'lime'
  | 'gem'
  | 'ice1'
  | 'ice2'
  | 'fixed';

export interface GridCell {
  type: BlockType;
  color: string;
  hasGem?: boolean;
  ice?: number; // 2 = double ice, 1 = cracked ice
  isBlasting?: boolean;
}

export interface PieceShape {
  id: string;
  matrix: number[][]; // 1 for filled, 0 for empty
  color: BlockType;
}

export interface LevelConfig {
  level: number;
  name: string;
  desc: string;
  targetScore: number;
  goalType: 'score' | 'lines' | 'gems' | 'ice' | 'combo' | 'moves';
  goalTarget: number;
  maxMoves?: number;
  initialGrid?: { r: number; c: number; type: BlockType; hasGem?: boolean; ice?: number }[];
}

export const LEVELS: LevelConfig[] = [
  {
    level: 1,
    name: 'Fase 1: Iniciação',
    desc: 'Limpe 2 linhas completas para aprender o básico do Blast.',
    targetScore: 400,
    goalType: 'lines',
    goalTarget: 2,
  },
  {
    level: 2,
    name: 'Fase 2: Caça às Gemas',
    desc: 'Exploda as linhas correspondentes para coletar 4 Diamantes.',
    targetScore: 700,
    goalType: 'gems',
    goalTarget: 4,
    initialGrid: [
      { r: 2, c: 2, type: 'purple', hasGem: true },
      { r: 2, c: 5, type: 'purple', hasGem: true },
      { r: 5, c: 2, type: 'purple', hasGem: true },
      { r: 5, c: 5, type: 'purple', hasGem: true },
    ],
  },
  {
    level: 3,
    name: 'Fase 3: Combo Mania',
    desc: 'Mantenha o ritmo e alcance um Combo x2 consecutivo.',
    targetScore: 1000,
    goalType: 'combo',
    goalTarget: 2,
  },
  {
    level: 4,
    name: 'Fase 4: Gelo Polar',
    desc: 'Limpe linhas adjacentes para derreter 6 blocos de gelo.',
    targetScore: 1400,
    goalType: 'ice',
    goalTarget: 6,
    initialGrid: [
      { r: 3, c: 2, type: 'cyan', ice: 1 },
      { r: 3, c: 3, type: 'cyan', ice: 1 },
      { r: 3, c: 4, type: 'cyan', ice: 1 },
      { r: 4, c: 2, type: 'cyan', ice: 1 },
      { r: 4, c: 3, type: 'cyan', ice: 1 },
      { r: 4, c: 4, type: 'cyan', ice: 1 },
    ],
  },
  {
    level: 5,
    name: 'Fase 5: Cruz de Cristal',
    desc: 'Colete 6 Gemas nos cantos da cruz de obsidiana.',
    targetScore: 1800,
    goalType: 'gems',
    goalTarget: 6,
    initialGrid: [
      { r: 1, c: 1, type: 'magenta', hasGem: true },
      { r: 1, c: 6, type: 'magenta', hasGem: true },
      { r: 6, c: 1, type: 'magenta', hasGem: true },
      { r: 6, c: 6, type: 'magenta', hasGem: true },
      { r: 3, c: 3, type: 'magenta', hasGem: true },
      { r: 4, c: 4, type: 'magenta', hasGem: true },
      { r: 3, c: 0, type: 'fixed' },
      { r: 3, c: 7, type: 'fixed' },
      { r: 0, c: 3, type: 'fixed' },
      { r: 7, c: 3, type: 'fixed' },
    ],
  },
  {
    level: 6,
    name: 'Fase 6: Sob Pressão',
    desc: 'Alcance 1.800 pontos usando no máximo 22 jogadas!',
    targetScore: 1800,
    goalType: 'moves',
    goalTarget: 1800,
    maxMoves: 22,
  },
  {
    level: 7,
    name: 'Fase 7: Permafrost',
    desc: 'Derreta todos os 8 blocos de Gelo Duplo (requerem 2 explosões).',
    targetScore: 2400,
    goalType: 'ice',
    goalTarget: 8,
    initialGrid: [
      { r: 1, c: 3, type: 'cyan', ice: 2 },
      { r: 1, c: 4, type: 'cyan', ice: 2 },
      { r: 3, c: 1, type: 'cyan', ice: 2 },
      { r: 4, c: 1, type: 'cyan', ice: 2 },
      { r: 3, c: 6, type: 'cyan', ice: 2 },
      { r: 4, c: 6, type: 'cyan', ice: 2 },
      { r: 6, c: 3, type: 'cyan', ice: 2 },
      { r: 6, c: 4, type: 'cyan', ice: 2 },
    ],
  },
  {
    level: 8,
    name: 'Fase 8: Tempestade de Combos',
    desc: 'Faça um super Combo x3 consecutivo para vencer!',
    targetScore: 2800,
    goalType: 'combo',
    goalTarget: 3,
  },
  {
    level: 9,
    name: 'Fase 9: Fortaleza de Obsidiana',
    desc: 'Navegue pelos obstáculos densos e faça 3.200 pontos.',
    targetScore: 3200,
    goalType: 'score',
    goalTarget: 3200,
    initialGrid: [
      { r: 2, c: 2, type: 'fixed' },
      { r: 2, c: 5, type: 'fixed' },
      { r: 5, c: 2, type: 'fixed' },
      { r: 5, c: 5, type: 'fixed' },
      { r: 0, c: 0, type: 'amber', hasGem: true },
      { r: 0, c: 7, type: 'amber', hasGem: true },
      { r: 7, c: 0, type: 'amber', hasGem: true },
      { r: 7, c: 7, type: 'amber', hasGem: true },
    ],
  },
  {
    level: 10,
    name: 'Fase 10: Mestre do Blast',
    desc: 'O desafio supremo: 8 Gemas + 6 Gelos em até 26 jogadas!',
    targetScore: 4000,
    goalType: 'gems',
    goalTarget: 8,
    maxMoves: 26,
    initialGrid: [
      { r: 1, c: 1, type: 'magenta', hasGem: true },
      { r: 1, c: 6, type: 'magenta', hasGem: true },
      { r: 6, c: 1, type: 'magenta', hasGem: true },
      { r: 6, c: 6, type: 'magenta', hasGem: true },
      { r: 2, c: 2, type: 'cyan', ice: 2 },
      { r: 2, c: 5, type: 'cyan', ice: 2 },
      { r: 5, c: 2, type: 'cyan', ice: 2 },
      { r: 5, c: 5, type: 'cyan', ice: 2 },
      { r: 3, c: 3, type: 'purple', hasGem: true },
      { r: 3, c: 4, type: 'purple', hasGem: true },
      { r: 4, c: 3, type: 'purple', hasGem: true },
      { r: 4, c: 4, type: 'purple', hasGem: true },
    ],
  },
];

/* =========================================================================
 * Piece Templates
 * ========================================================================= */

const SHAPES: { matrix: number[][]; color: BlockType }[] = [
  // 1-blocks
  { matrix: [[1]], color: 'amber' },

  // 2-blocks
  { matrix: [[1, 1]], color: 'cyan' },
  { matrix: [[1], [1]], color: 'cyan' },

  // 3-blocks
  { matrix: [[1, 1, 1]], color: 'blue' },
  { matrix: [[1], [1], [1]], color: 'blue' },
  { matrix: [[1, 0], [1, 1]], color: 'purple' },
  { matrix: [[0, 1], [1, 1]], color: 'purple' },
  { matrix: [[1, 1], [1, 0]], color: 'purple' },
  { matrix: [[1, 1], [0, 1]], color: 'purple' },

  // 4-blocks
  { matrix: [[1, 1], [1, 1]], color: 'magenta' },
  { matrix: [[1, 1, 1, 1]], color: 'emerald' },
  { matrix: [[1], [1], [1], [1]], color: 'emerald' },
  { matrix: [[1, 0, 0], [1, 1, 1]], color: 'amber' },
  { matrix: [[0, 0, 1], [1, 1, 1]], color: 'amber' },
  { matrix: [[1, 1, 1], [1, 0, 0]], color: 'amber' },
  { matrix: [[1, 1, 1], [0, 0, 1]], color: 'amber' },
  { matrix: [[1, 1, 0], [0, 1, 1]], color: 'red' },
  { matrix: [[0, 1, 1], [1, 1, 0]], color: 'red' },
  { matrix: [[0, 1], [1, 1], [0, 1]], color: 'lime' },
  { matrix: [[1, 0], [1, 1], [1, 0]], color: 'lime' },
  { matrix: [[1, 1, 1], [0, 1, 0]], color: 'lime' },
  { matrix: [[0, 1, 0], [1, 1, 1]], color: 'lime' },

  // 5-blocks & big shapes
  { matrix: [[1, 1, 1], [1, 1, 1], [1, 1, 1]], color: 'magenta' },
  { matrix: [[1, 1, 1], [1, 0, 0], [1, 0, 0]], color: 'blue' },
  { matrix: [[1, 1, 1], [0, 0, 1], [0, 0, 1]], color: 'blue' },
  { matrix: [[1, 0, 0], [1, 0, 0], [1, 1, 1]], color: 'blue' },
  { matrix: [[0, 0, 1], [0, 0, 1], [1, 1, 1]], color: 'blue' },
  { matrix: [[1, 1, 1, 1, 1]], color: 'emerald' },
  { matrix: [[1], [1], [1], [1], [1]], color: 'emerald' },
  { matrix: [[0, 1, 0], [1, 1, 1], [0, 1, 0]], color: 'purple' }, // Plus
];

const BLOCK_STYLES: Record<BlockType, { top: string; side: string; glow: string; text: string }> = {
  cyan: {
    top: 'bg-gradient-to-br from-cyan-300 to-cyan-500',
    side: 'bg-cyan-700',
    glow: 'rgba(6,182,212,0.6)',
    text: '#22d3ee',
  },
  blue: {
    top: 'bg-gradient-to-br from-blue-400 to-blue-600',
    side: 'bg-blue-800',
    glow: 'rgba(59,130,246,0.6)',
    text: '#60a5fa',
  },
  purple: {
    top: 'bg-gradient-to-br from-purple-400 to-purple-600',
    side: 'bg-purple-800',
    glow: 'rgba(168,85,247,0.6)',
    text: '#c084fc',
  },
  magenta: {
    top: 'bg-gradient-to-br from-fuchsia-400 to-pink-600',
    side: 'bg-fuchsia-800',
    glow: 'rgba(236,72,153,0.6)',
    text: '#f472b6',
  },
  amber: {
    top: 'bg-gradient-to-br from-amber-300 to-amber-500',
    side: 'bg-amber-700',
    glow: 'rgba(245,158,11,0.6)',
    text: '#fbbf24',
  },
  emerald: {
    top: 'bg-gradient-to-br from-emerald-300 to-emerald-500',
    side: 'bg-emerald-800',
    glow: 'rgba(16,185,129,0.6)',
    text: '#34d399',
  },
  red: {
    top: 'bg-gradient-to-br from-rose-400 to-red-600',
    side: 'bg-red-800',
    glow: 'rgba(239,68,68,0.6)',
    text: '#f87171',
  },
  lime: {
    top: 'bg-gradient-to-br from-lime-300 to-green-500',
    side: 'bg-green-800',
    glow: 'rgba(132,204,22,0.6)',
    text: '#a3e635',
  },
  gem: {
    top: 'bg-gradient-to-br from-pink-300 via-purple-300 to-indigo-400',
    side: 'bg-purple-900',
    glow: 'rgba(216,180,254,0.8)',
    text: '#f472b6',
  },
  ice1: {
    top: 'bg-gradient-to-br from-sky-200/90 to-blue-300/80',
    side: 'bg-sky-600/90',
    glow: 'rgba(186,230,253,0.7)',
    text: '#bae6fd',
  },
  ice2: {
    top: 'bg-gradient-to-br from-blue-100/95 to-sky-400/90',
    side: 'bg-blue-700/90',
    glow: 'rgba(147,197,253,0.8)',
    text: '#93c5fd',
  },
  fixed: {
    top: 'bg-gradient-to-br from-zinc-600 to-zinc-800',
    side: 'bg-zinc-950',
    glow: 'rgba(113,113,122,0.4)',
    text: '#a1a1aa',
  },
};

function randomPiece(): PieceShape {
  const tmpl = SHAPES[Math.floor(Math.random() * SHAPES.length)];
  return {
    id: `piece-${Math.random().toString(36).slice(2, 9)}`,
    matrix: tmpl.matrix,
    color: tmpl.color,
  };
}

/* =========================================================================
 * 3D Isometric Cube Component
 * ========================================================================= */

export function Block3D({
  type,
  size = 52,
  hasGem,
  ice,
  isGhost,
  isInvalid,
  isBlasting,
  onClick,
}: {
  type?: BlockType;
  size?: number;
  hasGem?: boolean;
  ice?: number;
  isGhost?: boolean;
  isInvalid?: boolean;
  isBlasting?: boolean;
  onClick?: () => void;
}) {
  if (!type && !isGhost) {
    return (
      <div
        onClick={onClick}
        style={{ width: size, height: size }}
        className="rounded-xl border border-white/10 bg-black/40 transition-colors hover:border-white/25"
      />
    );
  }

  const effectiveType: BlockType = ice === 2 ? 'ice2' : ice === 1 ? 'ice1' : type || 'cyan';
  const st = BLOCK_STYLES[effectiveType] || BLOCK_STYLES.cyan;

  return (
    <div
      onClick={onClick}
      style={{
        width: size,
        height: size,
        opacity: isGhost ? (isInvalid ? 0.5 : 0.85) : isBlasting ? 0 : 1,
      }}
      className={cn(
        'relative flex items-center justify-center rounded-xl select-none border-t border-l border-white/40 shadow-md transition-opacity',
        isGhost
          ? (isInvalid ? 'bg-red-600/70 ring-2 ring-red-400' : 'bg-emerald-500/80 ring-2 ring-emerald-300')
          : st.top
      )}
    >
      {hasGem && (
        <Gem size={size * 0.48} className="text-white drop-shadow" />
      )}
      {ice && ice > 0 && (
        <Snowflake size={size * 0.48} className="text-sky-100 drop-shadow" />
      )}
    </div>
  );
}

/* =========================================================================
 * Main Block Blast VR Game Component
 * ========================================================================= */

export function BlockBlastApp() {
  const [levelIdx, setLevelIdx] = useState(0); // 0 to 9, or -1 for Classic Infinity
  const [view, setView] = useState<'game' | 'levels'>('game');
  const [grid, setGrid] = useState<GridCell[][]>(() => createEmptyGrid());
  const [dock, setDock] = useState<(PieceShape | null)[]>([null, null, null]);
  const [selectedPieceIdx, setSelectedPieceIdx] = useState<number | null>(null);
  const [hoverPos, setHoverPos] = useState<{ r: number; c: number } | null>(null);

  // Stats & Progress
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(() => Number(localStorage.getItem('blvr.blockblast.high') || 0));
  const [combo, setCombo] = useState(0);
  const [movesLeft, setMovesLeft] = useState<number | null>(null);
  const [linesCleared, setLinesCleared] = useState(0);
  const [gemsCollected, setGemsCollected] = useState(0);
  const [iceMelted, setIceMelted] = useState(0);

  // Status Modals
  const [gameWon, setGameWon] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [levelStars, setLevelStars] = useState<number[]>(() => {
    try {
      const s = localStorage.getItem('blvr.blockblast.stars');
      return s ? JSON.parse(s) : Array(10).fill(0);
    } catch {
      return Array(10).fill(0);
    }
  });

  const gridRef = useRef<HTMLDivElement>(null);

  // Level Setup
  useEffect(() => {
    initLevel(levelIdx);
  }, [levelIdx]);

  function createEmptyGrid(): GridCell[][] {
    return Array.from({ length: GRID_SIZE }, () =>
      Array.from({ length: GRID_SIZE }, () => ({ type: 'cyan', color: '', ice: 0, hasGem: false }))
    );
  }

  function initLevel(lvl: number) {
    const isInfinity = lvl === -1;
    const cfg = isInfinity ? null : LEVELS[lvl] || LEVELS[0];

    const newGrid: GridCell[][] = Array.from({ length: GRID_SIZE }, () =>
      Array.from({ length: GRID_SIZE }, () => ({ type: 'cyan', color: '', ice: 0, hasGem: false }))
    );

    if (cfg?.initialGrid) {
      cfg.initialGrid.forEach((it) => {
        newGrid[it.r][it.c] = {
          type: it.type,
          color: it.type,
          hasGem: !!it.hasGem,
          ice: it.ice || 0,
        };
      });
    }

    setGrid(newGrid);
    setDock([randomPiece(), randomPiece(), randomPiece()]);
    setSelectedPieceIdx(null);
    setHoverPos(null);
    setScore(0);
    setCombo(0);
    setLinesCleared(0);
    setGemsCollected(0);
    setIceMelted(0);
    setMovesLeft(cfg?.maxMoves ?? null);
    setGameWon(false);
    setGameOver(false);
  }

  function canPlace(piece: PieceShape, startR: number, startC: number, currentGrid: GridCell[][]): boolean {
    const pr = piece.matrix.length;
    const pc = piece.matrix[0].length;

    if (startR + pr > GRID_SIZE || startC + pc > GRID_SIZE || startR < 0 || startC < 0) {
      return false;
    }

    for (let r = 0; r < pr; r++) {
      for (let c = 0; c < pc; c++) {
        if (piece.matrix[r][c] === 1) {
          const cell = currentGrid[startR + r][startC + c];
          if (cell.color !== '') {
            return false;
          }
        }
      }
    }
    return true;
  }

  function hasAnyValidPlacement(pieces: (PieceShape | null)[], currentGrid: GridCell[][]): boolean {
    for (const piece of pieces) {
      if (!piece) continue;
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          if (canPlace(piece, r, c, currentGrid)) {
            return true;
          }
        }
      }
    }
    return false;
  }

  function placePiece(pieceIdx: number, startR: number, startC: number) {
    const piece = dock[pieceIdx];
    if (!piece || !canPlace(piece, startR, startC, grid)) {
      sfx.click();
      return;
    }

    playNote(420, 0.15);

    // 1. Copy grid & place block cells
    const nextGrid = grid.map((row) => row.map((cell) => ({ ...cell })));
    let blocksPlaced = 0;

    for (let r = 0; r < piece.matrix.length; r++) {
      for (let c = 0; c < piece.matrix[r].length; c++) {
        if (piece.matrix[r][c] === 1) {
          nextGrid[startR + r][startC + c] = {
            type: piece.color,
            color: piece.color,
            hasGem: false,
            ice: 0,
          };
          blocksPlaced++;
        }
      }
    }

    // Base score for placing pieces
    let turnPoints = blocksPlaced * 10;

    // 2. Check completed rows and columns
    const fullRows: number[] = [];
    const fullCols: number[] = [];

    for (let r = 0; r < GRID_SIZE; r++) {
      if (nextGrid[r].every((cell) => cell.color !== '')) {
        fullRows.push(r);
      }
    }

    for (let c = 0; c < GRID_SIZE; c++) {
      let colFull = true;
      for (let r = 0; r < GRID_SIZE; r++) {
        if (nextGrid[r][c].color === '') {
          colFull = false;
          break;
        }
      }
      if (colFull) fullCols.push(c);
    }

    const totalLines = fullRows.length + fullCols.length;
    let newCombo = combo;
    let turnGems = 0;
    let turnIce = 0;

    if (totalLines > 0) {
      newCombo = combo + 1;
      const comboMult = Math.min(newCombo, 5);

      // Play synthesized chord for line clear with rising pitch based on combo!
      const baseFreq = 523.25 * Math.pow(1.15, newCombo - 1);
      playNote(baseFreq, 0.4);
      setTimeout(() => playNote(baseFreq * 1.25, 0.4), 80);
      setTimeout(() => playNote(baseFreq * 1.5, 0.5), 160);

      // Blast points: 100 per line * line count * combo multiplier
      turnPoints += totalLines * 120 * totalLines * comboMult;

      // Identify blasted cells and handle obstacles (Gems & Ice)
      const blastedCells = new Set<string>();

      fullRows.forEach((r) => {
        for (let c = 0; c < GRID_SIZE; c++) blastedCells.add(`${r},${c}`);
      });
      fullCols.forEach((c) => {
        for (let r = 0; r < GRID_SIZE; r++) blastedCells.add(`${r},${c}`);
      });

      blastedCells.forEach((coord) => {
        const [r, c] = coord.split(',').map(Number);
        const cell = nextGrid[r][c];

        if (cell.hasGem) {
          turnGems++;
        }

        if (cell.ice && cell.ice > 0) {
          if (cell.ice === 2) {
            cell.ice = 1; // cracked ice remains for one more hit
          } else {
            cell.ice = 0;
            turnIce++;
            cell.color = ''; // melted!
          }
        } else if (cell.type !== 'fixed') {
          cell.color = '';
        }
      });
    } else {
      newCombo = 0; // reset combo on turn without line clear
    }

    const newScore = score + turnPoints;
    const newLines = linesCleared + totalLines;
    const newGems = gemsCollected + turnGems;
    const newIce = iceMelted + turnIce;
    const nextMoves = movesLeft !== null ? movesLeft - 1 : null;

    setScore(newScore);
    setCombo(newCombo);
    setLinesCleared(newLines);
    setGemsCollected(newGems);
    setIceMelted(newIce);
    setMovesLeft(nextMoves);

    if (newScore > highScore) {
      setHighScore(newScore);
      localStorage.setItem('blvr.blockblast.high', String(newScore));
    }

    // 3. Update piece dock
    const updatedDock = dock.map((p, idx) => (idx === pieceIdx ? null : p));
    const allPlaced = updatedDock.every((p) => p === null);
    const finalDock = allPlaced ? [randomPiece(), randomPiece(), randomPiece()] : updatedDock;
    if (allPlaced) sfx.pop();

    setDock(finalDock);
    setSelectedPieceIdx(null);
    setHoverPos(null);
    setGrid(nextGrid);

    // 4. Check Level Win Conditions
    const cfg = levelIdx === -1 ? null : LEVELS[levelIdx];
    if (cfg) {
      let isWin = false;
      if (cfg.goalType === 'score' && newScore >= cfg.targetScore) isWin = true;
      if (cfg.goalType === 'lines' && newLines >= cfg.goalTarget) isWin = true;
      if (cfg.goalType === 'gems' && newGems >= cfg.goalTarget) isWin = true;
      if (cfg.goalType === 'ice' && newIce >= cfg.goalTarget) isWin = true;
      if (cfg.goalType === 'combo' && newCombo >= cfg.goalTarget) isWin = true;
      if (cfg.goalType === 'moves' && newScore >= cfg.targetScore) isWin = true;

      if (isWin) {
        setGameWon(true);
        sfx.hold();
        // Calculate stars (1-3)
        const stars = newScore >= cfg.targetScore * 1.5 ? 3 : newScore >= cfg.targetScore ? 2 : 1;
        const nextStars = [...levelStars];
        nextStars[levelIdx] = Math.max(nextStars[levelIdx] || 0, stars);
        setLevelStars(nextStars);
        localStorage.setItem('blvr.blockblast.stars', JSON.stringify(nextStars));
        return;
      }

      // Check Moves Run Out
      if (nextMoves !== null && nextMoves <= 0 && !isWin) {
        setGameOver(true);
        sfx.hold();
        return;
      }
    }

    // 5. Check No Valid Moves Remaining (Game Over)
    if (!hasAnyValidPlacement(finalDock, nextGrid)) {
      setGameOver(true);
      sfx.hold();
    }
  }

  // Cell Interaction with Pinch or Click
  function handleCellClick(r: number, c: number) {
    if (selectedPieceIdx !== null) {
      placePiece(selectedPieceIdx, r, c);
    }
  }

  const curLevel = levelIdx === -1 ? null : LEVELS[levelIdx] || LEVELS[0];

  return (
    <div className="flex h-full flex-col bg-[#080d1a] font-sans select-none text-white">
      {/* ===================== Top Bar ===================== */}
      <div className="flex shrink-0 items-center justify-between border-b border-white/10 bg-[#0c1222] px-6 py-3">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-fuchsia-500 to-indigo-700 shadow-md">
            <Sparkles size={24} className="text-white drop-shadow" />
          </div>
          <div>
            <div className="text-[19px] font-bold leading-tight">
              {levelIdx === -1 ? 'Modo Infinito' : curLevel?.name}
            </div>
            <div className="text-[13px] text-white/50">{curLevel?.desc || 'Faça o máximo de pontos!'}</div>
          </div>
        </div>

        {/* Level Stats Badge */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 rounded-2xl bg-white/5 px-4 py-2 border border-white/10">
            <Trophy size={18} className="text-amber-400" />
            <div className="text-[20px] font-extrabold text-sky-300 tabular-nums">{score}</div>
            <span className="text-[12px] text-white/40">/ {curLevel?.targetScore || '∞'}</span>
          </div>

          {combo > 1 && (
            <div className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-amber-500 to-orange-600 px-4 py-1.5 text-[14px] font-bold text-black shadow-lg animate-pulse">
              <Flame size={18} fill="currentColor" />
              <span>COMBO x{combo}!</span>
            </div>
          )}

          {movesLeft !== null && (
            <div className="rounded-xl bg-white/10 px-3.5 py-1.5 text-[14px] font-semibold text-white/80 tabular-nums">
              Jogadas: <b className="text-amber-300">{movesLeft}</b>
            </div>
          )}

          <Btn
            onClick={() => setView(view === 'game' ? 'levels' : 'game')}
            className="hv flex items-center gap-2 rounded-xl bg-white/10 px-4 py-2 text-[14px]"
          >
            <Grid3x3 size={18} />
            <span>Fases</span>
          </Btn>

          <Btn
            onClick={() => initLevel(levelIdx)}
            title="Reiniciar Fase"
            className="hv flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-white"
          >
            <RotateCcw size={18} />
          </Btn>
        </div>
      </div>

      {/* ===================== Main View ===================== */}
      <div className="relative min-h-0 flex-1 overflow-hidden p-4">
        {view === 'levels' ? (
          /* Level Selector Screen */
          <div data-scroll className="h-full overflow-y-auto p-6">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2 className="text-[26px] font-bold text-white">Escolha sua Fase</h2>
                <p className="text-[15px] text-white/60">Complete os objetivos para liberar as 10 fases em 3D.</p>
              </div>
              <Btn
                onClick={() => { setLevelIdx(-1); setView('game'); }}
                className="hv-solid flex items-center gap-2 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-600 px-6 py-3 text-[16px] font-bold text-black shadow-lg"
              >
                <Zap size={20} fill="currentColor" /> Modo Infinito
              </Btn>
            </div>

            <div className="grid grid-cols-2 gap-4 sm:grid-cols-5">
              {LEVELS.map((lvl, idx) => {
                const stars = levelStars[idx] || 0;
                const unlocked = idx === 0 || (levelStars[idx - 1] && levelStars[idx - 1] > 0) || idx <= 3;
                return (
                  <Btn
                    key={lvl.level}
                    onClick={() => {
                      if (unlocked) {
                        setLevelIdx(idx);
                        setView('game');
                      }
                    }}
                    className={cn(
                      'hv flex flex-col justify-between rounded-3xl p-5 text-left transition-all',
                      levelIdx === idx ? 'ring-2 ring-sky-400 bg-blue-900/40' : 'bg-white/5',
                      !unlocked && 'opacity-40 cursor-not-allowed'
                    )}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="rounded-full bg-white/10 px-2.5 py-0.5 text-[12px] font-bold text-sky-300">
                          Fase {lvl.level}
                        </span>
                        <div className="flex gap-0.5 text-amber-400">
                          {Array.from({ length: 3 }).map((_, i) => (
                            <Star key={i} size={14} fill={i < stars ? 'currentColor' : 'none'} className={i < stars ? '' : 'text-white/20'} />
                          ))}
                        </div>
                      </div>
                      <div className="text-[17px] font-bold leading-snug text-white">{lvl.name.split(':')[1] || lvl.name}</div>
                      <p className="mt-1 line-clamp-2 text-[12px] text-white/50">{lvl.desc}</p>
                    </div>

                    <div className="mt-4 flex items-center justify-between text-[12px] font-medium text-white/60">
                      <span>Meta: {lvl.targetScore}</span>
                      <ArrowRight size={14} />
                    </div>
                  </Btn>
                );
              })}
            </div>
          </div>
        ) : (
          /* Active Game Board View */
          <div className="flex h-full items-center justify-center gap-8">
            {/* 8x8 3D Isometric Board */}
            <div className="relative flex flex-col items-center">
              <div
                ref={gridRef}
                className="relative rounded-3xl border-2 border-white/20 bg-[#050914] p-3 shadow-2xl"
                style={{
                  transform: 'perspective(1200px) rotateX(16deg)',
                  transformStyle: 'preserve-3d',
                }}
              >
                <div className="grid grid-cols-8 gap-2 rounded-2xl bg-black/50 p-2.5">
                  {grid.map((row, r) =>
                    row.map((cell, c) => {
                      const selectedPiece = selectedPieceIdx !== null ? dock[selectedPieceIdx] : null;

                      // Check if cell is covered by hovered piece preview
                      let isGhostCell = false;
                      let isInvalidPlacement = false;

                      if (selectedPiece && hoverPos) {
                        const pr = r - hoverPos.r;
                        const pc = c - hoverPos.c;
                        if (
                          pr >= 0 &&
                          pr < selectedPiece.matrix.length &&
                          pc >= 0 &&
                          pc < selectedPiece.matrix[0].length &&
                          selectedPiece.matrix[pr][pc] === 1
                        ) {
                          isGhostCell = true;
                          isInvalidPlacement = !canPlace(selectedPiece, hoverPos.r, hoverPos.c, grid);
                        }
                      }

                      return (
                        <div
                          key={`${r}-${c}`}
                          onPointerEnter={() => setHoverPos({ r, c })}
                          onClick={() => handleCellClick(r, c)}
                          className="cursor-pointer"
                        >
                          <Block3D
                            type={isGhostCell ? selectedPiece?.color : cell.color ? cell.type : undefined}
                            size={52}
                            hasGem={cell.hasGem}
                            ice={cell.ice}
                            isGhost={isGhostCell}
                            isInvalid={isInvalidPlacement}
                          />
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>

            {/* Right Side: 3-Piece Dock + Placement Instructions */}
            <div className="flex w-[320px] flex-col gap-4">
              <div className="rounded-3xl border border-white/10 bg-white/[.04] p-5 shadow-xl">
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-[14px] font-bold uppercase tracking-wider text-sky-400">
                    Peças para Encaixar
                  </span>
                  <span className="text-[12px] text-white/40">Faça pinça para segurar</span>
                </div>

                {/* 3 Dock Slots */}
                <div className="flex flex-col gap-3">
                  {dock.map((piece, pIdx) => {
                    if (!piece) {
                      return (
                        <div
                          key={pIdx}
                          className="flex h-[88px] items-center justify-center rounded-2xl border border-dashed border-white/10 bg-white/[.01] text-white/20"
                        >
                          <Check size={24} />
                        </div>
                      );
                    }

                    const isSelected = selectedPieceIdx === pIdx;

                    return (
                      <Btn
                        key={piece.id}
                        onClick={() => {
                          setSelectedPieceIdx(isSelected ? null : pIdx);
                          sfx.click();
                        }}
                        className={cn(
                          'hv flex h-[100px] items-center justify-center rounded-2xl p-2 transition-all',
                          isSelected
                            ? 'bg-blue-600/30 ring-2 ring-sky-400 shadow-[0_0_20px_rgba(56,189,248,0.4)]'
                            : 'bg-white/5 hover:bg-white/10'
                        )}
                      >
                        {/* Render Mini Piece Matrix */}
                        <div
                          className="grid gap-1"
                          style={{
                            gridTemplateColumns: `repeat(${piece.matrix[0].length}, minmax(0, 1fr))`,
                          }}
                        >
                          {piece.matrix.map((row, r) =>
                            row.map((val, c) => (
                              <div key={`${r}-${c}`} className="flex items-center justify-center">
                                {val === 1 ? (
                                  <Block3D type={piece.color} size={24} />
                                ) : (
                                  <div className="h-6 w-6" />
                                )}
                              </div>
                            ))
                          )}
                        </div>
                      </Btn>
                    );
                  })}
                </div>
              </div>

              {/* Instructions Callout */}
              <div className="rounded-2xl bg-white/5 p-4 text-[13px] leading-relaxed text-white/60 border border-white/5">
                <p>
                  👉 <b className="text-white">Pinça na peça</b> para selecionar, depois <b className="text-white">pinça na grade</b> para soltar e explodir!
                </p>
              </div>
            </div>
          </div>
        )}

        {/* ===================== Modals ===================== */}

        {/* Victory Modal */}
        {gameWon && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/85 backdrop-blur-md">
            <div className="flex w-[480px] flex-col items-center rounded-3xl border border-white/20 bg-[#0d1322] p-8 text-center shadow-2xl">
              <div className="mb-2 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-orange-500 shadow-xl">
                <Trophy size={42} className="text-black" />
              </div>

              <h2 className="text-[32px] font-black text-white">Fase Concluída!</h2>
              <p className="text-[15px] text-white/60 mb-4">{curLevel?.name}</p>

              {/* Stars Earned */}
              <div className="mb-6 flex gap-2 text-amber-400">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Star key={i} size={36} fill="currentColor" className="drop-shadow-lg animate-bounce" style={{ animationDelay: `${i * 150}ms` }} />
                ))}
              </div>

              <div className="mb-6 rounded-2xl bg-white/5 p-4 w-full">
                <div className="text-[13px] uppercase text-white/40">Pontuação Final</div>
                <div className="text-[34px] font-extrabold text-sky-300 tabular-nums">{score}</div>
              </div>

              <div className="flex w-full gap-3">
                <Btn
                  onClick={() => initLevel(levelIdx)}
                  className="hv flex flex-1 items-center justify-center gap-2 rounded-2xl bg-white/10 py-3.5 text-[16px] font-semibold text-white"
                >
                  <RotateCcw size={18} /> Jogar de Novo
                </Btn>
                {levelIdx < 9 ? (
                  <Btn
                    onClick={() => {
                      setLevelIdx(levelIdx + 1);
                      setView('game');
                    }}
                    className="hv-solid flex flex-1 items-center justify-center gap-2 rounded-2xl bg-blue-600 py-3.5 text-[16px] font-semibold text-white shadow-lg"
                  >
                    <span>Próxima Fase</span> <ArrowRight size={18} />
                  </Btn>
                ) : (
                  <Btn
                    onClick={() => setView('levels')}
                    className="hv-solid flex flex-1 items-center justify-center gap-2 rounded-2xl bg-emerald-600 py-3.5 text-[16px] font-semibold text-white"
                  >
                    <span>Ver Todas as Fases</span>
                  </Btn>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Game Over Modal */}
        {gameOver && !gameWon && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/85 backdrop-blur-md">
            <div className="flex w-[460px] flex-col items-center rounded-3xl border border-white/20 bg-[#0d1322] p-8 text-center shadow-2xl">
              <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-red-600/30 text-red-400 ring-2 ring-red-500/50">
                <Target size={36} />
              </div>

              <h2 className="text-[28px] font-bold text-white mb-1">Sem Espaço para Peças!</h2>
              <p className="text-[14px] text-white/50 mb-4">Nenhuma peça restante cabe na grade atual.</p>

              <div className="mb-6 rounded-2xl bg-white/5 p-4 w-full">
                <div className="text-[12px] uppercase text-white/40">Pontuação Alcançada</div>
                <div className="text-[30px] font-extrabold text-amber-300 tabular-nums">{score}</div>
              </div>

              <div className="flex w-full gap-3">
                <Btn
                  onClick={() => setView('levels')}
                  className="hv flex flex-1 items-center justify-center rounded-2xl bg-white/10 py-3.5 text-[15px] font-semibold text-white"
                >
                  Fases
                </Btn>
                <Btn
                  onClick={() => initLevel(levelIdx)}
                  className="hv-solid flex flex-1 items-center justify-center gap-2 rounded-2xl bg-blue-600 py-3.5 text-[15px] font-semibold text-white"
                >
                  <RotateCcw size={18} /> Tentar de Novo
                </Btn>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
