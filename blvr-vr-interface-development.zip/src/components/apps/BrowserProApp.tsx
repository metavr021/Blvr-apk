import {
  ArrowLeft, ArrowRight, RotateCw, Home, Search, Plus, X, Shield, Eye, Bookmark as BookmarkIcon,
  ZoomIn, ZoomOut, Monitor, Smartphone, BookOpen, ExternalLink, Loader2, Lock, Star
} from 'lucide-react';
import {
  useBrowser, activeTab, newTab, closeTab, switchTab, toggleIncognito,
  browserNavigate, browserBack, browserForward, browserReload, browserHome,
  openReaderMode, addBookmark, removeBookmark, setZoom, toggleDesktop,
  setEngine, openBrowserKb, type SearchEngine
} from '../../core/browser';
import { S } from '../../core/store';
import { Btn } from '../ui';
import { cn } from '../../utils/cn';

const ENGINES: { id: SearchEngine; label: string; icon: string; url: (q: string) => string }[] = [
  { id: 'duckduckgo', label: 'DuckDuckGo', icon: '🦆', url: (q) => `https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}` },
  { id: 'google', label: 'Google', icon: 'G', url: (q) => `https://www.google.com/search?q=${encodeURIComponent(q)}` },
  { id: 'bing', label: 'Bing', icon: 'B', url: (q) => `https://www.bing.com/search?q=${encodeURIComponent(q)}` },
  { id: 'startpage', label: 'StartPage', icon: 'S', url: (q) => `https://www.startpage.com/sp/search?query=${encodeURIComponent(q)}` },
  { id: 'wikipedia', label: 'Wikipédia', icon: 'W', url: (q) => `wiki:${encodeURIComponent(q)}` },
];

export function BrowserProApp() {
  const tabs = useBrowser((s) => s.tabs);
  const activeId = useBrowser((s) => s.activeId);
  const bookmarks = useBrowser((s) => s.bookmarks);
  const globalHistory = useBrowser((s) => s.globalHistory);
  const cur = activeTab();

  const isBookmarked = bookmarks.some((b) => b.url === cur.url);

  return (
    <div className={cn('flex h-full flex-col font-sans', cur.incognito ? 'bg-[#090614]' : 'bg-[#0b1020]')}>
      {/* ===================== Top Tabs Strip ===================== */}
      <div className={cn('flex shrink-0 items-center gap-1.5 border-b px-2 pt-2', cur.incognito ? 'border-purple-900/40 bg-[#06040d]' : 'border-white/10 bg-[#080c18]')}>
        <div data-scroll="x" className="flex min-w-0 flex-1 items-center gap-1.5 overflow-x-auto pb-1.5">
          {tabs.map((t) => {
            const active = t.id === activeId;
            return (
              <div
                key={t.id}
                onClick={() => switchTab(t.id)}
                className={cn(
                  'group flex h-11 min-w-[140px] max-w-[220px] cursor-pointer items-center gap-2 rounded-t-xl px-3 text-[14px] transition-all select-none',
                  active
                    ? (t.incognito ? 'bg-[#140b2b] text-purple-200 shadow-md ring-1 ring-purple-500/40' : 'bg-[#0f172a] text-white shadow-md ring-1 ring-blue-500/30')
                    : 'bg-white/5 text-white/60 hover:bg-white/10 hover:text-white/85'
                )}
              >
                {t.incognito ? <Eye size={16} className="shrink-0 text-purple-400" /> : <Shield size={15} className="shrink-0 text-sky-400" />}
                <span className="truncate font-medium">{t.title}</span>
                <Btn
                  onClick={(e?: React.MouseEvent) => {
                    e?.stopPropagation();
                    closeTab(t.id);
                  }}
                  title="Fechar Guia"
                  className="hv ml-auto flex h-6 w-6 shrink-0 items-center justify-center rounded-full opacity-60 hover:bg-white/20 hover:opacity-100"
                >
                  <X size={14} />
                </Btn>
              </div>
            );
          })}
        </div>

        {/* Tab Controls */}
        <div className="flex shrink-0 items-center gap-1 pb-1.5">
          <Btn onClick={() => newTab(false)} title="Nova Guia" className="hv flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-white">
            <Plus size={18} />
          </Btn>
          <Btn
            onClick={toggleIncognito}
            title={cur.incognito ? 'Abrir Guia Normal' : 'Nova Guia Anônima'}
            className={cn('hv flex h-10 items-center gap-1.5 rounded-xl px-3 text-[13px]', cur.incognito ? 'bg-purple-600 text-white shadow' : 'bg-purple-950/60 text-purple-300 ring-1 ring-purple-500/40')}
          >
            <Eye size={16} />
            <span>Anônima</span>
          </Btn>
        </div>
      </div>

      {/* ===================== Navigation & Address Bar ===================== */}
      <div className={cn('flex shrink-0 items-center gap-2 border-b px-4 py-2.5', cur.incognito ? 'border-purple-900/30 bg-[#0e0721]' : 'border-white/10 bg-[#0d1322]')}>
        <Btn onClick={browserBack} className={cn('hv flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white', cur.histIdx <= 0 && 'opacity-35')}>
          <ArrowLeft size={20} />
        </Btn>
        <Btn onClick={browserForward} className={cn('hv flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white', cur.histIdx >= cur.history.length - 1 && 'opacity-35')}>
          <ArrowRight size={20} />
        </Btn>
        <Btn onClick={browserReload} title="Recarregar" className="hv flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white">
          <RotateCw size={18} className={cur.loading ? 'animate-spin text-sky-400' : ''} />
        </Btn>
        <Btn onClick={browserHome} title="Início" className="hv flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white">
          <Home size={19} />
        </Btn>

        {/* Address Input Bar */}
        <div
          onClick={openBrowserKb}
          className={cn(
            'group flex h-11 min-w-0 flex-1 cursor-pointer items-center gap-2.5 rounded-full px-4 text-[16px] transition-all',
            cur.incognito
              ? 'bg-purple-950/40 ring-1 ring-purple-500/50 hover:bg-purple-950/60'
              : 'bg-white/[.08] ring-1 ring-white/15 hover:bg-white/[.12]'
          )}
        >
          {cur.mode === 'web' ? <Lock size={16} className="text-emerald-400 shrink-0" /> : <Search size={17} className="text-white/50 shrink-0" />}
          <span className={cn('truncate font-normal', cur.input ? (cur.incognito ? 'text-purple-100' : 'text-white') : 'text-white/40')}>
            {cur.input || 'Pesquisar ou digitar endereço web (.com)'}
          </span>
          <span className="ml-auto rounded bg-white/10 px-2 py-0.5 text-[11px] text-white/50 shrink-0">⌨ Teclado</span>
        </div>

        {/* Action icons */}
        {cur.mode === 'web' && (
          <Btn
            onClick={() => openReaderMode(cur.url)}
            title="Modo Leitura (Extrair texto limpo)"
            className="hv flex h-11 items-center gap-1.5 rounded-full bg-sky-500/20 px-3.5 text-[13px] text-sky-200 ring-1 ring-sky-400/40"
          >
            <BookOpen size={16} />
            <span>Leitor</span>
          </Btn>
        )}

        <Btn
          onClick={() => (isBookmarked ? removeBookmark(bookmarks.find((b) => b.url === cur.url)?.id || '') : addBookmark(cur.title, cur.url || cur.input))}
          title={isBookmarked ? 'Remover Favorito' : 'Salvar nos Favoritos'}
          className={cn('hv flex h-11 w-11 items-center justify-center rounded-full', isBookmarked ? 'bg-amber-500 text-black' : 'bg-white/10 text-white')}
        >
          <BookmarkIcon size={18} fill={isBookmarked ? 'currentColor' : 'none'} />
        </Btn>

        {/* Zoom controls */}
        <div className="flex items-center rounded-full bg-white/10 p-1">
          <Btn onClick={() => setZoom(-0.1)} title="Diminuir Zoom" className="hv flex h-9 w-9 items-center justify-center rounded-full text-white">
            <ZoomOut size={16} />
          </Btn>
          <span className="w-11 text-center text-[12px] font-semibold text-white/80 tabular-nums">{Math.round(cur.zoom * 100)}%</span>
          <Btn onClick={() => setZoom(0.1)} title="Aumentar Zoom" className="hv flex h-9 w-9 items-center justify-center rounded-full text-white">
            <ZoomIn size={16} />
          </Btn>
        </div>

        <Btn
          onClick={toggleDesktop}
          title={cur.desktop ? 'Visualização Mobile' : 'Visualização Desktop'}
          className={cn('hv flex h-11 w-11 items-center justify-center rounded-full', cur.desktop ? 'bg-blue-600 text-white' : 'bg-white/10 text-white')}
        >
          {cur.desktop ? <Monitor size={18} /> : <Smartphone size={18} />}
        </Btn>
      </div>

      {/* ===================== Content Viewport ===================== */}
      <div className="relative min-h-0 flex-1 overflow-hidden">
        {/* --- 1. HOME MODE (Normal & Incognito Hub) --- */}
        {cur.mode === 'home' && (
          <div data-scroll className="flex h-full flex-col items-center overflow-y-auto px-8 py-8">
            {cur.incognito ? (
              <div className="mb-6 flex flex-col items-center text-center">
                <div className="mb-3 flex h-20 w-20 items-center justify-center rounded-full bg-purple-900/40 ring-2 ring-purple-500/50">
                  <Eye size={42} className="text-purple-300" />
                </div>
                <h1 className="text-[32px] font-bold text-purple-100">Navegação Anônima</h1>
                <p className="max-w-xl text-[15px] leading-relaxed text-purple-300/70">
                  Neste modo, o BLVR não salva seu histórico de navegação, termos pesquisados ou cookies desta guia.
                  As guias anônimas são isoladas e fechadas limpas.
                </p>
              </div>
            ) : (
              <div className="mb-6 flex flex-col items-center text-center">
                <div className="mb-2 flex items-center gap-2">
                  <span className="text-[38px] font-extrabold text-white">BLVR</span>
                  <span className="rounded-lg bg-blue-600 px-2.5 py-0.5 text-[20px] font-bold text-white shadow-lg">Web Pro</span>
                </div>
                <p className="text-[15px] text-white/55">Navegador completo com abas, modo anônimo, leitor VR e favoritos.</p>
              </div>
            )}

            {/* Quick Search Box */}
            <div
              onClick={openBrowserKb}
              className={cn(
                'hv mb-8 flex h-14 w-full max-w-2xl cursor-pointer items-center gap-3.5 rounded-full px-6 text-[18px] shadow-2xl transition-all',
                cur.incognito ? 'bg-purple-950/60 ring-2 ring-purple-500/40 text-purple-200' : 'bg-white/10 ring-2 ring-blue-500/40 text-white'
              )}
            >
              <Search size={22} className={cur.incognito ? 'text-purple-400' : 'text-sky-400'} />
              <span className="flex-1 font-normal opacity-60">Pesquise no DuckDuckGo, Google ou digite uma URL…</span>
              <Btn onClick={() => openBrowserKb()} className="rounded-full bg-white/15 px-3 py-1 text-[13px]">
                Digitar ↵
              </Btn>
            </div>

            {/* Search Engine Switcher */}
            <div className="mb-8 flex flex-wrap items-center justify-center gap-2">
              <span className="text-[13px] text-white/45">Motor de busca:</span>
              {ENGINES.map((e) => (
                <Btn
                  key={e.id}
                  onClick={() => setEngine(e.id)}
                  className={cn(
                    'hv rounded-full px-3.5 py-1.5 text-[13px] font-medium transition-all',
                    cur.engine === e.id ? 'bg-blue-600 text-white shadow' : 'bg-white/5 text-white/70'
                  )}
                >
                  <span className="mr-1.5">{e.icon}</span>
                  {e.label}
                </Btn>
              ))}
            </div>

            {/* Quick Dials & Bookmarks Grid */}
            <div className="w-full max-w-3xl">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="flex items-center gap-2 text-[18px] font-semibold text-white">
                  <Star size={18} className="text-amber-400" /> Favoritos & Atalhos Rápidos
                </h2>
                <span className="text-[12px] text-white/40">{bookmarks.length} atalhos</span>
              </div>

              <div className="grid grid-cols-4 gap-3.5 sm:grid-cols-6">
                {bookmarks.map((b) => (
                  <Btn
                    key={b.id}
                    onClick={() => browserNavigate(b.url)}
                    className="hv-lift flex flex-col items-center gap-2 rounded-2xl bg-white/[.04] p-3.5 text-center transition-all hover:bg-white/[.08]"
                  >
                    <span className={cn('flex h-14 w-14 items-center justify-center rounded-2xl text-[24px] font-bold text-white shadow-md', b.color || 'bg-blue-600')}>
                      {b.icon || b.title.charAt(0)}
                    </span>
                    <span className="w-full truncate text-[13px] font-medium text-white/85">{b.title}</span>
                  </Btn>
                ))}
              </div>
            </div>

            {/* Recent History (Non-incognito only) */}
            {!cur.incognito && globalHistory.length > 0 && (
              <div className="mt-8 w-full max-w-3xl">
                <div className="mb-3 flex items-center justify-between">
                  <h3 className="text-[16px] font-medium text-white/80">Páginas recentes</h3>
                </div>
                <div className="flex flex-col gap-1.5 rounded-2xl bg-white/5 p-2">
                  {globalHistory.slice(0, 5).map((h, i) => (
                    <Btn
                      key={i}
                      onClick={() => browserNavigate(h.url)}
                      className="hv flex items-center justify-between rounded-xl px-3 py-2 text-[14px] text-white/80"
                    >
                      <span className="truncate">{h.title || h.url}</span>
                      <span className="text-[12px] text-white/40">{new URL(h.url.startsWith('http') ? h.url : 'https://blvr.web').hostname}</span>
                    </Btn>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* --- 2. SEARCH RESULTS MODE --- */}
        {cur.mode === 'search' && (
          <div data-scroll className="h-full overflow-y-auto px-8 py-6">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
              <div>
                <span className="text-[13px] text-white/50">Resultados da pesquisa para:</span>
                <h1 className="text-[24px] font-bold text-white">“{cur.url}”</h1>
              </div>

              {/* Direct Search Engine Launchers */}
              <div className="flex flex-wrap items-center gap-2">
                <Btn
                  onClick={() => browserNavigate(ENGINES.find((e) => e.id === 'duckduckgo')?.url(cur.url) || '')}
                  className="hv flex items-center gap-1.5 rounded-full bg-amber-600/30 px-3.5 py-1.5 text-[13px] text-amber-200 ring-1 ring-amber-500/40"
                >
                  <span>🦆 Abrir no DuckDuckGo</span>
                </Btn>
                <Btn
                  onClick={() => browserNavigate(ENGINES.find((e) => e.id === 'google')?.url(cur.url) || '')}
                  className="hv flex items-center gap-1.5 rounded-full bg-blue-600/30 px-3.5 py-1.5 text-[13px] text-blue-200 ring-1 ring-blue-500/40"
                >
                  <span>G Abrir no Google</span>
                </Btn>
              </div>
            </div>

            {cur.loading && (
              <div className="flex items-center gap-3 p-8 text-white/60">
                <Loader2 className="animate-spin text-sky-400" size={24} />
                <span>Buscando resultados...</span>
              </div>
            )}

            {cur.error && (
              <div className="mb-4 rounded-2xl bg-amber-500/10 p-4 text-[14px] text-amber-200">
                {cur.error}
              </div>
            )}

            {/* Results list */}
            <div className="flex flex-col gap-3">
              {cur.results.map((r, i) => (
                <div key={i} className="rounded-2xl bg-white/[.04] p-4 transition-all hover:bg-white/[.07]">
                  <div className="mb-1 flex items-center justify-between">
                    <Btn
                      onClick={() => (r.url.startsWith('wiki:') ? openReaderMode(r.url) : browserNavigate(r.url))}
                      className="hv text-[20px] font-semibold text-sky-300 hover:text-sky-200 hover:underline"
                    >
                      {r.title}
                    </Btn>
                    <Btn
                      onClick={() => openReaderMode(r.title)}
                      className="hv rounded-full bg-sky-500/20 px-3 py-1 text-[12px] font-medium text-sky-200"
                    >
                      Modo Leitura
                    </Btn>
                  </div>
                  <p className="text-[15px] leading-relaxed text-white/70">{r.snippet}...</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* --- 3. READER MODE (Clean Article Formatter) --- */}
        {cur.mode === 'reader' && (
          <div data-scroll className="h-full overflow-y-auto px-12 py-8">
            {cur.loading && (
              <div className="flex items-center gap-3 p-8 text-white/60">
                <Loader2 className="animate-spin text-sky-400" size={24} />
                <span>Formatando artigo para VR...</span>
              </div>
            )}

            {cur.error && (
              <div className="rounded-2xl bg-red-500/10 p-5 text-red-200">
                {cur.error}
              </div>
            )}

            {cur.reader && (
              <article className="mx-auto max-w-3xl">
                <div className="mb-2 flex items-center gap-2 text-[14px] text-sky-400">
                  <BookOpen size={16} />
                  <span>Modo Leitura BLVR · {cur.reader.byline || 'Web'}</span>
                </div>
                <h1 className="mb-4 text-[38px] font-extrabold leading-tight text-white">{cur.reader.title}</h1>
                {cur.reader.thumb && (
                  <img src={cur.reader.thumb} alt="" className="mb-6 max-h-[380px] w-full rounded-2xl object-cover shadow-2xl" draggable={false} />
                )}
                <div
                  className="wiki text-[18px] leading-relaxed text-white/85"
                  dangerouslySetInnerHTML={{ __html: cur.reader.html }}
                />
              </article>
            )}
          </div>
        )}

        {/* --- 4. REAL WEB VIEW (IFRAME WITH CONTROLS) --- */}
        {cur.mode === 'web' && (
          <div className="flex h-full flex-col bg-white">
            <div
              className="touch-frame relative min-h-0 flex-1 overflow-hidden"
              style={{
                transform: cur.zoom !== 1 ? `scale(${cur.zoom})` : undefined,
                transformOrigin: 'top left',
                width: cur.zoom !== 1 ? `${(100 / cur.zoom).toFixed(2)}%` : '100%',
                height: cur.zoom !== 1 ? `${(100 / cur.zoom).toFixed(2)}%` : '100%',
              }}
            >
              {cur.url ? (
                <iframe
                  src={cur.url}
                  title="Navegador Web"
                  className="h-full w-full border-0 bg-white"
                  sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals allow-downloads allow-presentation"
                  allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                />
              ) : (
                <div className="flex h-full items-center justify-center bg-[#0d1322] text-white/50">Carregando página...</div>
              )}
            </div>

            {/* Embedded notice & quick rescue banner */}
            <div className="flex shrink-0 items-center justify-between border-t border-black/10 bg-[#0c1220] px-4 py-2 text-[13px] text-white/80">
              <span className="flex items-center gap-1.5 text-white/60">
                <Shield size={14} className="text-emerald-400" />
                <span>Página web real. Se a página travar ou ficar cinza (bloqueio X-Frame-Options do site):</span>
              </span>
              <div className="flex items-center gap-2">
                <Btn
                  onClick={() => openReaderMode(cur.url)}
                  className="hv rounded-full bg-sky-500/20 px-3 py-1 text-[12px] font-medium text-sky-300 ring-1 ring-sky-400/40"
                >
                  <BookOpen size={14} className="inline mr-1" />
                  Modo Leitura
                </Btn>
                <Btn
                  onClick={() => {
                    const w = window.open(cur.url, '_blank', 'noopener');
                    if (!w) S().toast('O navegador bloqueou a nova aba externa', 'warn');
                  }}
                  className="hv rounded-full bg-white/10 px-3 py-1 text-[12px] text-white/80"
                >
                  <ExternalLink size={14} className="inline mr-1" />
                  Abrir fora do VR
                </Btn>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
