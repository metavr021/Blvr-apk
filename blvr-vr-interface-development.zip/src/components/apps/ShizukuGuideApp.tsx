import { Shield, Terminal, HelpCircle, Check, X, ArrowRight } from 'lucide-react';
import { DROID, launchAndroid } from '../../core/launcher';
import { openApp } from '../../core/actions';
import { Btn } from '../ui';
import { cn } from '../../utils/cn';

/**
 * Shizuku & Android Apps Reality Hub.
 * Explains clearly, honestly and technically how Shizuku, Android OS, and Web VR interact:
 *  - What Shizuku is: a native Android daemon that gives INSTALLED NATIVE KOTLIN/JAVA APPS system API access via Binder IPC.
 *  - Why browsers cannot talk to Shizuku: Chrome / Webview security sandboxes isolate JavaScript completely from /dev/binder and Unix domain sockets.
 *  - Why Android does not let apps render other apps in 3D: only a native VR Operating System (like Quest Horizon OS / Android XR) or custom ROM with SurfaceControl can compose arbitrary native APKs into virtual displays.
 *  - The real solutions available today in BLVR: Web Apps running inside windows (BLVR Craft, YouTube, Spotify, etc.) + 1-touch Android deep links!
 */
export function ShizukuGuideApp() {
  const isAndroid = /Android/i.test(navigator.userAgent);
  const mem = (navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? 'n/d';
  const cores = navigator.hardwareConcurrency ?? 'n/d';

  return (
    <div className="flex h-full flex-col bg-[#080d1a] font-sans">
      {/* Header Banner */}
      <div className="shrink-0 border-b border-white/10 bg-gradient-to-r from-blue-950/80 via-slate-900 to-indigo-950/80 p-6">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-600 text-white shadow-lg">
            <Terminal size={28} />
          </div>
          <div>
            <h1 className="text-[24px] font-bold text-white">Shizuku & Apps do Android no VR</h1>
            <p className="text-[14px] text-white/60">Diagnóstico técnico, como o Android funciona e alternativas reais</p>
          </div>
        </div>
      </div>

      <div data-scroll className="min-h-0 flex-1 overflow-y-auto p-6 text-white/85">
        {/* Diagnostic Status Box */}
        <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
          <div className="rounded-2xl bg-white/5 p-4">
            <div className="text-[12px] text-white/40">Sistema Operacional</div>
            <div className="flex items-center gap-2 text-[18px] font-bold text-white">
              {isAndroid ? <><Check size={18} className="text-emerald-400" /> Android</> : <><X size={18} className="text-amber-400" /> Não-Android</>}
            </div>
          </div>
          <div className="rounded-2xl bg-white/5 p-4">
            <div className="text-[12px] text-white/40">Ambiente de Execução</div>
            <div className="text-[18px] font-bold text-sky-300">Web / PWA (Chrome)</div>
          </div>
          <div className="rounded-2xl bg-white/5 p-4">
            <div className="text-[12px] text-white/40">Hardware do Celular</div>
            <div className="text-[18px] font-bold text-white">{cores} núcleos · {mem} GB RAM</div>
          </div>
          <div className="rounded-2xl bg-white/5 p-4">
            <div className="text-[12px] text-white/40">Acesso ao Binder / IPC</div>
            <div className="flex items-center gap-1.5 text-[16px] font-bold text-red-400">
              <X size={18} /> Bloqueado (Sandbox Web)
            </div>
          </div>
        </div>

        {/* Clear Explanation Cards */}
        <div className="mb-6 space-y-4">
          <div className="rounded-2xl border border-blue-500/30 bg-blue-950/20 p-5">
            <h2 className="mb-2 flex items-center gap-2 text-[18px] font-bold text-sky-300">
              <HelpCircle size={20} /> Por que ativar o Shizuku não roda apps dentro de um site?
            </h2>
            <div className="space-y-2 text-[15px] leading-relaxed text-white/80">
              <p>
                O <b>Shizuku</b> é um serviço incrível que concede permissões elevadas via ADB para <b>aplicativos nativos instalados em Java ou Kotlin</b> através do mecanismo de comunicação <code>Binder</code> do Android.
              </p>
              <p>
                Por segurança da internet, navegadores web (como Google Chrome, Samsung Internet e WebViews) rodam em um <b>sandbox rígido</b>: o JavaScript de uma página web <b>não tem permissão de conversar com sockets do Linux nem com o Binder do Android</b>. Mesmo com o Shizuku ativo no seu celular, nenhum site tem como se conectar a ele.
              </p>
            </div>
          </div>

          <div className="rounded-2xl border border-amber-500/30 bg-amber-950/20 p-5">
            <h2 className="mb-2 flex items-center gap-2 text-[18px] font-bold text-amber-300">
              <Shield size={20} /> Como o Meta Quest consegue desenhar outros apps em janelas?
            </h2>
            <p className="text-[15px] leading-relaxed text-white/80">
              No Meta Quest, o <b>óculos é o próprio sistema operacional</b> (o Horizon OS, uma versão customizada do Android). O sistema tem acesso direto ao compositor gráfico (<code>SurfaceFlinger</code>) e cria telas virtuais com <code>VirtualDisplay</code>. Celulares comerciais comuns não concedem esse poder a páginas web nem a apps comuns sem modificações profundas na ROM.
            </p>
          </div>
        </div>

        {/* Real Solutions in BLVR */}
        <div className="mb-6">
          <h2 className="mb-3 text-[20px] font-bold text-white">Como ter a melhor experiência hoje no BLVR:</h2>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-2xl bg-white/5 p-4">
              <div className="mb-1 text-[17px] font-semibold text-emerald-400">1. Jogar BLVR Craft</div>
              <p className="text-[14px] leading-relaxed text-white/65">
                Jogo de blocos 3D real rodando 100% dentro de uma janela no BLVR, sem sair do VR.
              </p>
              <Btn onClick={() => openApp('craft')} className="hv-solid mt-3 flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-[14px] text-white">
                Abrir BLVR Craft <ArrowRight size={16} />
              </Btn>
            </div>

            <div className="rounded-2xl bg-white/5 p-4">
              <div className="mb-1 text-[17px] font-semibold text-sky-400">2. Navegador Web Pro</div>
              <p className="text-[14px] leading-relaxed text-white/65">
                Navegue na web real com abas, modo anônimo, pesquisa e favoritos sem sair do VR.
              </p>
              <Btn onClick={() => openApp('browser')} className="hv-solid mt-3 flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 text-[14px] text-white">
                Abrir Navegador <ArrowRight size={16} />
              </Btn>
            </div>

            <div className="rounded-2xl bg-white/5 p-4">
              <div className="mb-1 text-[17px] font-semibold text-fuchsia-400">3. Lançador de Apps</div>
              <p className="text-[14px] leading-relaxed text-white/65">
                Atalhos rápidos para abrir o Minecraft, Roblox, Netflix e Free Fire no celular.
              </p>
              <Btn onClick={() => openApp('android')} className="hv-solid mt-3 flex items-center gap-1.5 rounded-xl bg-purple-600 px-4 py-2 text-[14px] text-white">
                Ver Meus Apps <ArrowRight size={16} />
              </Btn>
            </div>
          </div>
        </div>

        {/* Quick Android Launcher Matrix */}
        <div>
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-[18px] font-semibold text-white">Atalhos para apps instalados no celular:</h3>
            <span className="text-[13px] text-white/45">Toque para abrir fora do VR</span>
          </div>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
            {DROID.slice(0, 10).map((a) => (
              <Btn
                key={a.id}
                onClick={() => launchAndroid(a.id)}
                className="hv flex items-center gap-2.5 rounded-xl bg-white/[.04] p-2.5 text-left hover:bg-white/[.08]"
              >
                <span className={cn('flex h-9 w-9 shrink-0 items-center justify-center rounded-xl font-bold text-white', a.color)}>
                  {a.letter}
                </span>
                <span className="truncate text-[13px] font-medium text-white/90">{a.name}</span>
              </Btn>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
