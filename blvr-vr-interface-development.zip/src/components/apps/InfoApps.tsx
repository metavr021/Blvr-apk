import { useContext, useEffect } from 'react';
import { Loader2, MapPin, RefreshCw, ArrowUp, MessageSquare, Droplets, Wind, Thermometer } from 'lucide-react';
import { useApps, CITIES, wmo, weatherLoad, weatherHere, weatherTab, nasaLoad, nasaSel, newsLoad, setChess } from '../../core/apps';
import { browserGo, openApp } from '../../core/actions';
import { Btn, EyeCtx } from '../ui';
import { Frame, TouchNote } from './MediaApps';
import { RadarView } from './MapApps';
import { cn } from '../../utils/cn';

const DAY = (d: string) => new Date(d + 'T12:00:00').toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit' });

/* ============================ Clima ============================ */
export function WeatherApp() {
  const eye = useContext(EyeCtx);
  const w = useApps((s) => s.weather);
  useEffect(() => { if (eye !== 'R' && !w.data && !w.loading) weatherHere(); }, [eye]); // eslint-disable-line react-hooks/exhaustive-deps
  const d = w.data;
  return (
    <div className="flex h-full flex-col">
      <div data-scroll="x" className="flex shrink-0 items-center gap-2 overflow-x-auto border-b border-white/10 px-4 py-3">
        <Btn onClick={() => weatherTab('forecast')} className={cn('hv shrink-0 rounded-full px-4 py-2 text-[14px]', w.tab === 'forecast' ? 'bg-sky-500 text-white' : 'bg-white/10 text-white/80')}>Previsão</Btn>
        <Btn onClick={() => weatherTab('radar')} className={cn('hv shrink-0 rounded-full px-4 py-2 text-[14px]', w.tab === 'radar' ? 'bg-sky-500 text-white' : 'bg-white/10 text-white/80')}>Radar de chuva</Btn>
        <div className="mx-1 h-6 w-px shrink-0 bg-white/15" />
        <Btn onClick={weatherHere} className="hv flex shrink-0 items-center gap-1.5 rounded-full bg-white/10 px-4 py-2 text-[14px] text-white"><MapPin size={15} /> Minha localização</Btn>
        {CITIES.map((c) => (
          <Btn key={c.n} onClick={() => weatherLoad(c.lat, c.lon, c.n)} className={cn('hv shrink-0 rounded-full px-4 py-2 text-[14px]', d?.place === c.n ? 'bg-white text-black' : 'bg-white/10 text-white/80')}>{c.n}</Btn>
        ))}
      </div>
      {w.error && <div className="mx-4 mt-3 rounded-xl bg-amber-500/10 p-2.5 text-sm text-amber-200">{w.error}</div>}
      {w.tab === 'radar' ? (
        <RadarView lat={d?.lat} lon={d?.lon} />
      ) : (
        <div data-scroll className="min-h-0 flex-1 overflow-y-auto p-6">
          {w.loading && !d && <div className="flex items-center gap-2 text-white/60"><Loader2 className="animate-spin" /> Obtendo previsão…</div>}
          {d && (
            <>
              <div className="mb-6 flex items-center gap-8 rounded-3xl bg-gradient-to-br from-sky-500/30 to-indigo-600/30 p-6">
                <div className="text-[84px] leading-none">{wmo(d.current.code)[0]}</div>
                <div>
                  <div className="text-[18px] text-white/70">{d.place}</div>
                  <div className="text-[64px] font-semibold leading-none text-white">{Math.round(d.current.temp)}°</div>
                  <div className="text-[18px] text-white/80">{wmo(d.current.code)[1]}</div>
                </div>
                <div className="ml-auto grid gap-2 text-[16px] text-white/80">
                  <span className="flex items-center gap-2"><Thermometer size={18} /> Sensação {Math.round(d.current.feels)}°</span>
                  <span className="flex items-center gap-2"><Droplets size={18} /> Umidade {d.current.hum}%</span>
                  <span className="flex items-center gap-2"><Wind size={18} /> Vento {Math.round(d.current.wind)} km/h</span>
                </div>
              </div>
              <div className="grid grid-cols-7 gap-2">
                {d.days.map((day) => (
                  <div key={day.date} className="flex flex-col items-center gap-1 rounded-2xl bg-white/5 p-3 text-white">
                    <span className="text-[13px] capitalize text-white/60">{DAY(day.date)}</span>
                    <span className="text-[32px]">{wmo(day.code)[0]}</span>
                    <span className="text-[17px] font-semibold">{Math.round(day.max)}°</span>
                    <span className="text-[14px] text-white/50">{Math.round(day.min)}°</span>
                    <span className="text-[12px] text-sky-300">💧 {day.rain}%</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}
      <TouchNote text="Dados: Open-Meteo · Radar: RainViewer (segure a pinça e arraste para mover)" />
    </div>
  );
}

/* ============================ NASA APOD ============================ */
export function NasaApp() {
  const eye = useContext(EyeCtx);
  const n = useApps((s) => s.nasa);
  useEffect(() => { if (eye !== 'R') void nasaLoad(); }, [eye]);
  const cur = n.list[n.sel];
  return (
    <div className="flex h-full">
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="relative flex min-h-0 flex-[3] items-center justify-center bg-black">
          {n.loading && <Loader2 className="animate-spin text-white/60" size={36} />}
          {n.error && <div className="max-w-md p-6 text-center text-amber-200">{n.error}</div>}
          {cur && (cur.media_type === 'video'
            ? <Frame src={cur.url} title={cur.title} />
            : <img src={cur.url} alt={cur.title} draggable={false} className="h-full w-full object-contain" />)}
        </div>
        {cur && (
          <div data-scroll className="min-h-0 flex-[2] overflow-y-auto px-6 py-4">
            <div className="text-[13px] text-white/50">{cur.date}{cur.copyright ? ` · © ${cur.copyright.trim()}` : ''}</div>
            <div className="mb-2 text-[24px] font-semibold text-white">{cur.title}</div>
            <p className="text-[16px] leading-relaxed text-white/75">{cur.explanation}</p>
          </div>
        )}
      </div>
      <div data-scroll className="w-[220px] shrink-0 overflow-y-auto border-l border-white/10 bg-[#0b1020] p-3">
        {n.list.map((a, i) => (
          <Btn key={a.date + i} onClick={() => nasaSel(i)} className={cn('hv mb-2 block overflow-hidden rounded-xl', n.sel === i && 'ring-2 ring-indigo-400')}>
            <img src={a.media_type === 'video' ? (a.thumbnail_url || '') : a.url} alt="" loading="lazy" draggable={false} className="h-[110px] w-full bg-white/5 object-cover" />
            <div className="truncate px-2 py-1.5 text-[12px] text-white/80">{i === 0 ? 'Hoje · ' : ''}{a.title}</div>
          </Btn>
        ))}
      </div>
    </div>
  );
}

/* ============================ Hacker News ============================ */
export function NewsApp() {
  const eye = useContext(EyeCtx);
  const n = useApps((s) => s.news);
  useEffect(() => { if (eye !== 'R') void newsLoad(); }, [eye]);
  const host = (u?: string) => { try { return u ? new URL(u).hostname.replace(/^www\./, '') : 'news.ycombinator.com'; } catch { return ''; } };
  return (
    <div className="flex h-full flex-col">
      <div className="flex shrink-0 items-center gap-3 border-b border-white/10 px-5 py-3">
        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-orange-500 text-lg font-bold text-white">Y</span>
        <span className="flex-1 text-[18px] font-semibold text-white">Top stories</span>
        <Btn onClick={() => newsLoad(true)} className="hv flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white"><RefreshCw size={18} /></Btn>
      </div>
      {n.error && <div className="mx-4 mt-3 rounded-xl bg-red-500/10 p-3 text-sm text-red-300">{n.error}</div>}
      <div data-scroll className="min-h-0 flex-1 overflow-y-auto px-3 py-2">
        {n.loading && <div className="flex items-center gap-2 p-3 text-white/60"><Loader2 className="animate-spin" /> Carregando…</div>}
        {n.list.map((s, i) => (
          <Btn key={s.id} onClick={() => { openApp('browser'); browserGo(s.url || `https://news.ycombinator.com/item?id=${s.id}`); }} className="hv flex gap-3 rounded-xl px-3 py-3">
            <span className="w-7 shrink-0 pt-0.5 text-right text-[15px] text-white/35">{i + 1}</span>
            <div className="min-w-0">
              <div className="text-[17px] leading-snug text-white">{s.title}</div>
              <div className="mt-1 flex items-center gap-3 text-[13px] text-white/45">
                <span>{host(s.url)}</span>
                <span className="flex items-center gap-1"><ArrowUp size={13} />{s.score}</span>
                <span className="flex items-center gap-1"><MessageSquare size={13} />{s.descendants ?? 0}</span>
                <span>por {s.by}</span>
              </div>
            </div>
          </Btn>
        ))}
      </div>
      <TouchNote text="API oficial do Hacker News · links abrem no Navegador (alguns sites bloqueiam exibição em janela)" />
    </div>
  );
}

/* ============================ Lichess / Photopea ============================ */
export function ChessApp() {
  const c = useApps((s) => s.chess);
  return (
    <div className="flex h-full flex-col">
      <div className="flex shrink-0 gap-2 border-b border-white/10 px-4 py-3">
        <Btn onClick={() => setChess('tv')} className={cn('hv rounded-full px-4 py-2 text-[14px]', c === 'tv' ? 'bg-white text-black' : 'bg-white/10 text-white/80')}>Lichess TV (ao vivo)</Btn>
        <Btn onClick={() => setChess('puzzle')} className={cn('hv rounded-full px-4 py-2 text-[14px]', c === 'puzzle' ? 'bg-white text-black' : 'bg-white/10 text-white/80')}>Quebra-cabeça do dia</Btn>
      </div>
      <div className="min-h-0 flex-1 bg-[#161512]">
        <Frame src={c === 'tv' ? 'https://lichess.org/tv/frame?theme=brown&bg=dark' : 'https://lichess.org/training/frame?theme=brown&bg=dark'} title="Lichess" />
      </div>
      <TouchNote text="Widgets oficiais do lichess.org · toque direto para jogar o quebra-cabeça (tela única)" />
    </div>
  );
}

export function PhotopeaApp() {
  const eye = useContext(EyeCtx);
  return (
    <div className="flex h-full flex-col">
      <div className="min-h-0 flex-1">
        {/* Very heavy web app: loaded once (left eye) to protect memory on low-end phones */}
        {eye === 'R'
          ? <div className="flex h-full items-center justify-center bg-[#1e1e1e] p-8 text-center text-white/50">Photopea é carregado em um olho só para economizar memória.</div>
          : <Frame src="https://www.photopea.com" title="Photopea" />}
      </div>
      <TouchNote text="photopea.com · editor completo, use com toque direto (tela única) · pesado em celulares simples" />
    </div>
  );
}
