import { useContext, useEffect } from 'react';
import { create } from 'zustand';
import { Loader2, RotateCcw, ChevronLeft, ChevronRight, ArrowUp, ArrowDown, ArrowLeft, ArrowRight, Check, X as XIcon, Waves } from 'lucide-react';
import { S } from '../../core/store';
import { playNote, playDrum, sfx } from '../../core/sound';
import { Btn, EyeCtx } from '../ui';
import { TouchNote } from './MediaApps';
import { cn } from '../../utils/cn';

/* Global state (stereo: both eyes render the same app → must share state). Lists are paginated:
   fewer DOM nodes inside the 3D scene = smoother on low-end phones. */
interface Poke { id: number; name: string }
interface PokeDetail { id: number; name: string; types: string[]; h: number; w: number; stats: { n: string; v: number }[] }
interface Meal { id: string; name: string; thumb: string }
interface MealDetail { name: string; thumb: string; area: string; cat: string; ing: string[]; steps: string }
interface Country { name: string; flag: string; capital: string; pop: number; area: number; langs: string; money: string; region: string }
interface Quake { id: string; mag: number; place: string; time: number; tsunami: boolean; depth: number }
interface Book { key: string; title: string; author: string; year?: number; cover?: number }
interface Fun {
  poke: { list: Poke[]; page: number; sel: PokeDetail | null; loading: boolean; error: string };
  quiz: { order: number[]; i: number; score: number; picked: number; done: boolean };
  g2048: { b: number[]; score: number; best: number; over: boolean; won: boolean };
  recipes: { cats: string[]; cat: string; meals: Meal[]; sel: MealDetail | null; loading: boolean; error: string };
  countries: { region: string; list: Country[]; page: number; sel: Country | null; loading: boolean; error: string };
  quakes: { list: Quake[]; loading: boolean; error: string };
  books: { q: string; list: Book[]; loading: boolean; error: string };
}
const shuffle = <T,>(a: T[]) => { const r = a.slice(); for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r; };

const useF = create<Fun>(() => ({
  poke: { list: [], page: 0, sel: null, loading: false, error: '' },
  quiz: { order: [], i: 0, score: 0, picked: -1, done: false },
  g2048: { b: Array(16).fill(0), score: 0, best: Number(localStorage.getItem('blvr.2048') || 0), over: false, won: false },
  recipes: { cats: [], cat: 'Chicken', meals: [], sel: null, loading: false, error: '' },
  countries: { region: 'americas', list: [], page: 0, sel: null, loading: false, error: '' },
  quakes: { list: [], loading: false, error: '' },
  books: { q: 'Machado de Assis', list: [], loading: false, error: '' },
}));
const F = () => useF.getState();
const setF = <K extends keyof Fun>(k: K, p: Partial<Fun[K]>) => useF.setState({ [k]: { ...(F()[k] as object), ...p } } as Pick<Fun, K>);
async function getJ<T>(url: string): Promise<T> { const r = await fetch(url); if (!r.ok) throw new Error(String(r.status)); return r.json() as Promise<T>; }

function Pager({ page, pages, onPage }: { page: number; pages: number; onPage: (p: number) => void }) {
  if (pages <= 1) return null;
  return (
    <div className="flex shrink-0 items-center justify-center gap-4 py-2">
      <Btn onClick={() => onPage(Math.max(0, page - 1))} className={cn('hv flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white', page === 0 && 'opacity-30')}><ChevronLeft size={22} /></Btn>
      <span className="text-[15px] tabular-nums text-white/70">{page + 1} / {pages}</span>
      <Btn onClick={() => onPage(Math.min(pages - 1, page + 1))} className={cn('hv flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white', page >= pages - 1 && 'opacity-30')}><ChevronRight size={22} /></Btn>
    </div>
  );
}
const Loading = ({ t = 'Carregando…' }: { t?: string }) => <div className="flex items-center gap-2 p-4 text-white/60"><Loader2 className="animate-spin" /> {t}</div>;
const Err = ({ t }: { t: string }) => (t ? <div className="m-4 rounded-xl bg-red-500/10 p-3 text-sm text-red-300">{t}</div> : null);

/* ============================== Pokédex ============================== */
const ART = (id: number) => `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`;
const TYPES: Record<string, [string, string]> = {
  normal: ['Normal', '#a8a77a'], fire: ['Fogo', '#ee8130'], water: ['Água', '#6390f0'], electric: ['Elétrico', '#f7d02c'], grass: ['Planta', '#7ac74c'],
  ice: ['Gelo', '#96d9d6'], fighting: ['Lutador', '#c22e28'], poison: ['Venenoso', '#a33ea1'], ground: ['Terra', '#e2bf65'], flying: ['Voador', '#a98ff3'],
  psychic: ['Psíquico', '#f95587'], bug: ['Inseto', '#a6b91a'], rock: ['Pedra', '#b6a136'], ghost: ['Fantasma', '#735797'], dragon: ['Dragão', '#6f35fc'],
  dark: ['Sombrio', '#705746'], steel: ['Aço', '#b7b7ce'], fairy: ['Fada', '#d685ad'],
};
const STAT: Record<string, string> = { hp: 'HP', attack: 'Ataque', defense: 'Defesa', 'special-attack': 'At. Esp.', 'special-defense': 'Def. Esp.', speed: 'Velocidade' };
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

async function pokeLoad() {
  if (F().poke.list.length || F().poke.loading) return;
  setF('poke', { loading: true, error: '' });
  try {
    const j = await getJ<{ results: { name: string }[] }>('https://pokeapi.co/api/v2/pokemon?limit=151');
    setF('poke', { list: j.results.map((r, i) => ({ id: i + 1, name: cap(r.name) })), loading: false });
  } catch { setF('poke', { loading: false, error: 'Não foi possível carregar a Pokédex (sem internet?).' }); }
}
async function pokeOpen(id: number) {
  setF('poke', { loading: true });
  try {
    const p = await getJ<{ id: number; name: string; height: number; weight: number; types: { type: { name: string } }[]; stats: { base_stat: number; stat: { name: string } }[] }>(`https://pokeapi.co/api/v2/pokemon/${id}`);
    setF('poke', { loading: false, sel: { id: p.id, name: cap(p.name), types: p.types.map((t) => t.type.name), h: p.height / 10, w: p.weight / 10, stats: p.stats.map((s) => ({ n: STAT[s.stat.name] ?? s.stat.name, v: s.base_stat })) } });
  } catch { setF('poke', { loading: false, error: 'Falha ao abrir este Pokémon.' }); }
}

export function PokedexApp() {
  const eye = useContext(EyeCtx);
  const p = useF((s) => s.poke);
  useEffect(() => { if (eye !== 'R') void pokeLoad(); }, [eye]);
  const PER = 18;
  const pages = Math.ceil(p.list.length / PER);
  if (p.sel) {
    const d = p.sel;
    return (
      <div className="flex h-full">
        <div className="flex w-[420px] shrink-0 flex-col items-center justify-center p-6" style={{ background: `radial-gradient(circle, ${TYPES[d.types[0]]?.[1] ?? '#444'}55, transparent 70%)` }}>
          <img src={ART(d.id)} alt={d.name} draggable={false} className="h-[300px] w-[300px] object-contain" />
          <div className="text-[15px] text-white/50">#{String(d.id).padStart(3, '0')}</div>
          <div className="text-[34px] font-bold text-white">{d.name}</div>
          <div className="mt-2 flex gap-2">
            {d.types.map((t) => <span key={t} className="rounded-full px-4 py-1 text-[15px] font-semibold text-white" style={{ background: TYPES[t]?.[1] }}>{TYPES[t]?.[0] ?? t}</span>)}
          </div>
        </div>
        <div className="flex min-w-0 flex-1 flex-col p-6">
          <div className="mb-4 flex gap-6 text-[17px] text-white/80"><span>Altura: <b className="text-white">{d.h} m</b></span><span>Peso: <b className="text-white">{d.w} kg</b></span></div>
          {d.stats.map((s) => (
            <div key={s.n} className="mb-3 flex items-center gap-3">
              <span className="w-28 text-[15px] text-white/60">{s.n}</span>
              <span className="w-10 text-right text-[15px] tabular-nums text-white">{s.v}</span>
              <div className="h-3 flex-1 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-red-500" style={{ width: `${Math.min(100, (s.v / 180) * 100)}%` }} /></div>
            </div>
          ))}
          <div className="flex-1" />
          <div className="flex gap-2">
            <Btn onClick={() => d.id > 1 && pokeOpen(d.id - 1)} className="hv flex-1 rounded-full bg-white/10 py-3 text-center text-white">‹ Anterior</Btn>
            <Btn onClick={() => setF('poke', { sel: null })} className="hv flex-1 rounded-full bg-red-600 py-3 text-center text-white">Lista</Btn>
            <Btn onClick={() => d.id < 151 && pokeOpen(d.id + 1)} className="hv flex-1 rounded-full bg-white/10 py-3 text-center text-white">Próximo ›</Btn>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className="flex h-full flex-col">
      <Err t={p.error} />
      {p.loading && !p.list.length && <Loading />}
      <div className="grid min-h-0 flex-1 auto-rows-min grid-cols-6 gap-3 p-4">
        {p.list.slice(p.page * PER, p.page * PER + PER).map((k) => (
          <Btn key={k.id} onClick={() => pokeOpen(k.id)} className="hv flex flex-col items-center rounded-2xl bg-white/5 p-2">
            <img src={ART(k.id)} alt="" loading="lazy" draggable={false} className="h-[110px] w-[110px] object-contain" />
            <div className="text-[12px] text-white/40">#{String(k.id).padStart(3, '0')}</div>
            <div className="truncate text-[14px] text-white">{k.name}</div>
          </Btn>
        ))}
      </div>
      <Pager page={p.page} pages={pages} onPage={(page) => setF('poke', { page })} />
      <TouchNote text="Dados: pokeapi.co" />
    </div>
  );
}

/* ============================== Piano & Bateria ============================== */
const NAMES = ['Dó', 'Dó#', 'Ré', 'Ré#', 'Mi', 'Fá', 'Fá#', 'Sol', 'Sol#', 'Lá', 'Lá#', 'Si'];
const midiF = (m: number) => 440 * Math.pow(2, (m - 69) / 12);
const WHITE = [0, 2, 4, 5, 7, 9, 11];
const DRUMS: { k: Parameters<typeof playDrum>[0]; label: string; color: string }[] = [
  { k: 'kick', label: 'Bumbo', color: 'bg-red-600' }, { k: 'snare', label: 'Caixa', color: 'bg-orange-500' }, { k: 'hat', label: 'Chimbal', color: 'bg-yellow-500' },
  { k: 'clap', label: 'Palma', color: 'bg-emerald-600' }, { k: 'tom', label: 'Tom', color: 'bg-sky-600' }, { k: 'crash', label: 'Prato', color: 'bg-violet-600' },
];
export function PianoApp() {
  const whites: number[] = [];
  for (let o = 0; o < 2; o++) for (const n of WHITE) whites.push(60 + o * 12 + n);
  whites.push(84);
  const KW = 70;
  const blacks = whites.flatMap((m, i) => ([0, 2, 5, 7, 9].includes(m % 12) && i < whites.length - 1 ? [{ m: m + 1, x: (i + 1) * KW - 22 }] : []));
  return (
    <div className="flex h-full flex-col p-5">
      <div className="relative mx-auto mb-5 h-[300px]" style={{ width: whites.length * KW }}>
        {whites.map((m, i) => (
          <Btn key={m} onClick={() => playNote(midiF(m))} title={NAMES[m % 12]}
            className="hv absolute top-0 flex h-full items-end justify-center rounded-b-xl border border-black/30 bg-white pb-3 text-[13px] font-medium text-slate-500"
            style={{ left: i * KW, width: KW - 3 }}>{NAMES[m % 12]}</Btn>
        ))}
        {blacks.map((b) => (
          <Btn key={b.m} onClick={() => playNote(midiF(b.m))} title={NAMES[b.m % 12]}
            className="hv absolute top-0 z-10 h-[185px] rounded-b-lg bg-slate-900 ring-1 ring-black" style={{ left: b.x, width: 44 }} />
        ))}
      </div>
      <div className="mx-auto grid grid-cols-6 gap-3">
        {DRUMS.map((d) => (
          <Btn key={d.k} onClick={() => playDrum(d.k)} className={cn('hv flex h-[150px] w-[160px] items-center justify-center rounded-3xl text-[20px] font-semibold text-white', d.color)}>{d.label}</Btn>
        ))}
      </div>
    </div>
  );
}

/* ============================== Quiz ============================== */
const Q: { q: string; a: string[]; c: number }[] = [
  { q: 'Qual é o maior planeta do Sistema Solar?', a: ['Terra', 'Júpiter', 'Saturno', 'Netuno'], c: 1 },
  { q: 'Em que ano o Brasil foi descoberto pelos portugueses?', a: ['1492', '1500', '1530', '1822'], c: 1 },
  { q: 'Qual é a capital da Austrália?', a: ['Sydney', 'Melbourne', 'Camberra', 'Perth'], c: 2 },
  { q: 'Quantos lados tem um hexágono?', a: ['5', '6', '7', '8'], c: 1 },
  { q: 'Qual é o símbolo químico do ouro?', a: ['Ag', 'Go', 'Au', 'Or'], c: 2 },
  { q: 'Quem pintou a Mona Lisa?', a: ['Michelangelo', 'Rafael', 'Van Gogh', 'Leonardo da Vinci'], c: 3 },
  { q: 'Qual é o maior oceano da Terra?', a: ['Atlântico', 'Índico', 'Pacífico', 'Ártico'], c: 2 },
  { q: 'Quantas Copas do Mundo o Brasil venceu?', a: ['4', '5', '6', '3'], c: 1 },
  { q: 'Qual é o animal terrestre mais rápido?', a: ['Leão', 'Guepardo', 'Cavalo', 'Antílope'], c: 1 },
  { q: 'Qual gás as plantas absorvem na fotossíntese?', a: ['Oxigênio', 'Nitrogênio', 'Gás carbônico', 'Hélio'], c: 2 },
  { q: 'Quem escreveu "Dom Casmurro"?', a: ['José de Alencar', 'Machado de Assis', 'Jorge Amado', 'Clarice Lispector'], c: 1 },
  { q: 'Qual é o rio mais volumoso do mundo?', a: ['Nilo', 'Amazonas', 'Yangtzé', 'Mississipi'], c: 1 },
  { q: 'Quantos ossos tem o corpo humano adulto?', a: ['186', '206', '226', '256'], c: 1 },
  { q: 'Qual é a velocidade da luz (aprox.)?', a: ['300 mil km/s', '30 mil km/s', '3 milhões km/s', '150 mil km/s'], c: 0 },
  { q: 'Em que continente fica o Egito?', a: ['Ásia', 'Europa', 'África', 'Oceania'], c: 2 },
  { q: 'Qual é o menor país do mundo?', a: ['Mônaco', 'Vaticano', 'Malta', 'San Marino'], c: 1 },
  { q: 'Qual planeta é conhecido como Planeta Vermelho?', a: ['Vênus', 'Marte', 'Mercúrio', 'Júpiter'], c: 1 },
  { q: 'Quanto é 12 × 12?', a: ['124', '144', '132', '154'], c: 1 },
  { q: 'Qual é a língua mais falada no mundo (nativos)?', a: ['Inglês', 'Espanhol', 'Mandarim', 'Hindi'], c: 2 },
  { q: 'Quem inventou a lâmpada elétrica comercial?', a: ['Nikola Tesla', 'Thomas Edison', 'Graham Bell', 'Santos Dumont'], c: 1 },
  { q: 'Qual é a capital do Canadá?', a: ['Toronto', 'Vancouver', 'Ottawa', 'Montreal'], c: 2 },
  { q: 'Quantos minutos tem um dia?', a: ['1.440', '1.240', '1.640', '2.400'], c: 0 },
  { q: 'Qual é o maior bioma do Brasil?', a: ['Cerrado', 'Amazônia', 'Caatinga', 'Pantanal'], c: 1 },
  { q: 'Qual é o metal líquido à temperatura ambiente?', a: ['Chumbo', 'Mercúrio', 'Estanho', 'Zinco'], c: 1 },
  { q: 'Em que ano o homem pisou na Lua pela primeira vez?', a: ['1965', '1969', '1972', '1959'], c: 1 },
  { q: 'Quem é conhecido como o "Pai da Aviação" no Brasil?', a: ['Santos Dumont', 'Bartolomeu de Gusmão', 'Irmãos Wright', 'Rui Barbosa'], c: 0 },
  { q: 'Qual é o maior deserto quente do mundo?', a: ['Gobi', 'Atacama', 'Saara', 'Kalahari'], c: 2 },
  { q: 'Quantos jogadores um time de futebol tem em campo?', a: ['10', '11', '12', '9'], c: 1 },
];
const quizNew = () => setF('quiz', { order: shuffle(Q.map((_, i) => i)).slice(0, 10), i: 0, score: 0, picked: -1, done: false });
function quizPick(k: number) {
  const z = F().quiz;
  if (z.picked >= 0 || z.done) return;
  const ok = Q[z.order[z.i]].c === k;
  if (ok) sfx.pop();
  setF('quiz', { picked: k, score: z.score + (ok ? 1 : 0) });
}
function quizNext() {
  const z = F().quiz;
  if (z.i + 1 >= z.order.length) { setF('quiz', { done: true }); sfx.hold(); }
  else setF('quiz', { i: z.i + 1, picked: -1 });
}
export function QuizApp() {
  const z = useF((s) => s.quiz);
  useEffect(() => { if (!F().quiz.order.length) quizNew(); }, []);
  if (!z.order.length) return null;
  if (z.done) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-4 p-8 text-center">
        <div className="text-[64px]">{z.score >= 8 ? '🏆' : z.score >= 5 ? '👏' : '📚'}</div>
        <div className="text-[30px] font-semibold text-white">Você acertou {z.score} de {z.order.length}</div>
        <Btn onClick={quizNew} className="hv-solid flex items-center gap-2 rounded-full bg-blue-600 px-8 py-3.5 text-[18px] text-white"><RotateCcw size={20} /> Jogar de novo</Btn>
      </div>
    );
  }
  const q = Q[z.order[z.i]];
  return (
    <div className="flex h-full flex-col p-7">
      <div className="mb-2 flex justify-between text-[15px] text-white/55"><span>Pergunta {z.i + 1} de {z.order.length}</span><span>Acertos: {z.score}</span></div>
      <div className="mb-6 text-[26px] font-semibold leading-snug text-white">{q.q}</div>
      <div className="grid grid-cols-2 gap-3">
        {q.a.map((a, k) => {
          const show = z.picked >= 0;
          const good = show && k === q.c, bad = show && k === z.picked && k !== q.c;
          return (
            <Btn key={k} onClick={() => quizPick(k)} className={cn('hv flex items-center justify-between rounded-2xl px-5 py-5 text-[19px] text-white', good ? 'bg-emerald-600' : bad ? 'bg-red-600' : 'bg-white/[.07]')}>
              {a} {good && <Check size={22} />}{bad && <XIcon size={22} />}
            </Btn>
          );
        })}
      </div>
      <div className="flex-1" />
      {z.picked >= 0 && <Btn onClick={quizNext} className="hv-solid self-end rounded-full bg-blue-600 px-8 py-3.5 text-[18px] text-white">{z.i + 1 >= z.order.length ? 'Ver resultado' : 'Próxima →'}</Btn>}
    </div>
  );
}

/* ============================== 2048 ============================== */
function addTile(b: number[]) {
  const free = b.map((v, i) => (v ? -1 : i)).filter((i) => i >= 0);
  if (!free.length) return b;
  const n = b.slice();
  n[free[Math.floor(Math.random() * free.length)]] = Math.random() < 0.9 ? 2 : 4;
  return n;
}
const g2048New = () => setF('g2048', { b: addTile(addTile(Array(16).fill(0))), score: 0, over: false, won: false });
function slide(row: number[]): [number[], number] {
  const v = row.filter(Boolean);
  let pts = 0;
  for (let i = 0; i < v.length - 1; i++) if (v[i] === v[i + 1]) { v[i] *= 2; pts += v[i]; v.splice(i + 1, 1); }
  while (v.length < 4) v.push(0);
  return [v, pts];
}
function g2048Move(dir: 'l' | 'r' | 'u' | 'd') {
  const g = F().g2048;
  if (g.over) return;
  const b = g.b.slice();
  let pts = 0, moved = false;
  for (let k = 0; k < 4; k++) {
    const idx = [0, 1, 2, 3].map((j) => (dir === 'l' || dir === 'r' ? k * 4 + j : j * 4 + k));
    if (dir === 'r' || dir === 'd') idx.reverse();
    const [row, p] = slide(idx.map((i) => b[i]));
    idx.forEach((i, j) => { if (b[i] !== row[j]) moved = true; b[i] = row[j]; });
    pts += p;
  }
  if (!moved) return;
  const nb = addTile(b);
  const score = g.score + pts;
  const best = Math.max(g.best, score);
  if (best > g.best) localStorage.setItem('blvr.2048', String(best));
  const canMove = nb.some((v, i) => !v || (i % 4 < 3 && v === nb[i + 1]) || (i < 12 && v === nb[i + 4]));
  const won = g.won || nb.includes(2048);
  if (won && !g.won) { sfx.hold(); S().toast('Você chegou ao 2048! 🎉', 'ok'); }
  setF('g2048', { b: nb, score, best, over: !canMove, won });
}
const TILE: Record<number, string> = { 2: 'bg-[#eee4da] text-[#776e65]', 4: 'bg-[#ede0c8] text-[#776e65]', 8: 'bg-[#f2b179] text-white', 16: 'bg-[#f59563] text-white', 32: 'bg-[#f67c5f] text-white', 64: 'bg-[#f65e3b] text-white', 128: 'bg-[#edcf72] text-white', 256: 'bg-[#edcc61] text-white', 512: 'bg-[#edc850] text-white', 1024: 'bg-[#edc53f] text-white', 2048: 'bg-[#edc22e] text-white' };
export function Game2048App() {
  const g = useF((s) => s.g2048);
  useEffect(() => { if (!F().g2048.b.some(Boolean)) g2048New(); }, []);
  const arrow = (d: 'l' | 'r' | 'u' | 'd', Icon: typeof ArrowUp) => (
    <Btn onClick={() => g2048Move(d)} className="hv flex h-16 w-16 items-center justify-center rounded-2xl bg-white/10 text-white"><Icon size={30} /></Btn>
  );
  return (
    <div className="flex h-full flex-col items-center p-5">
      <div className="mb-3 flex w-[440px] items-center justify-between text-white">
        <div><div className="text-[13px] text-white/50">Pontos</div><div className="text-[24px] font-semibold tabular-nums">{g.score}</div></div>
        <div><div className="text-[13px] text-white/50">Recorde</div><div className="text-[24px] font-semibold tabular-nums">{g.best}</div></div>
        <Btn onClick={g2048New} className="hv flex items-center gap-2 rounded-full bg-white/10 px-4 py-2.5 text-[15px]"><RotateCcw size={18} /> Novo</Btn>
      </div>
      <div className="relative grid w-[440px] grid-cols-4 gap-2.5 rounded-2xl bg-[#bbada0] p-2.5">
        {g.b.map((v, i) => (
          <div key={i} className={cn('flex h-[96px] items-center justify-center rounded-xl font-bold', v ? TILE[v] ?? 'bg-[#3c3a32] text-white' : 'bg-[#cdc1b4]', v >= 1024 ? 'text-[30px]' : v >= 128 ? 'text-[36px]' : 'text-[42px]')}>{v || ''}</div>
        ))}
        {g.over && <div className="absolute inset-0 flex items-center justify-center rounded-2xl bg-black/60 text-[30px] font-bold text-white">Fim de jogo</div>}
      </div>
      <div className="mt-4 grid grid-cols-3 gap-2">
        <div />{arrow('u', ArrowUp)}<div />
        {arrow('l', ArrowLeft)}{arrow('d', ArrowDown)}{arrow('r', ArrowRight)}
      </div>
    </div>
  );
}

/* ============================== Receitas ============================== */
const CAT_PT: Record<string, string> = { Beef: 'Carne', Chicken: 'Frango', Dessert: 'Sobremesas', Lamb: 'Cordeiro', Pasta: 'Massas', Pork: 'Porco', Seafood: 'Frutos do mar', Vegetarian: 'Vegetariano', Vegan: 'Vegano', Breakfast: 'Café da manhã', Side: 'Acompanhamentos', Starter: 'Entradas', Goat: 'Cabrito', Miscellaneous: 'Diversos' };
async function recipesCat(cat: string) {
  setF('recipes', { cat, loading: true, error: '', sel: null });
  try {
    if (!F().recipes.cats.length) {
      const c = await getJ<{ categories: { strCategory: string }[] }>('https://www.themealdb.com/api/json/v1/1/categories.php');
      setF('recipes', { cats: c.categories.map((x) => x.strCategory) });
    }
    const j = await getJ<{ meals: { idMeal: string; strMeal: string; strMealThumb: string }[] | null }>(`https://www.themealdb.com/api/json/v1/1/filter.php?c=${encodeURIComponent(cat)}`);
    if (F().recipes.cat === cat) setF('recipes', { meals: (j.meals ?? []).slice(0, 24).map((m) => ({ id: m.idMeal, name: m.strMeal, thumb: m.strMealThumb })), loading: false });
  } catch { setF('recipes', { loading: false, error: 'Não foi possível carregar as receitas.' }); }
}
async function recipeOpen(id: string) {
  setF('recipes', { loading: true });
  try {
    const j = await getJ<{ meals: Record<string, string | null>[] }>(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${id}`);
    const m = j.meals[0];
    const ing: string[] = [];
    for (let i = 1; i <= 20; i++) { const n = m[`strIngredient${i}`]?.trim(); if (n) ing.push(`${m[`strMeasure${i}`]?.trim() ?? ''} ${n}`.trim()); }
    setF('recipes', { loading: false, sel: { name: m.strMeal ?? '', thumb: m.strMealThumb ?? '', area: m.strArea ?? '', cat: m.strCategory ?? '', ing, steps: m.strInstructions ?? '' } });
  } catch { setF('recipes', { loading: false, error: 'Falha ao abrir a receita.' }); }
}
export function RecipesApp() {
  const eye = useContext(EyeCtx);
  const r = useF((s) => s.recipes);
  useEffect(() => { if (eye !== 'R' && !F().recipes.meals.length && !F().recipes.loading) void recipesCat(F().recipes.cat); }, [eye]);
  return (
    <div className="flex h-full flex-col">
      <div data-scroll="x" className="flex shrink-0 gap-2 overflow-x-auto border-b border-white/10 px-4 py-3">
        {(r.cats.length ? r.cats : Object.keys(CAT_PT)).map((c) => (
          <Btn key={c} onClick={() => recipesCat(c)} className={cn('hv shrink-0 rounded-full px-4 py-2 text-[14px]', r.cat === c ? 'bg-orange-500 text-white' : 'bg-white/10 text-white/80')}>{CAT_PT[c] ?? c}</Btn>
        ))}
      </div>
      <Err t={r.error} />
      {r.sel ? (
        <div className="flex min-h-0 flex-1">
          <div className="w-[360px] shrink-0 p-5">
            <img src={r.sel.thumb} alt="" draggable={false} className="mb-3 h-[240px] w-full rounded-2xl object-cover" />
            <div className="text-[22px] font-semibold text-white">{r.sel.name}</div>
            <div className="mb-3 text-[14px] text-white/50">{r.sel.area} · {CAT_PT[r.sel.cat] ?? r.sel.cat}</div>
            <Btn onClick={() => setF('recipes', { sel: null })} className="hv rounded-full bg-orange-500 px-5 py-2.5 text-center text-white">← Voltar</Btn>
          </div>
          <div data-scroll className="min-w-0 flex-1 overflow-y-auto p-5 text-white/80">
            <div className="mb-2 text-[18px] font-semibold text-white">Ingredientes</div>
            <ul className="mb-4 grid grid-cols-2 gap-x-4 text-[15px]">{r.sel.ing.map((i) => <li key={i}>• {i}</li>)}</ul>
            <div className="mb-2 text-[18px] font-semibold text-white">Modo de preparo</div>
            <p className="whitespace-pre-line text-[15px] leading-relaxed">{r.sel.steps}</p>
          </div>
        </div>
      ) : (
        <div data-scroll className="grid min-h-0 flex-1 auto-rows-min grid-cols-4 gap-3 overflow-y-auto p-4">
          {r.loading && <div className="col-span-4"><Loading /></div>}
          {r.meals.map((m) => (
            <Btn key={m.id} onClick={() => recipeOpen(m.id)} className="hv overflow-hidden rounded-xl bg-white/5">
              <img src={`${m.thumb}/preview`} alt="" loading="lazy" draggable={false} className="h-[140px] w-full object-cover" />
              <div className="truncate px-2 py-2 text-[14px] text-white">{m.name}</div>
            </Btn>
          ))}
        </div>
      )}
      <TouchNote text="Receitas: TheMealDB (conteúdo em inglês)" />
    </div>
  );
}

/* ============================== Países ============================== */
const REGIONS = [['americas', 'Américas'], ['europe', 'Europa'], ['africa', 'África'], ['asia', 'Ásia'], ['oceania', 'Oceania']];
async function countriesLoad(region: string) {
  setF('countries', { region, loading: true, error: '', list: [], page: 0, sel: null });
  try {
    type RC = { name: { common: string }; translations?: { por?: { common: string } }; flags: { png: string }; capital?: string[]; population: number; area: number; languages?: Record<string, string>; currencies?: Record<string, { name: string; symbol?: string }>; subregion?: string };
    const j = await getJ<RC[]>(`https://restcountries.com/v3.1/region/${region}?fields=name,translations,flags,capital,population,area,languages,currencies,subregion`);
    const list = j.map((c) => ({
      name: c.translations?.por?.common ?? c.name.common, flag: c.flags.png, capital: c.capital?.[0] ?? '—', pop: c.population, area: c.area,
      langs: Object.values(c.languages ?? {}).join(', ') || '—', money: Object.values(c.currencies ?? {}).map((m) => `${m.name}${m.symbol ? ` (${m.symbol})` : ''}`).join(', ') || '—', region: c.subregion ?? '',
    })).sort((a, b) => a.name.localeCompare(b.name, 'pt'));
    if (F().countries.region === region) setF('countries', { list, loading: false });
  } catch { setF('countries', { loading: false, error: 'Não foi possível carregar os países.' }); }
}
export function CountriesApp() {
  const eye = useContext(EyeCtx);
  const c = useF((s) => s.countries);
  useEffect(() => { if (eye !== 'R' && !F().countries.list.length && !F().countries.loading) void countriesLoad(F().countries.region); }, [eye]);
  const PER = 20;
  const pages = Math.ceil(c.list.length / PER);
  return (
    <div className="flex h-full flex-col">
      <div className="flex shrink-0 gap-2 border-b border-white/10 px-4 py-3">
        {REGIONS.map(([k, l]) => (
          <Btn key={k} onClick={() => countriesLoad(k)} className={cn('hv rounded-full px-4 py-2 text-[14px]', c.region === k ? 'bg-emerald-600 text-white' : 'bg-white/10 text-white/80')}>{l}</Btn>
        ))}
      </div>
      <Err t={c.error} />
      {c.sel ? (
        <div className="flex min-h-0 flex-1 items-center gap-8 p-8">
          <img src={c.sel.flag} alt="" draggable={false} className="w-[380px] rounded-xl shadow-lg" />
          <div className="min-w-0 flex-1 text-[17px] text-white/75">
            <div className="mb-1 text-[34px] font-bold text-white">{c.sel.name}</div>
            <div className="mb-4 text-white/45">{c.sel.region}</div>
            <div className="mb-1">Capital: <b className="text-white">{c.sel.capital}</b></div>
            <div className="mb-1">População: <b className="text-white">{c.sel.pop.toLocaleString('pt-BR')}</b></div>
            <div className="mb-1">Área: <b className="text-white">{c.sel.area.toLocaleString('pt-BR')} km²</b></div>
            <div className="mb-1">Idiomas: <b className="text-white">{c.sel.langs}</b></div>
            <div className="mb-5">Moeda: <b className="text-white">{c.sel.money}</b></div>
            <Btn onClick={() => setF('countries', { sel: null })} className="hv w-fit rounded-full bg-emerald-600 px-6 py-3 text-white">← Voltar</Btn>
          </div>
        </div>
      ) : (
        <>
          {c.loading && <Loading />}
          <div className="grid min-h-0 flex-1 auto-rows-min grid-cols-5 gap-3 p-4">
            {c.list.slice(c.page * PER, c.page * PER + PER).map((k) => (
              <Btn key={k.name} onClick={() => setF('countries', { sel: k })} className="hv overflow-hidden rounded-xl bg-white/5">
                <img src={k.flag} alt="" loading="lazy" draggable={false} className="h-[90px] w-full object-cover" />
                <div className="truncate px-2 py-1.5 text-[14px] text-white">{k.name}</div>
              </Btn>
            ))}
          </div>
          <Pager page={c.page} pages={pages} onPage={(page) => setF('countries', { page })} />
        </>
      )}
      <TouchNote text="Dados: restcountries.com" />
    </div>
  );
}

/* ============================== Terremotos ============================== */
async function quakesLoad() {
  setF('quakes', { loading: true, error: '' });
  try {
    const j = await getJ<{ features: { id: string; properties: { mag: number; place: string; time: number; tsunami: number }; geometry: { coordinates: number[] } }[] }>('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson');
    setF('quakes', { loading: false, list: j.features.slice(0, 60).map((f) => ({ id: f.id, mag: f.properties.mag, place: f.properties.place, time: f.properties.time, tsunami: !!f.properties.tsunami, depth: f.geometry.coordinates[2] })) });
  } catch { setF('quakes', { loading: false, error: 'Não foi possível acessar o USGS.' }); }
}
const ago = (t: number) => { const m = Math.round((Date.now() - t) / 60000); return m < 60 ? `há ${m} min` : `há ${Math.round(m / 60)} h`; };
export function QuakesApp() {
  const eye = useContext(EyeCtx);
  const q = useF((s) => s.quakes);
  useEffect(() => { if (eye !== 'R' && !F().quakes.list.length) void quakesLoad(); }, [eye]);
  return (
    <div className="flex h-full flex-col">
      <div className="flex shrink-0 items-center gap-3 border-b border-white/10 px-5 py-3">
        <Waves className="text-amber-400" />
        <span className="flex-1 text-[18px] font-semibold text-white">Últimas 24 h · magnitude 2,5+</span>
        <Btn onClick={quakesLoad} className="hv rounded-full bg-white/10 px-4 py-2 text-[14px] text-white">Atualizar</Btn>
      </div>
      <Err t={q.error} />
      <div data-scroll className="min-h-0 flex-1 overflow-y-auto px-3 py-2">
        {q.loading && <Loading />}
        {q.list.map((e) => (
          <div key={e.id} className="mb-2 flex items-center gap-4 rounded-xl bg-white/5 px-4 py-3">
            <span className={cn('flex h-14 w-14 shrink-0 items-center justify-center rounded-xl text-[20px] font-bold text-white', e.mag >= 6 ? 'bg-red-600' : e.mag >= 4.5 ? 'bg-orange-500' : 'bg-amber-600/80')}>{e.mag.toFixed(1)}</span>
            <div className="min-w-0 flex-1">
              <div className="truncate text-[16px] text-white">{e.place}</div>
              <div className="text-[13px] text-white/45">{ago(e.time)} · profundidade {Math.round(e.depth)} km{e.tsunami ? ' · ⚠️ alerta de tsunami' : ''}</div>
            </div>
          </div>
        ))}
      </div>
      <TouchNote text="Dados ao vivo: USGS Earthquake Hazards Program" />
    </div>
  );
}

/* ============================== Biblioteca ============================== */
const THEMES = ['Machado de Assis', 'Harry Potter', 'Tolkien', 'Ficção científica', 'História do Brasil', 'Sherlock Holmes', 'Programação', 'Astronomia'];
async function booksLoad(q: string) {
  setF('books', { q, loading: true, error: '', list: [] });
  try {
    const j = await getJ<{ docs: { key: string; title: string; author_name?: string[]; first_publish_year?: number; cover_i?: number }[] }>(`https://openlibrary.org/search.json?q=${encodeURIComponent(q)}&limit=24&fields=key,title,author_name,first_publish_year,cover_i`);
    if (F().books.q === q) setF('books', { loading: false, list: j.docs.map((d) => ({ key: d.key, title: d.title, author: d.author_name?.[0] ?? '', year: d.first_publish_year, cover: d.cover_i })) });
  } catch { if (F().books.q === q) setF('books', { loading: false, error: 'Não foi possível acessar a Open Library.' }); }
}
export function BooksApp() {
  const eye = useContext(EyeCtx);
  const b = useF((s) => s.books);
  useEffect(() => { if (eye !== 'R' && !F().books.list.length && !F().books.loading) void booksLoad(F().books.q); }, [eye]);
  return (
    <div className="flex h-full flex-col">
      <div data-scroll="x" className="flex shrink-0 gap-2 overflow-x-auto border-b border-white/10 px-4 py-3">
        {THEMES.map((t) => (
          <Btn key={t} onClick={() => booksLoad(t)} className={cn('hv shrink-0 rounded-full px-4 py-2 text-[14px]', b.q === t ? 'bg-teal-600 text-white' : 'bg-white/10 text-white/80')}>{t}</Btn>
        ))}
      </div>
      <Err t={b.error} />
      <div data-scroll className="grid min-h-0 flex-1 auto-rows-min grid-cols-6 gap-3 overflow-y-auto p-4">
        {b.loading && <div className="col-span-6"><Loading /></div>}
        {b.list.map((k) => (
          <div key={k.key} className="overflow-hidden rounded-xl bg-white/5">
            {k.cover
              ? <img src={`https://covers.openlibrary.org/b/id/${k.cover}-M.jpg`} alt="" loading="lazy" draggable={false} className="h-[200px] w-full bg-white/5 object-cover" />
              : <div className="flex h-[200px] items-center justify-center bg-gradient-to-br from-teal-700 to-slate-800 p-3 text-center text-[14px] text-white/80">{k.title}</div>}
            <div className="px-2 pt-1.5 text-[13px] leading-tight text-white line-clamp-2">{k.title}</div>
            <div className="truncate px-2 pb-2 text-[11px] text-white/45">{k.author}{k.year ? ` · ${k.year}` : ''}</div>
          </div>
        ))}
      </div>
      <TouchNote text="Acervo: Open Library (Internet Archive)" />
    </div>
  );
}
