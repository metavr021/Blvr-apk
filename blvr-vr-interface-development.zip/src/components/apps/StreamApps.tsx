import { useContext, useEffect, useRef } from 'react';
import { create } from 'zustand';
import { Play, Pause, Volume2, VolumeX, Volume1, Search, Loader2, ExternalLink, RotateCcw } from 'lucide-react';
import { S } from '../../core/store';
import { registerKb, openKb, closeKb } from '../../core/keyboard';
import { launchAndroid } from '../../core/launcher';
import { Btn, EyeCtx } from '../ui';
import { useDeferred, TouchNote } from './MediaApps';
import { cn } from '../../utils/cn';

/**
 * Twitch & Spotify with their OFFICIAL JavaScript player APIs → the BLVR buttons control the players,
 * so they work with pinch / gaze (clicks can't reach inside third-party frames).
 *
 * Why Twitch failed before: the Twitch player refuses to play unless EVERY site that contains it is listed in
 * `parent` (BLVR inside a preview/iframe or an APK host). Now all ancestor hostnames are passed.
 */
/* eslint-disable @typescript-eslint/no-explicit-any */
declare global { interface Window { Twitch?: any; onSpotifyIframeApiReady?: (api: any) => void } }

const scripts = new Map<string, Promise<void>>();
function loadScript(src: string): Promise<void> {
  let p = scripts.get(src);
  if (!p) {
    p = new Promise<void>((res, rej) => {
      const s = document.createElement('script');
      s.src = src; s.async = true;
      s.onload = () => res();
      s.onerror = () => { scripts.delete(src); rej(new Error('script')); };
      document.head.appendChild(s);
    });
    scripts.set(src, p);
  }
  return p;
}

function parents(): string[] {
  const hs = new Set<string>();
  if (location.hostname) hs.add(location.hostname);
  const ao = (location as Location & { ancestorOrigins?: DOMStringList }).ancestorOrigins;
  if (ao) for (let i = 0; i < ao.length; i++) { try { hs.add(new URL(ao[i]).hostname); } catch { /* ignore */ } }
  return [...hs];
}

interface StreamState {
  tw: { channel: string; input: string; paused: boolean; muted: boolean; volume: number; online: boolean | null; error: string; ready: boolean };
  sp: { idx: number; paused: boolean; pos: number; dur: number; error: string; ready: boolean };
}
export const useStream = create<StreamState>(() => ({
  tw: { channel: 'gaules', input: '', paused: false, muted: false, volume: 0.6, online: null, error: '', ready: false },
  sp: { idx: 0, paused: true, pos: 0, dur: 0, error: '', ready: false },
}));
const G = () => useStream.getState();
const setTw = (p: Partial<StreamState['tw']>) => useStream.setState({ tw: { ...G().tw, ...p } });
const setSp = (p: Partial<StreamState['sp']>) => useStream.setState({ sp: { ...G().sp, ...p } });

/* ============================ Twitch ============================ */
const twPlayers = new Map<string, any>(); // one player per eye (right eye always muted)
const mainTw = () => twPlayers.get('M') ?? twPlayers.get('L');
const twAll = (fn: (p: any) => void) => twPlayers.forEach((p) => { try { fn(p); } catch { /* player not ready */ } });

export function twSetChannel(c: string) {
  const ch = c.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
  if (!ch) return;
  setTw({ channel: ch, online: null, paused: false, input: '' });
  twAll((p) => p.setChannel(ch));
}
export function twToggle() {
  const paused = !G().tw.paused;
  twAll((p) => (paused ? p.pause() : p.play()));
  setTw({ paused });
}
export function twMute() {
  const muted = !G().tw.muted;
  try { mainTw()?.setMuted(muted); } catch { /* */ }
  setTw({ muted });
}
export function twVolume(d: number) {
  const volume = Math.max(0, Math.min(1, Math.round((G().tw.volume + d) * 10) / 10));
  try { const p = mainTw(); p?.setVolume(volume); if (volume > 0) p?.setMuted(false); } catch { /* */ }
  setTw({ volume, muted: volume === 0 });
}
registerKb('twitch', {
  key: (k) => {
    const t = G().tw;
    if (k === '⌫') setTw({ input: t.input.slice(0, -1) });
    else if (k === 'clear') setTw({ input: '' });
    else if (k === '↵') { twSetChannel(t.input); closeKb(); }
    else setTw({ input: t.input + k });
  },
  open: () => true, value: () => G().tw.input, label: 'Twitch', hint: 'Digite o nome do canal e Enter',
});

const CHANNELS = ['gaules', 'casimito', 'loud_coringa', 'alanzoka', 'cellbit', 'baiano', 'tixinhadois', 'nasa', 'riotgames', 'esl_csgo'];

export function TwitchApp() {
  const eye = useContext(EyeCtx);
  const main = eye !== 'R';
  const tw = useStream((s) => s.tw);
  const ok = useDeferred();
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ok) return;
    let dead = false;
    const host = ref.current;
    loadScript('https://player.twitch.tv/js/embed/v1.js').then(() => {
      if (dead || !host || !window.Twitch) return;
      const inner = document.createElement('div');
      inner.id = `tw-${eye}-${Math.random().toString(36).slice(2)}`;
      inner.style.cssText = 'width:100%;height:100%';
      host.appendChild(inner);
      const player = new window.Twitch.Player(inner.id, {
        width: '100%', height: '100%', channel: G().tw.channel, parent: parents(), autoplay: true, muted: !main || G().tw.muted,
      });
      twPlayers.set(eye, player);
      if (main) {
        const P = window.Twitch.Player;
        player.addEventListener(P.READY, () => { setTw({ ready: true, error: '' }); try { player.setVolume(G().tw.volume); } catch { /* */ } });
        player.addEventListener(P.ONLINE, () => setTw({ online: true }));
        player.addEventListener(P.OFFLINE, () => setTw({ online: false }));
        player.addEventListener(P.PLAY, () => setTw({ paused: false }));
        player.addEventListener(P.PAUSE, () => setTw({ paused: true }));
      }
    }).catch(() => { if (main) setTw({ error: 'Não foi possível carregar o player da Twitch (sem internet?).' }); });
    return () => { dead = true; twPlayers.delete(eye); if (host) host.innerHTML = ''; };
  }, [ok, eye, main]);

  return (
    <div className="flex h-full flex-col">
      <div data-scroll="x" className="flex shrink-0 gap-2 overflow-x-auto border-b border-white/10 px-4 py-3">
        <Btn onClick={() => openKb('twitch')} className="hv flex shrink-0 items-center gap-2 rounded-full bg-violet-600 px-4 py-2 text-[14px] text-white"><Search size={16} /> Canal…</Btn>
        {CHANNELS.map((c) => (
          <Btn key={c} onClick={() => twSetChannel(c)} className={cn('hv shrink-0 rounded-full px-4 py-2 text-[14px]', tw.channel === c ? 'bg-white text-black' : 'bg-white/10 text-white/85')}>{c}</Btn>
        ))}
      </div>
      <div className="touch-frame relative min-h-0 flex-1 overflow-hidden bg-black">
        <div ref={ref} className="h-full w-full" />
        {!tw.ready && !tw.error && <div className="pointer-events-none absolute inset-0 flex items-center justify-center text-white/50"><Loader2 className="animate-spin" /></div>}
        {tw.error && <div className="absolute inset-0 flex items-center justify-center p-8 text-center text-red-300">{tw.error}</div>}
      </div>
      <div className="flex shrink-0 items-center gap-2.5 bg-[#0d1322] px-4 py-3">
        <Btn onClick={twToggle} title="Play/Pause" className="hv-solid flex h-12 w-14 items-center justify-center rounded-full bg-violet-600 text-white">
          {tw.paused ? <Play size={22} fill="white" /> : <Pause size={22} fill="white" />}
        </Btn>
        <Btn onClick={twMute} title="Som" className="hv flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-white">{tw.muted ? <VolumeX size={22} /> : <Volume2 size={22} />}</Btn>
        <Btn onClick={() => twVolume(-0.1)} title="Volume -" className="hv flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-white"><Volume1 size={22} /></Btn>
        <span className="w-12 text-center text-[14px] tabular-nums text-white/70">{Math.round(tw.volume * 100)}%</span>
        <Btn onClick={() => twVolume(0.1)} title="Volume +" className="hv flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-white"><Volume2 size={22} /></Btn>
        <div className="min-w-0 flex-1 truncate px-2 text-[16px] text-white/85">
          {tw.channel} {tw.online === true && <span className="ml-2 rounded bg-red-600 px-2 text-[12px] font-bold text-white">AO VIVO</span>}
          {tw.online === false && <span className="ml-2 rounded bg-white/15 px-2 text-[12px] text-white/70">offline</span>}
        </div>
        <Btn onClick={() => launchAndroid('twitch')} className="hv flex items-center gap-2 rounded-full bg-white/10 px-4 py-2.5 text-[14px] text-white"><ExternalLink size={16} /> App</Btn>
      </div>
    </div>
  );
}

/* ============================ Spotify ============================ */
const PLAYLISTS = [
  { n: "Today's Top Hits", id: '37i9dQZF1DXcBWIGoYBM5M' },
  { n: 'Top 50 Brasil', id: '37i9dQZEVXbMXbN3EUUhlg' },
  { n: 'Top 50 Global', id: '37i9dQZEVXbMDoHDwVN2tF' },
  { n: 'Lofi Beats', id: '37i9dQZF1DWWQRwui0ExPn' },
  { n: 'Funk Hits', id: '37i9dQZF1DWTkIwO2HDifB' },
  { n: 'Sertanejo', id: '37i9dQZF1DX5dpn9ROb26T' },
];
let spApi: Promise<any> | null = null;
function spotifyApi(): Promise<any> {
  if (!spApi) {
    spApi = new Promise((res, rej) => {
      window.onSpotifyIframeApiReady = (api: any) => res(api);
      loadScript('https://open.spotify.com/embed/iframe-api/v1').catch(rej);
      setTimeout(() => rej(new Error('timeout')), 20000);
    });
    spApi.catch(() => { spApi = null; });
  }
  return spApi;
}
const spCtl = new Map<string, any>();
const mainSp = () => spCtl.get('M') ?? spCtl.get('L');

export function spSelect(i: number) {
  setSp({ idx: i, pos: 0, dur: 0 });
  spCtl.forEach((c) => { try { c.loadUri(`spotify:playlist:${PLAYLISTS[i].id}`); } catch { /* */ } });
}
export function spToggle() { try { mainSp()?.togglePlay(); } catch { /* */ } }
export function spRestart() { try { mainSp()?.restart(); } catch { /* */ } }

const mmss = (ms: number) => `${Math.floor(ms / 60000)}:${String(Math.floor((ms % 60000) / 1000)).padStart(2, '0')}`;

export function SpotifyApp() {
  const eye = useContext(EyeCtx);
  const main = eye !== 'R';
  const sp = useStream((s) => s.sp);
  const ok = useDeferred();
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ok) return;
    let dead = false;
    const host = ref.current;
    spotifyApi().then((api) => {
      if (dead || !host) return;
      const el = document.createElement('div');
      host.appendChild(el);
      api.createController(el, { uri: `spotify:playlist:${PLAYLISTS[G().sp.idx].id}`, width: '100%', height: '100%' }, (ctl: any) => {
        if (dead) { try { ctl.destroy(); } catch { /* */ } return; }
        spCtl.set(eye, ctl);
        if (main) {
          setSp({ ready: true, error: '' });
          ctl.addListener('playback_update', (e: any) => setSp({ paused: !!e.data.isPaused, pos: e.data.position ?? 0, dur: e.data.duration ?? 0 }));
        }
      });
    }).catch(() => { if (main) setSp({ error: 'Não foi possível carregar o player do Spotify (sem internet?).' }); });
    return () => {
      dead = true;
      const c = spCtl.get(eye);
      spCtl.delete(eye);
      try { c?.destroy(); } catch { /* */ }
      if (host) host.innerHTML = '';
    };
  }, [ok, eye, main]);

  return (
    <div className="flex h-full flex-col">
      <div data-scroll="x" className="flex shrink-0 gap-2 overflow-x-auto border-b border-white/10 px-4 py-3">
        {PLAYLISTS.map((p, k) => (
          <Btn key={p.id} onClick={() => spSelect(k)} className={cn('hv shrink-0 rounded-full px-4 py-2 text-[14px]', sp.idx === k ? 'bg-green-500 text-black' : 'bg-white/10 text-white/85')}>{p.n}</Btn>
        ))}
      </div>
      <div className="touch-frame relative min-h-0 flex-1 overflow-hidden p-3">
        <div ref={ref} className="h-full w-full" />
        {!sp.ready && !sp.error && <div className="pointer-events-none absolute inset-0 flex items-center justify-center text-white/50"><Loader2 className="animate-spin" /></div>}
        {sp.error && <div className="absolute inset-0 flex items-center justify-center p-8 text-center text-red-300">{sp.error}</div>}
      </div>
      <div className="flex shrink-0 items-center gap-3 bg-[#0d1322] px-4 py-3">
        <Btn onClick={spRestart} title="Do começo" className="hv flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-white"><RotateCcw size={20} /></Btn>
        <Btn onClick={spToggle} title="Play/Pause" className="hv-solid flex h-12 w-14 items-center justify-center rounded-full bg-green-500 text-black">
          {sp.paused ? <Play size={22} fill="black" /> : <Pause size={22} fill="black" />}
        </Btn>
        <span className="text-[14px] tabular-nums text-white/60">{mmss(sp.pos)} / {mmss(sp.dur)}</span>
        <div className="flex-1" />
        <Btn onClick={() => launchAndroid('spotify')} className="hv flex items-center gap-2 rounded-full bg-white/10 px-4 py-2.5 text-[14px] text-white"><ExternalLink size={16} /> Abrir no app Spotify</Btn>
      </div>
      <TouchNote text="Player oficial do Spotify · sem login o Spotify libera prévias de 30 s por música · música completa: botão “Abrir no app”" />
    </div>
  );
}

void S;
