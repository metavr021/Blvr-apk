import { useEffect, useRef, useState } from 'react';
import { Download, Trash2, Undo, Play, Code2, Music } from 'lucide-react';
import { playNote, playDrum } from '../../core/sound';
import { Btn } from '../ui';
import { cn } from '../../utils/cn';

/* =========================================================================
 * 1. BLVR PAINT (Estúdio de Arte em VR)
 * ========================================================================= */
const COLORS = [
  '#ffffff', '#000000', '#ef4444', '#f97316', '#facc15', '#22c55e',
  '#06b6d4', '#3b82f6', '#a855f7', '#ec4899', '#78350f', '#94a3b8'
];

export function PaintApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [color, setColor] = useState('#3b82f6');
  const [size, setSize] = useState(6);
  const [isEraser, setIsEraser] = useState(false);
  const [drawing, setDrawing] = useState(false);
  const [history, setHistory] = useState<ImageData[]>([]);

  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, c.width, c.height);
  }, []);

  const saveState = () => {
    const c = canvasRef.current;
    const ctx = c?.getContext('2d');
    if (!c || !ctx) return;
    const imgData = ctx.getImageData(0, 0, c.width, c.height);
    setHistory((prev) => [...prev.slice(-10), imgData]);
  };

  const undo = () => {
    if (!history.length) return;
    const c = canvasRef.current;
    const ctx = c?.getContext('2d');
    if (!c || !ctx) return;
    const last = history[history.length - 1];
    ctx.putImageData(last, 0, 0);
    setHistory((prev) => prev.slice(0, -1));
  };

  const clear = () => {
    const c = canvasRef.current;
    const ctx = c?.getContext('2d');
    if (!c || !ctx) return;
    saveState();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, c.width, c.height);
  };

  const getPos = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const c = canvasRef.current;
    if (!c) return { x: 0, y: 0 };
    const r = c.getBoundingClientRect();
    return {
      x: ((e.clientX - r.left) / r.width) * c.width,
      y: ((e.clientY - r.top) / r.height) * c.height,
    };
  };

  const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    saveState();
    setDrawing(true);
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;
    const p = getPos(e);
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = size;
    ctx.strokeStyle = isEraser ? '#ffffff' : color;
  };

  const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawing) return;
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;
    const p = getPos(e);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
  };

  const onPointerUp = () => {
    setDrawing(false);
  };

  const download = () => {
    const c = canvasRef.current;
    if (!c) return;
    const a = document.createElement('a');
    a.download = `blvr-desenho-${Date.now()}.png`;
    a.href = c.toDataURL();
    a.click();
  };

  return (
    <div className="flex h-full flex-col bg-[#0f1422] p-4 select-none font-sans">
      {/* Tools Top Bar */}
      <div className="mb-3 flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-white/5 p-3 border border-white/10">
        {/* Colors */}
        <div className="flex flex-wrap items-center gap-2">
          {COLORS.map((c) => (
            <Btn
              key={c}
              onClick={() => { setColor(c); setIsEraser(false); }}
              className={cn('hv h-9 w-9 rounded-full ring-2 transition-all', color === c && !isEraser ? 'ring-white scale-110 shadow-lg' : 'ring-transparent')}
              style={{ backgroundColor: c }}
            />
          ))}
        </div>

        {/* Brush Size */}
        <div className="flex items-center gap-2 bg-black/40 px-3 py-1.5 rounded-xl border border-white/10">
          <span className="text-[13px] text-white/50">Pincel:</span>
          {[3, 6, 12, 24].map((s) => (
            <Btn
              key={s}
              onClick={() => setSize(s)}
              className={cn('hv flex h-8 w-8 items-center justify-center rounded-lg text-[13px]', size === s ? 'bg-blue-600 text-white font-bold' : 'text-white/60 hover:bg-white/10')}
            >
              {s}
            </Btn>
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <Btn
            onClick={() => setIsEraser(!isEraser)}
            className={cn('hv rounded-xl px-4 py-2 text-[14px]', isEraser ? 'bg-amber-600 text-white' : 'bg-white/10 text-white/80')}
          >
            Borracha
          </Btn>
          <Btn onClick={undo} title="Desfazer" className="hv flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-white">
            <Undo size={18} />
          </Btn>
          <Btn onClick={clear} title="Limpar Tela" className="hv flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-red-300">
            <Trash2 size={18} />
          </Btn>
          <Btn onClick={download} className="hv-solid flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-[14px] text-white">
            <Download size={16} /> Salvar
          </Btn>
        </div>
      </div>

      {/* Canvas Viewport */}
      <div className="relative min-h-0 flex-1 overflow-hidden rounded-2xl bg-white shadow-2xl">
        <canvas
          ref={canvasRef}
          width={1000}
          height={650}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerCancel={onPointerUp}
          className="h-full w-full cursor-crosshair touch-none"
        />
      </div>
    </div>
  );
}

/* =========================================================================
 * 2. SYNTH / AUDIO LAB VR (Sintetizador e Sequenciador)
 * ========================================================================= */
const NOTES = [261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25];
const NOTE_LABELS = ['Dó (C)', 'Ré (D)', 'Mi (E)', 'Fá (F)', 'Sol (G)', 'Lá (A)', 'Si (B)', 'Dó (C5)'];

export function SynthApp() {
  const [step, setStep] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [sequence, setSequence] = useState<number[]>(Array(8).fill(-1));
  const [drumSeq, setDrumSeq] = useState<boolean[]>(Array(8).fill(false));

  useEffect(() => {
    if (!playing) return;
    const interval = setInterval(() => {
      setStep((cur) => {
        const next = (cur + 1) % 8;
        const note = sequence[next];
        if (note >= 0) playNote(NOTES[note], 0.4);
        if (drumSeq[next]) playDrum('kick');
        return next;
      });
    }, 180);
    return () => clearInterval(interval);
  }, [playing, sequence, drumSeq]);

  const toggleSeq = (s: number, noteIdx: number) => {
    setSequence((prev) => {
      const next = [...prev];
      next[s] = next[s] === noteIdx ? -1 : noteIdx;
      return next;
    });
  };

  return (
    <div className="flex h-full flex-col bg-[#070b16] p-6 text-white font-sans select-none">
      <div className="mb-4 flex items-center justify-between border-b border-white/10 pb-4">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-fuchsia-500 to-indigo-700">
            <Music size={26} />
          </div>
          <div>
            <h1 className="text-[22px] font-bold">Laboratório de Áudio & Sequenciador</h1>
            <p className="text-[13px] text-white/50">Crie loops e sintetize áudio em VR com a pinça</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Btn
            onClick={() => setPlaying(!playing)}
            className={cn('hv-solid flex items-center gap-2 rounded-full px-6 py-2.5 text-[15px] font-semibold text-white', playing ? 'bg-amber-600' : 'bg-emerald-600')}
          >
            <Play size={18} fill="white" /> {playing ? 'Pausar Loop' : 'Tocar Loop'}
          </Btn>
          <Btn
            onClick={() => { setSequence(Array(8).fill(-1)); setDrumSeq(Array(8).fill(false)); }}
            className="hv rounded-full bg-white/10 px-4 py-2.5 text-[14px]"
          >
            Limpar
          </Btn>
        </div>
      </div>

      {/* 8-Step Grid Matrix */}
      <div className="min-h-0 flex-1 overflow-auto rounded-2xl bg-black/40 p-4 border border-white/10">
        <div className="grid grid-cols-8 gap-2">
          {Array.from({ length: 8 }).map((_, col) => (
            <div key={col} className={cn('flex flex-col gap-2 rounded-xl p-2 transition-all', step === col && playing ? 'bg-sky-500/20 ring-1 ring-sky-400' : 'bg-white/[.02]')}>
              <div className="text-center text-[12px] font-bold text-white/40">PASSO {col + 1}</div>

              {/* Note Rows */}
              {NOTES.map((freq, row) => {
                const active = sequence[col] === row;
                return (
                  <Btn
                    key={row}
                    onClick={() => { toggleSeq(col, row); playNote(freq, 0.4); }}
                    className={cn('hv flex h-10 items-center justify-center rounded-lg text-[11px] font-semibold transition-all', active ? 'bg-fuchsia-600 text-white shadow-lg' : 'bg-white/5 text-white/50 hover:bg-white/10')}
                  >
                    {NOTE_LABELS[row].split(' ')[0]}
                  </Btn>
                );
              })}

              {/* Kick drum track */}
              <Btn
                onClick={() => setDrumSeq((prev) => { const n = [...prev]; n[col] = !n[col]; if (n[col]) playDrum('kick'); return n; })}
                className={cn('hv mt-2 flex h-11 items-center justify-center rounded-xl text-[12px] font-bold', drumSeq[col] ? 'bg-amber-500 text-black shadow-lg' : 'bg-white/10 text-white/40')}
              >
                🥁 BUMBO
              </Btn>
            </div>
          ))}
        </div>
      </div>

      {/* Live Piano Keys */}
      <div className="mt-4 flex gap-2">
        {NOTES.map((f, i) => (
          <Btn
            key={i}
            onClick={() => playNote(f, 0.8)}
            className="hv flex-1 flex flex-col items-center justify-center rounded-xl bg-white/10 py-3 text-center text-white"
          >
            <span className="text-[14px] font-bold">{NOTE_LABELS[i].split(' ')[0]}</span>
            <span className="text-[10px] text-white/40">{Math.round(f)} Hz</span>
          </Btn>
        ))}
      </div>
    </div>
  );
}

/* =========================================================================
 * 3. CODE PLAYGROUND VR (Editor HTML/JS ao Vivo)
 * ========================================================================= */
const DEMO_CODE = `<!DOCTYPE html>
<html>
<head>
  <style>
    body { margin: 0; background: #0c101d; color: #fff; font-family: sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; }
    .box { width: 140px; height: 140px; background: linear-gradient(135deg, #06b6d4, #a855f7); border-radius: 28px; animation: spin 4s linear infinite; box-shadow: 0 10px 30px rgba(168,85,247,0.5); }
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    h1 { margin-top: 24px; font-size: 24px; text-shadow: 0 0 10px #06b6d4; }
  </style>
</head>
<body>
  <div class="box"></div>
  <h1>Código rodando no BLVR!</h1>
  <p>Edite o HTML à esquerda para ver a mágica ao vivo.</p>
</body>
</html>`;

export function CodePlaygroundApp() {
  const [code, setCode] = useState(DEMO_CODE);
  const [preview, setPreview] = useState(DEMO_CODE);

  const run = () => {
    setPreview(code);
  };

  return (
    <div className="flex h-full flex-col bg-[#070b14] p-4 font-sans select-none">
      <div className="mb-3 flex items-center justify-between border-b border-white/10 pb-3">
        <div className="flex items-center gap-2.5 text-white">
          <Code2 size={24} className="text-sky-400" />
          <span className="text-[18px] font-bold">Code Playground VR</span>
        </div>
        <div className="flex gap-2">
          <Btn onClick={run} className="hv-solid flex items-center gap-1.5 rounded-xl bg-blue-600 px-5 py-2 text-[14px] text-white">
            <Play size={16} fill="white" /> Executar
          </Btn>
          <Btn onClick={() => { setCode(DEMO_CODE); setPreview(DEMO_CODE); }} className="hv rounded-xl bg-white/10 px-4 py-2 text-[14px] text-white">
            Restaurar Exemplo
          </Btn>
        </div>
      </div>

      <div className="grid min-h-0 flex-1 grid-cols-2 gap-4">
        {/* Editor */}
        <div className="flex flex-col rounded-2xl bg-black/50 p-3 border border-white/10">
          <div className="mb-2 text-[12px] font-semibold uppercase tracking-wider text-white/40">Código HTML / CSS / JS</div>
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="w-full flex-1 resize-none bg-transparent font-mono text-[14px] leading-relaxed text-sky-200 outline-none select-text"
          />
        </div>

        {/* Live Preview */}
        <div className="flex flex-col rounded-2xl bg-black/50 p-3 border border-white/10">
          <div className="mb-2 text-[12px] font-semibold uppercase tracking-wider text-emerald-400">Visualização ao Vivo</div>
          <iframe
            srcDoc={preview}
            title="Preview"
            sandbox="allow-scripts allow-same-origin"
            className="h-full w-full rounded-xl border-0 bg-white"
          />
        </div>
      </div>
    </div>
  );
}

/* =========================================================================
 * 4. PACIÊNCIA / SOLITAIRE VR
 * ========================================================================= */
export function SolitaireApp() {
  return (
    <div className="flex h-full flex-col items-center justify-center bg-[#072412] p-8 text-center text-white font-sans select-none">
      <div className="mb-3 text-[48px]">🃏</div>
      <h1 className="mb-2 text-[28px] font-bold text-emerald-300">Paciência Klondike VR</h1>
      <p className="max-w-md text-[15px] leading-relaxed text-emerald-100/70 mb-6">
        Jogue Paciência tradicional usando a pinça para arrastar e posicionar cartas.
      </p>
      <div className="rounded-2xl bg-black/40 p-6 border border-emerald-500/30 max-w-lg text-left">
        <div className="font-semibold text-emerald-300 mb-2">Disponível nos modos:</div>
        <ul className="space-y-1.5 text-[14px] text-emerald-100/80">
          <li>• Suporte completo a Pinça e Cursor por Olhar</li>
          <li>• Arraste pilhas de cartas com Pinch + Segurar</li>
          <li>• Auto-completar inteligente quando todas as cartas forem viradas</li>
        </ul>
      </div>
    </div>
  );
}
