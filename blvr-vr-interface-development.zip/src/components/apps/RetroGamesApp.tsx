import { useEffect } from 'react';
import { create } from 'zustand';
import { RotateCw, ArrowLeft, ArrowRight, ArrowDown, ArrowUp, RotateCcw, Trophy, Play, Pause, Zap } from 'lucide-react';
import { sfx } from '../../core/sound';
import { Btn } from '../ui';
import { cn } from '../../utils/cn';

/* =========================================================================
 * 1. TETRIS VR (Classic Falling Blocks)
 * ========================================================================= */
const COLS = 10, ROWS = 20;
const SHAPES = [
  [[1, 1, 1, 1]], // I (cyan)
  [[2, 0, 0], [2, 2, 2]], // J (blue)
  [[0, 0, 3], [3, 3, 3]], // L (orange)
  [[4, 4], [4, 4]], // O (yellow)
  [[0, 5, 5], [5, 5, 0]], // S (green)
  [[0, 6, 0], [6, 6, 6]], // T (purple)
  [[7, 7, 0], [0, 7, 7]], // Z (red)
];
const COLORS = [
  'bg-transparent',
  'bg-cyan-400 shadow-[inset_0_0_8px_rgba(255,255,255,0.6)]',
  'bg-blue-600 shadow-[inset_0_0_8px_rgba(255,255,255,0.6)]',
  'bg-orange-500 shadow-[inset_0_0_8px_rgba(255,255,255,0.6)]',
  'bg-yellow-400 shadow-[inset_0_0_8px_rgba(255,255,255,0.6)]',
  'bg-emerald-500 shadow-[inset_0_0_8px_rgba(255,255,255,0.6)]',
  'bg-purple-600 shadow-[inset_0_0_8px_rgba(255,255,255,0.6)]',
  'bg-red-500 shadow-[inset_0_0_8px_rgba(255,255,255,0.6)]',
];

interface TetrisState {
  grid: number[][];
  piece: number[][];
  pieceX: number;
  pieceY: number;
  score: number;
  lines: number;
  level: number;
  over: boolean;
  paused: boolean;
  high: number;
}

const emptyGrid = () => Array.from({ length: ROWS }, () => Array(COLS).fill(0));
const randPiece = () => SHAPES[Math.floor(Math.random() * SHAPES.length)];

export const useTetris = create<TetrisState>(() => ({
  grid: emptyGrid(),
  piece: randPiece(),
  pieceX: 3,
  pieceY: 0,
  score: 0,
  lines: 0,
  level: 1,
  over: false,
  paused: false,
  high: Number(localStorage.getItem('blvr.tetris.high') || 0),
}));

const T = () => useTetris.getState();

function collide(grid: number[][], piece: number[][], x: number, y: number): boolean {
  for (let r = 0; r < piece.length; r++) {
    for (let c = 0; c < piece[r].length; c++) {
      if (piece[r][c] !== 0) {
        const nx = x + c;
        const ny = y + r;
        if (nx < 0 || nx >= COLS || ny >= ROWS) return true;
        if (ny >= 0 && grid[ny][nx] !== 0) return true;
      }
    }
  }
  return false;
}

function rotatePiece(p: number[][]): number[][] {
  const h = p.length;
  const w = p[0].length;
  const res: number[][] = Array.from({ length: w }, () => Array(h).fill(0));
  for (let r = 0; r < h; r++) {
    for (let c = 0; c < w; c++) {
      res[c][h - 1 - r] = p[r][c];
    }
  }
  return res;
}

export function tetrisReset() {
  const p = randPiece();
  useTetris.setState({
    grid: emptyGrid(),
    piece: p,
    pieceX: Math.floor((COLS - p[0].length) / 2),
    pieceY: 0,
    score: 0,
    lines: 0,
    level: 1,
    over: false,
    paused: false,
  });
}

export function tetrisMove(dx: number) {
  const st = T();
  if (st.over || st.paused) return;
  if (!collide(st.grid, st.piece, st.pieceX + dx, st.pieceY)) {
    useTetris.setState({ pieceX: st.pieceX + dx });
  }
}

export function tetrisRotate() {
  const st = T();
  if (st.over || st.paused) return;
  const rot = rotatePiece(st.piece);
  let nx = st.pieceX;
  if (collide(st.grid, rot, nx, st.pieceY)) {
    // Wall kick
    if (!collide(st.grid, rot, nx - 1, st.pieceY)) nx--;
    else if (!collide(st.grid, rot, nx + 1, st.pieceY)) nx++;
    else return;
  }
  useTetris.setState({ piece: rot, pieceX: nx });
  sfx.click();
}

export function tetrisDrop() {
  const st = T();
  if (st.over || st.paused) return;
  if (!collide(st.grid, st.piece, st.pieceX, st.pieceY + 1)) {
    useTetris.setState({ pieceY: st.pieceY + 1 });
  } else {
    // Lock piece
    const g = st.grid.map((row) => [...row]);
    for (let r = 0; r < st.piece.length; r++) {
      for (let c = 0; c < st.piece[r].length; c++) {
        if (st.piece[r][c] !== 0) {
          const gy = st.pieceY + r;
          const gx = st.pieceX + c;
          if (gy >= 0) g[gy][gx] = st.piece[r][c];
        }
      }
    }

    // Line clearing
    let cleared = 0;
    const nextGrid = g.filter((row) => {
      const full = row.every((cell) => cell !== 0);
      if (full) cleared++;
      return !full;
    });
    while (nextGrid.length < ROWS) {
      nextGrid.unshift(Array(COLS).fill(0));
    }

    const pts = [0, 100, 300, 500, 800][cleared] * st.level;
    const newScore = st.score + pts;
    const newLines = st.lines + cleared;
    const newLevel = Math.floor(newLines / 10) + 1;
    const nextHigh = Math.max(st.high, newScore);
    if (nextHigh > st.high) localStorage.setItem('blvr.tetris.high', String(nextHigh));

    if (cleared > 0) sfx.pop();

    // Spawn new piece
    const np = randPiece();
    const nx = Math.floor((COLS - np[0].length) / 2);
    const isOver = collide(nextGrid, np, nx, 0);

    useTetris.setState({
      grid: nextGrid,
      piece: np,
      pieceX: nx,
      pieceY: 0,
      score: newScore,
      lines: newLines,
      level: newLevel,
      over: isOver,
      high: nextHigh,
    });

    if (isOver) sfx.hold();
  }
}

export function tetrisHardDrop() {
  const st = T();
  if (st.over || st.paused) return;
  let ny = st.pieceY;
  while (!collide(st.grid, st.piece, st.pieceX, ny + 1)) {
    ny++;
  }
  useTetris.setState({ pieceY: ny });
  tetrisDrop();
}

export function TetrisApp() {
  const st = useTetris();

  useEffect(() => {
    if (st.over || st.paused) return;
    const speed = Math.max(120, 800 - (st.level - 1) * 70);
    const interval = setInterval(() => {
      tetrisDrop();
    }, speed);
    return () => clearInterval(interval);
  }, [st.level, st.over, st.paused, st.grid, st.piece, st.pieceX, st.pieceY]);

  // Compute ghost piece Y
  let ghostY = st.pieceY;
  while (!collide(st.grid, st.piece, st.pieceX, ghostY + 1)) {
    ghostY++;
  }

  // Render combined view
  const display = st.grid.map((row) => [...row]);
  // Ghost
  for (let r = 0; r < st.piece.length; r++) {
    for (let c = 0; c < st.piece[r].length; c++) {
      if (st.piece[r][c] !== 0) {
        const y = ghostY + r;
        const x = st.pieceX + c;
        if (y >= 0 && y < ROWS && display[y][x] === 0) {
          display[y][x] = -1; // ghost
        }
      }
    }
  }
  // Active
  for (let r = 0; r < st.piece.length; r++) {
    for (let c = 0; c < st.piece[r].length; c++) {
      if (st.piece[r][c] !== 0) {
        const y = st.pieceY + r;
        const x = st.pieceX + c;
        if (y >= 0 && y < ROWS) {
          display[y][x] = st.piece[r][c];
        }
      }
    }
  }

  return (
    <div className="flex h-full items-center justify-center gap-8 bg-[#070b14] p-6 select-none">
      {/* Game Board */}
      <div className="relative rounded-2xl border-2 border-white/20 bg-black/80 p-2 shadow-2xl">
        <div className="grid grid-cols-10 gap-1 bg-[#02040a] p-1.5 rounded-xl">
          {display.map((row, r) =>
            row.map((cell, c) => (
              <div
                key={`${r}-${c}`}
                className={cn(
                  'h-7 w-7 rounded-sm border border-black/40 transition-colors',
                  cell === -1 ? 'border-dashed border-white/30 bg-white/5' : COLORS[cell] || 'bg-white/[.02]'
                )}
              />
            ))
          )}
        </div>

        {st.over && (
          <div className="absolute inset-0 flex flex-col items-center justify-center rounded-2xl bg-black/85 text-center">
            <Trophy size={48} className="mb-2 text-amber-400" />
            <div className="text-[26px] font-bold text-white">Fim de Jogo!</div>
            <div className="mb-4 text-[16px] text-white/60">Pontuação: {st.score}</div>
            <Btn onClick={tetrisReset} className="hv-solid rounded-full bg-blue-600 px-6 py-2.5 text-[15px] text-white">
              Jogar Novamente
            </Btn>
          </div>
        )}
      </div>

      {/* Side Stats & Controls */}
      <div className="flex w-[260px] flex-col gap-4">
        <div className="rounded-2xl bg-white/5 p-4 space-y-2 border border-white/10">
          <div>
            <div className="text-[12px] uppercase text-white/40">Pontuação</div>
            <div className="text-[28px] font-bold text-sky-300 tabular-nums">{st.score}</div>
          </div>
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/10">
            <div>
              <div className="text-[11px] uppercase text-white/40">Linhas</div>
              <div className="text-[18px] font-semibold text-white tabular-nums">{st.lines}</div>
            </div>
            <div>
              <div className="text-[11px] uppercase text-white/40">Nível</div>
              <div className="text-[18px] font-semibold text-white tabular-nums">{st.level}</div>
            </div>
          </div>
          <div className="pt-2 border-t border-white/10">
            <div className="text-[11px] uppercase text-white/40">Recorde</div>
            <div className="text-[18px] font-semibold text-amber-300 tabular-nums">{st.high}</div>
          </div>
        </div>

        {/* Big Touch / Pinch D-Pad Controls */}
        <div className="grid grid-cols-3 gap-2">
          <Btn onClick={() => tetrisMove(-1)} title="Esquerda" className="hv flex h-14 items-center justify-center rounded-2xl bg-white/10 text-white">
            <ArrowLeft size={24} />
          </Btn>
          <Btn onClick={tetrisRotate} title="Girar Peça" className="hv flex h-14 items-center justify-center rounded-2xl bg-sky-600 text-white shadow-lg">
            <RotateCw size={24} />
          </Btn>
          <Btn onClick={() => tetrisMove(1)} title="Direita" className="hv flex h-14 items-center justify-center rounded-2xl bg-white/10 text-white">
            <ArrowRight size={24} />
          </Btn>
          <Btn onClick={tetrisDrop} title="Descer Suave" className="hv flex h-14 items-center justify-center rounded-2xl bg-white/10 text-white">
            <ArrowDown size={24} />
          </Btn>
          <Btn onClick={tetrisHardDrop} title="Descer Direto (Hard Drop)" className="hv col-span-2 flex h-14 items-center justify-center gap-1.5 rounded-2xl bg-amber-600 text-white font-semibold">
            <Zap size={20} /> Soltar
          </Btn>
        </div>

        <div className="flex gap-2">
          <Btn
            onClick={() => useTetris.setState({ paused: !st.paused })}
            className="hv flex flex-1 items-center justify-center gap-2 rounded-xl bg-white/10 py-2.5 text-[14px] text-white"
          >
            {st.paused ? <><Play size={16} /> Continuar</> : <><Pause size={16} /> Pausar</>}
          </Btn>
          <Btn onClick={tetrisReset} title="Reiniciar" className="hv flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-white">
            <RotateCcw size={18} />
          </Btn>
        </div>
      </div>
    </div>
  );
}

/* =========================================================================
 * 2. SNAKE 3D / COBRINHA RETRO
 * ========================================================================= */
const S_COLS = 20, S_ROWS = 16;
type Point = { x: number; y: number };

interface SnakeState {
  snake: Point[];
  dir: Point;
  food: Point;
  score: number;
  high: number;
  over: boolean;
  run: boolean;
}

const randFood = (snake: Point[]): Point => {
  let pt: Point;
  do {
    pt = { x: Math.floor(Math.random() * S_COLS), y: Math.floor(Math.random() * S_ROWS) };
  } while (snake.some((s) => s.x === pt.x && s.y === pt.y));
  return pt;
};

export const useSnake = create<SnakeState>(() => {
  const initialSnake = [{ x: 8, y: 8 }, { x: 7, y: 8 }, { x: 6, y: 8 }];
  return {
    snake: initialSnake,
    dir: { x: 1, y: 0 },
    food: randFood(initialSnake),
    score: 0,
    high: Number(localStorage.getItem('blvr.snake.high') || 0),
    over: false,
    run: false,
  };
});

const S_STATE = () => useSnake.getState();

export function snakeReset() {
  const init = [{ x: 8, y: 8 }, { x: 7, y: 8 }, { x: 6, y: 8 }];
  useSnake.setState({
    snake: init,
    dir: { x: 1, y: 0 },
    food: randFood(init),
    score: 0,
    over: false,
    run: true,
  });
}

export function snakeSetDir(dx: number, dy: number) {
  const { dir, run, over } = S_STATE();
  if (over) return;
  if (!run) useSnake.setState({ run: true });
  // Cannot reverse directly
  if (dir.x + dx === 0 && dir.y + dy === 0) return;
  useSnake.setState({ dir: { x: dx, y: dy } });
}

export function SnakeApp() {
  const st = useSnake();

  useEffect(() => {
    if (st.over || !st.run) return;
    const interval = setInterval(() => {
      const { snake, dir, food, score, high } = S_STATE();
      const head = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };

      // Wall collision (warp or die)
      if (head.x < 0 || head.x >= S_COLS || head.y < 0 || head.y >= S_ROWS) {
        useSnake.setState({ over: true, run: false });
        sfx.hold();
        return;
      }

      // Self collision
      if (snake.some((s) => s.x === head.x && s.y === head.y)) {
        useSnake.setState({ over: true, run: false });
        sfx.hold();
        return;
      }

      const nextSnake = [head, ...snake];
      if (head.x === food.x && head.y === food.y) {
        const nextScore = score + 10;
        const nextHigh = Math.max(high, nextScore);
        if (nextHigh > high) localStorage.setItem('blvr.snake.high', String(nextHigh));
        sfx.pop();
        useSnake.setState({
          snake: nextSnake,
          food: randFood(nextSnake),
          score: nextScore,
          high: nextHigh,
        });
      } else {
        nextSnake.pop();
        useSnake.setState({ snake: nextSnake });
      }
    }, 140);

    return () => clearInterval(interval);
  }, [st.over, st.run]);

  return (
    <div className="flex h-full flex-col items-center justify-center gap-4 bg-[#0a0f1d] p-6 select-none font-sans">
      <div className="flex w-full max-w-lg items-center justify-between text-white">
        <div className="flex items-center gap-4">
          <div>
            <div className="text-[12px] uppercase text-white/50">Comprimento</div>
            <div className="text-[22px] font-bold text-emerald-400 tabular-nums">{st.score}</div>
          </div>
          <div>
            <div className="text-[12px] uppercase text-white/50">Recorde</div>
            <div className="text-[22px] font-bold text-amber-300 tabular-nums">{st.high}</div>
          </div>
        </div>
        <Btn onClick={snakeReset} className="hv flex items-center gap-1.5 rounded-full bg-white/10 px-4 py-2 text-[14px]">
          <RotateCcw size={16} /> Reiniciar
        </Btn>
      </div>

      {/* Grid */}
      <div className="relative rounded-2xl border-2 border-emerald-500/30 bg-black/80 p-2 shadow-2xl">
        <div className="grid grid-cols-20 gap-1 bg-[#050912] p-1.5 rounded-xl">
          {Array.from({ length: S_ROWS }).map((_, r) =>
            Array.from({ length: S_COLS }).map((_, c) => {
              const isHead = st.snake[0]?.x === c && st.snake[0]?.y === r;
              const isBody = st.snake.slice(1).some((s) => s.x === c && s.y === r);
              const isFood = st.food.x === c && st.food.y === r;
              return (
                <div
                  key={`${r}-${c}`}
                  className={cn(
                    'h-6 w-6 rounded-sm transition-all',
                    isHead ? 'bg-emerald-400 shadow-[0_0_10px_#34d399]' :
                    isBody ? 'bg-emerald-600' :
                    isFood ? 'bg-red-500 animate-pulse shadow-[0_0_8px_#ef4444]' :
                    'bg-white/[.02]'
                  )}
                />
              );
            })
          )}
        </div>

        {st.over && (
          <div className="absolute inset-0 flex flex-col items-center justify-center rounded-2xl bg-black/80 text-center">
            <div className="text-[28px] font-bold text-white mb-2">Fim de Jogo!</div>
            <div className="mb-4 text-[16px] text-white/60">Pontos: {st.score}</div>
            <Btn onClick={snakeReset} className="hv-solid rounded-full bg-emerald-600 px-6 py-2.5 text-[15px] text-white">
              Jogar Novamente
            </Btn>
          </div>
        )}
      </div>

      {/* D-Pad */}
      <div className="grid grid-cols-3 gap-2 w-48">
        <div />
        <Btn onClick={() => snakeSetDir(0, -1)} className="hv flex h-12 items-center justify-center rounded-xl bg-white/10 text-white">
          <ArrowUp size={22} />
        </Btn>
        <div />
        <Btn onClick={() => snakeSetDir(-1, 0)} className="hv flex h-12 items-center justify-center rounded-xl bg-white/10 text-white">
          <ArrowLeft size={22} />
        </Btn>
        <Btn onClick={() => snakeSetDir(0, 1)} className="hv flex h-12 items-center justify-center rounded-xl bg-white/10 text-white">
          <ArrowDown size={22} />
        </Btn>
        <Btn onClick={() => snakeSetDir(1, 0)} className="hv flex h-12 items-center justify-center rounded-xl bg-white/10 text-white">
          <ArrowRight size={22} />
        </Btn>
      </div>
    </div>
  );
}
