import { useContext, useEffect, useState } from 'react';
import { Play, Pause, Rewind, FastForward, Volume2, VolumeX, Link2, Radio as RadioIcon, Loader2, RefreshCw, Globe2, MapPin, Search, Monitor } from 'lucide-react';
import { useStore } from '../../core/store';
import { toggleTelao, closeTelao } from '../../core/actions';
import { useApps, YT_CATS, ytOpen, ytToggle, ytSeek, ytMute, ytSetCat, ytKeyboard, ytListen, ytTab, ytPlayer, radioLoad, radioPlay, radioStop, setSpotify, setTwitch } from '../../core/apps';
import { Btn, EyeCtx } from '../ui';
import { cn } from '../../utils/cn';

const ORIGIN = location.origin && location.origin !== 'null' ? location.origin : '';

/** Third-party frame. Pinch can't click inside cross-origin frames (browser security) – touch works in tela única. */
export function Frame({ src, title, allow }: { src: string; title: string; allow?: string }) {
  const ok = useDeferred();
  if (!ok) return <div className="flex h-full w-full items-center justify-center bg-black"><Loader2 className="animate-spin text-white/40" /></div>;
  // .touch-frame: lets touch gestures (tap, drag, zoom) reach the site inside the frame in tela única.
  // (BLVR blocks native touch gestures everywhere else – before, that also blocked them inside the apps.)
  return (
    <div className="touch-frame h-full w-full overflow-hidden">
      <iframe
        src={src}
        title={title}
        className="h-full w-full border-0 bg-black"
        allow={allow ?? 'autoplay; encrypted-media; fullscreen; picture-in-picture; clipboard-write'}
        referrerPolicy="strict-origin-when-cross-origin"
      />
    </div>
  );
}

export function TouchNote({ text }: { text: string }) {
  return <div className="shrink-0 bg-white/5 px-4 py-1.5 text-center text-[12px] text-white/50">{text}</div>;
}

/* ============================ YouTube ============================ */
const fmtDur = (s: number) => (s > 0 ? `${Math.floor(s / 3600) ? `${Math.floor(s / 3600)}:` : ''}${String(Math.floor((s % 3600) / 60)).padStart(Math.floor(s / 3600) ? 2 : 1, '0')}:${String(Math.floor(s % 60)).padStart(2, '0')}` : 'AO VIVO');

/** Mount heavy content (iframes) only after the window-open animation → opening never stutters. */
export function useDeferred(ms = 380) {
  const [ok, setOk] = useState(false);
  useEffect(() => { const t = setTimeout(() => setOk(true), ms); return () => clearTimeout(t); }, [ms]);
  return ok;
}

/**
 * The ONE YouTube player (official embed). Lives either in the YouTube window or on the telão – never both.
 * srcId only changes when the player must be (re)created; normal video switches use loadVideoById.
 * Second stereo eye: muted copy, so audio plays once.
 */
export function YtPlayer() {
  const eye = useContext(EyeCtx);
  const main = eye !== 'R';
  const srcId = useApps((s) => s.yt.srcId);
  const startAt = useApps((s) => s.yt.startAt);
  const muted = useApps((s) => s.yt.muted);
  const ready = useDeferred();
  useEffect(() => () => { if (main) ytPlayer.ready = false; }, [main]);
  const src = `https://www.youtube.com/embed/${srcId}?enablejsapi=1&autoplay=1&playsinline=1&rel=0&modestbranding=1${startAt > 0 ? `&start=${startAt}` : ''}${ORIGIN ? `&origin=${encodeURIComponent(ORIGIN)}` : ''}${main ? (muted ? '&mute=1' : '') : '&mute=1'}`;
  if (!ready) return <img src={`https://i.ytimg.com/vi/${srcId}/hqdefault.jpg`} alt="" draggable={false} className="h-full w-full object-contain opacity-60" />;
  return (
    <iframe
      key={srcId + eye}
      data-yt={main ? 'main' : 'mirror'}
      src={src}
      title="YouTube"
      className="h-full w-full border-0"
      allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
      referrerPolicy="strict-origin-when-cross-origin"
      onLoad={(e) => { const f = e.currentTarget; ytListen(f); setTimeout(() => ytListen(f), 1200); }}
    />
  );
}

export function YouTubeApp() {
  const yt = useApps((s) => s.yt);
  const telao = useStore((s) => s.telaoOpen);
  const cat = YT_CATS.find((c) => c.id === yt.cat) ?? YT_CATS[0];


  const list = yt.tab === 'search'
    ? yt.results.map((r) => ({ id: r.id, title: r.title, ch: r.ch, extra: fmtDur(r.dur) }))
    : cat.videos.map((v) => ({ id: v.id, title: v.title, ch: v.ch, extra: '' }));

  return (
    <div className="relative flex h-full">
      <div className="flex min-w-0 flex-1 flex-col bg-black">
        <div className="touch-frame relative min-h-0 flex-1 overflow-hidden">
          {telao ? (
            <div className="flex h-full flex-col items-center justify-center gap-4 bg-gradient-to-b from-zinc-900 to-black p-6 text-center">
              <Monitor size={56} className="text-red-500" />
              <div className="text-[22px] font-semibold text-white">Tocando no telão</div>
              <div className="max-w-sm text-[15px] text-white/55">Escolha vídeos aqui — eles abrem direto no telão do cenário.</div>
              <Btn onClick={closeTelao} className="hv rounded-full bg-white/10 px-5 py-2.5 text-[15px] text-white">Trazer para esta janela</Btn>
            </div>
          ) : <YtPlayer />}
        </div>
        <div className="flex shrink-0 items-center gap-2.5 bg-[#0d1322] px-4 py-3">
          <Btn onClick={() => ytSeek(-10)} title="Voltar 10 s" className="hv flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-white"><Rewind size={22} /></Btn>
          <Btn onClick={ytToggle} title="Play/Pause" className="hv-solid flex h-12 w-14 items-center justify-center rounded-full bg-red-600 text-white">
            {yt.playing ? <Pause size={24} fill="white" /> : <Play size={24} fill="white" />}
          </Btn>
          <Btn onClick={() => ytSeek(10)} title="Avançar 10 s" className="hv flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-white"><FastForward size={22} /></Btn>
          <Btn onClick={ytMute} title="Som" className="hv flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-white">
            {yt.muted ? <VolumeX size={22} /> : <Volume2 size={22} />}
          </Btn>
          <div className="min-w-0 flex-1 truncate px-2 text-[16px] text-white/85">{yt.title}</div>
          <Btn onClick={toggleTelao} title="Assistir no telão do cenário" className={cn('hv flex items-center gap-2 rounded-full px-4 py-2.5 text-[15px] text-white', telao ? 'bg-red-600' : 'bg-white/10')}>
            <Monitor size={18} /> Telão
          </Btn>
          <Btn onClick={() => ytKeyboard(true)} className="hv flex items-center gap-2 rounded-full bg-white/10 px-4 py-2.5 text-[15px] text-white">
            <Link2 size={18} /> Link
          </Btn>
        </div>
      </div>

      <div className="flex w-[360px] shrink-0 flex-col border-l border-white/10 bg-[#0b1020]">
        <div className="shrink-0 px-3 pt-3">
          <Btn onClick={() => ytKeyboard(true)} className="hv flex h-12 items-center gap-3 rounded-full bg-white/[.08] px-4 text-[15px]">
            <Search size={18} className="text-white/60" />
            <span className={cn('truncate', yt.query ? 'text-white' : 'text-white/45')}>{yt.query || 'Pesquisar no YouTube'}</span>
          </Btn>
        </div>
        <div data-scroll="x" className="flex shrink-0 gap-2 overflow-x-auto px-3 py-3">
          {(yt.results.length > 0 || yt.searching || yt.searchError) && (
            <Btn onClick={() => ytTab('search')} className={cn('hv shrink-0 rounded-full px-4 py-2 text-[14px]', yt.tab === 'search' ? 'bg-red-600 text-white' : 'bg-white/10 text-white/85')}>Resultados</Btn>
          )}
          {YT_CATS.map((c) => (
            <Btn key={c.id} onClick={() => { ytSetCat(c.id); ytTab('cats'); }} className={cn('hv shrink-0 rounded-full px-4 py-2 text-[14px]', yt.tab === 'cats' && yt.cat === c.id ? 'bg-white text-black' : 'bg-white/10 text-white/85')}>{c.label}</Btn>
          ))}
        </div>
        <div data-scroll className="min-h-0 flex-1 overflow-y-auto px-3 pb-3">
          {yt.tab === 'search' && yt.searching && <div className="flex items-center gap-2 p-3 text-[14px] text-white/60"><Loader2 size={18} className="animate-spin" /> Pesquisando “{yt.query}”…</div>}
          {yt.tab === 'search' && yt.searchError && <div className="rounded-xl bg-amber-500/10 p-3 text-[13px] text-amber-200">{yt.searchError}</div>}
          {list.map((v) => (
            <Btn key={v.id} onClick={() => ytOpen(v.id, v.title)} className={cn('hv mb-2 flex gap-3 rounded-xl p-2', yt.id === v.id && 'bg-red-600/20 ring-1 ring-red-500/50')}>
              <div className="relative h-[68px] w-[120px] shrink-0">
                <img src={`https://i.ytimg.com/vi/${v.id}/mqdefault.jpg`} alt="" loading="lazy" draggable={false} className="h-full w-full rounded-lg bg-white/5 object-cover" />
                {v.extra && <span className="absolute bottom-1 right-1 rounded bg-black/80 px-1 text-[11px] text-white">{v.extra}</span>}
              </div>
              <div className="min-w-0">
                <div className="line-clamp-2 text-[14px] font-medium leading-snug text-white">{v.title}</div>
                <div className="mt-0.5 truncate text-[12px] text-white/50">{v.ch}</div>
              </div>
            </Btn>
          ))}
        </div>
      </div>

      {/* the keyboard is the big floating one (GlobalKeyboard), outside this window */}
    </div>
  );
}

/* ============================ Rádio ============================ */
export function RadioApp() {
  const eye = useContext(EyeCtx);
  const r = useApps((s) => s.radio);
  useEffect(() => { if (eye !== 'R' && !r.list.length && !r.loading) void radioLoad(); }, [eye]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="flex h-full flex-col">
      <div className="flex shrink-0 items-center gap-2 border-b border-white/10 px-4 py-3">
        <Btn onClick={() => radioLoad('br')} className={cn('hv flex items-center gap-2 rounded-full px-4 py-2 text-[15px]', r.scope === 'br' ? 'bg-orange-500 text-white' : 'bg-white/10 text-white/80')}><MapPin size={16} /> Brasil</Btn>
        <Btn onClick={() => radioLoad('world')} className={cn('hv flex items-center gap-2 rounded-full px-4 py-2 text-[15px]', r.scope === 'world' ? 'bg-orange-500 text-white' : 'bg-white/10 text-white/80')}><Globe2 size={16} /> Mundo</Btn>
        <Btn onClick={() => radioLoad()} className="hv flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white"><RefreshCw size={18} /></Btn>
        <div className="flex-1" />
        {r.current && (
          <div className="flex min-w-0 items-center gap-3 rounded-full bg-white/[.07] py-1 pl-4 pr-1">
            <span className={cn('h-2.5 w-2.5 shrink-0 rounded-full', r.playing ? 'bg-emerald-400' : r.buffering ? 'bg-amber-400' : 'bg-white/30')} />
            <span className="max-w-[260px] truncate text-[15px] text-white">{r.current.name}</span>
            <Btn onClick={() => (r.playing ? radioStop() : radioPlay(r.current!))} className="hv-solid flex h-10 w-10 items-center justify-center rounded-full bg-orange-500 text-white">
              {r.buffering ? <Loader2 size={18} className="animate-spin" /> : r.playing ? <Pause size={18} fill="white" /> : <Play size={18} fill="white" />}
            </Btn>
          </div>
        )}
      </div>
      {r.error && <div className="mx-4 mt-3 rounded-xl bg-red-500/10 p-3 text-sm text-red-300">{r.error}</div>}
      <div data-scroll className="grid min-h-0 flex-1 auto-rows-min grid-cols-2 gap-2 overflow-y-auto p-4">
        {r.loading && <div className="col-span-2 flex items-center gap-2 text-white/60"><Loader2 className="animate-spin" /> Carregando rádios…</div>}
        {r.list.map((s) => {
          const on = r.current?.id === s.id;
          return (
            <Btn key={s.id} onClick={() => radioPlay(s)} className={cn('hv flex items-center gap-3 rounded-2xl p-3', on ? 'bg-orange-500/20 ring-1 ring-orange-400/60' : 'bg-white/5')}>
              <div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-white/10">
                {s.favicon ? <img src={s.favicon} alt="" loading="lazy" draggable={false} className="h-full w-full object-cover" onError={(e) => { e.currentTarget.style.display = 'none'; }} /> : <RadioIcon size={22} className="text-white/60" />}
              </div>
              <div className="min-w-0">
                <div className="truncate text-[15px] font-medium text-white">{s.name}</div>
                <div className="truncate text-[12px] text-white/45">{s.tags || s.country} {s.bitrate ? `· ${s.bitrate} kbps` : ''}</div>
              </div>
            </Btn>
          );
        })}
      </div>
      <TouchNote text="Diretório: radio-browser.info · somente rádios com HTTPS" />
    </div>
  );
}

/* ============================ Spotify / Twitch ============================ */
const SPOTIFY = [
  { n: "Today's Top Hits", id: '37i9dQZF1DXcBWIGoYBM5M' },
  { n: 'Top 50 Brasil', id: '37i9dQZEVXbMXbN3EUUhlg' },
  { n: 'Top 50 Global', id: '37i9dQZEVXbMDoHDwVN2tF' },
  { n: 'Lofi Beats', id: '37i9dQZF1DWWQRwui0ExPn' },
  { n: 'RapCaviar', id: '37i9dQZF1DX0XUsuxWHRQd' },
];
export function SpotifyApp() {
  const i = useApps((s) => s.spotify);
  return (
    <div className="flex h-full flex-col">
      <div data-scroll="x" className="flex shrink-0 gap-2 overflow-x-auto border-b border-white/10 px-4 py-3">
        {SPOTIFY.map((p, k) => (
          <Btn key={p.id} onClick={() => setSpotify(k)} className={cn('hv shrink-0 rounded-full px-4 py-2 text-[14px]', i === k ? 'bg-green-500 text-black' : 'bg-white/10 text-white/85')}>{p.n}</Btn>
        ))}
      </div>
      <div className="min-h-0 flex-1 p-3"><Frame src={`https://open.spotify.com/embed/playlist/${SPOTIFY[i].id}?theme=0`} title="Spotify" /></div>
      <TouchNote text="Player oficial do Spotify · toque direto no player (tela única) · sem login: prévias de 30 s" />
    </div>
  );
}

const TWITCH = ['gaules', 'casimito', 'alanzoka', 'loud_coringa', 'nasa', 'riotgames'];
export function TwitchApp() {
  const eye = useContext(EyeCtx);
  const i = useApps((s) => s.twitch);
  const host = location.hostname || 'localhost';
  return (
    <div className="flex h-full flex-col">
      <div data-scroll="x" className="flex shrink-0 gap-2 overflow-x-auto border-b border-white/10 px-4 py-3">
        {TWITCH.map((c, k) => (
          <Btn key={c} onClick={() => setTwitch(k)} className={cn('hv shrink-0 rounded-full px-4 py-2 text-[14px]', i === k ? 'bg-violet-500 text-white' : 'bg-white/10 text-white/85')}>{c}</Btn>
        ))}
      </div>
      <div className="min-h-0 flex-1">
        <Frame key={TWITCH[i] + eye} src={`https://player.twitch.tv/?channel=${TWITCH[i]}&parent=${host}&autoplay=true&muted=${eye === 'R'}`} title="Twitch" />
      </div>
      <TouchNote text="Player oficial da Twitch · canais offline mostram a tela de offline da própria Twitch" />
    </div>
  );
}
