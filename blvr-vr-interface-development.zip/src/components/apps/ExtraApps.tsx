import { useContext, useEffect, useState } from 'react';
import { create } from 'zustand';
import { Delete, RotateCcw, Play, Pause, Flag, Loader2, RefreshCw, TrendingUp, TrendingDown } from 'lucide-react';
import { S } from '../../core/store';
import { sfx } from '../../core/sound';
import { Btn, EyeCtx } from '../ui';
import { TouchNote } from './MediaApps';
import { cn } from '../../utils/cn';

/* All state is GLOBAL (one store): in stereo both eyes render the same app and must stay identical. */
type Cell = '' | 'X' | 'O';
interface Rate { code: string; name: string; bid: number; pct: number; high: number; low: number }
interface Art { id: number; title: string; artist: string; date: string; image: string }
interface Card { k: number; e: string; open: boolean; done: boolean }
interface Extra {
  calc: { expr: string; last: string };
  clock: { tab: 'world' | 'stopwatch' | 'timer'; swStart: number; swAcc: number; swRun: boolean; laps: number[]; tmTotal: number; tmEnd: number; tmLeft: number; tmRun: boolean };
  fx: { list: Rate[]; loading: boolean; error: string; at: string; amount: number };
  museum: { list: Art[]; q: string; loading: boolean; error: string; sel: number };
  ttt: { b: Cell[]; turn: 'X' | 'O'; win: '' | 'X' | 'O' | 'draw'; line: number[]; score: { X: number; O: number; draw: number } };
  mem: { cards: Card[]; first: number; moves: number; lock: boolean; won: boolean; best: number };
}
const shuffle = <T,>(a: T[]) => { const r = a.slice(); for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r; };
const EMOJIS = ['🍎', '🚀', '🎧', '🐱', '🌈', '⚽', '🍕', '🎲'];
const newDeck = (): Card[] => shuffle([...EMOJIS, ...EMOJIS]).map((e, k) => ({ k, e, open: false, done: false }));

const useX = create<Extra>(() => ({
  calc: { expr: '', last: '' },
  clock: { tab: 'world', swStart: 0, swAcc: 0, swRun: false, laps: [], tmTotal: 300, tmEnd: 0, tmLeft: 300, tmRun: false },
  fx: { list: [], loading: false, error: '', at: '', amount: 100 },
  museum: { list: [], q: 'Monet', loading: false, error: '', sel: -1 },
  ttt: { b: Array(9).fill(''), turn: 'X', win: '', line: [], score: { X: 0, O: 0, draw: 0 } },
  mem: { cards: newDeck(), first: -1, moves: 0, lock: false, won: false, best: 0 },
}));
const X = () => useX.getState();
const setX = <K extends keyof Extra>(k: K, p: Partial<Extra[K]>) => useX.setState({ [k]: { ...(X()[k] as object), ...p } } as Pick<Extra, K>);

/* =========================== Calculadora =========================== */
/** Safe recursive-descent evaluator (no eval). Supports + − × ÷ % ( ) and decimals. */
function evaluate(src: string): number {
  const t = src.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/,/g, '.');
  let i = 0;
  const num = () => {
    const s = i;
    while (i < t.length && /[\d.]/.test(t[i])) i++;
    if (s === i) throw new Error();
    const v = Number(t.slice(s, i));
    if (Number.isNaN(v)) throw new Error();
    return v;
  };
  const post = (v: number) => { while (t[i] === '%') { i++; v /= 100; } return v; };
  const factor = (): number => {
    if (t[i] === '-') { i++; return -factor(); }
    if (t[i] === '+') { i++; return factor(); }
    if (t[i] === '(') { i++; const v = expr(); if (t[i] === ')') i++; return post(v); }
    return post(num());
  };
  const term = (): number => { let v = factor(); while (t[i] === '*' || t[i] === '/') { const op = t[i++]; const r = factor(); v = op === '*' ? v * r : v / r; } return v; };
  const expr = (): number => { let v = term(); while (t[i] === '+' || t[i] === '-') { const op = t[i++]; const r = term(); v = op === '+' ? v + r : v - r; } return v; };
  const v = expr();
  if (i !== t.length) throw new Error();
  return v;
}
const fmtNum = (v: number) => (Number.isFinite(v) ? Number(v.toPrecision(12)).toLocaleString('pt-BR', { maximumFractionDigits: 10 }) : 'Erro');
function preview(expr: string) { try { return expr ? fmtNum(evaluate(expr)) : ''; } catch { return ''; } }

function calcKey(k: string) {
  const { expr } = X().calc;
  if (k === 'C') setX('calc', { expr: '', last: '' });
  else if (k === '⌫') setX('calc', { expr: expr.slice(0, -1) });
  else if (k === '=') {
    try { const v = evaluate(expr); setX('calc', { last: expr + ' =', expr: Number.isFinite(v) ? String(Number(v.toPrecision(12))) : '' }); if (!Number.isFinite(v)) S().toast('Divisão por zero', 'warn'); }
    catch { S().toast('Expressão inválida', 'warn'); }
  } else if (k === '( )') {
    const open = (expr.match(/\(/g) || []).length - (expr.match(/\)/g) || []).length;
    setX('calc', { expr: expr + (open > 0 && /[\d)%]$/.test(expr) ? ')' : '(') });
  } else {
    const ops = '+−×÷';
    if (ops.includes(k) && ops.includes(expr.slice(-1))) setX('calc', { expr: expr.slice(0, -1) + k });
    else if (expr.length < 40) setX('calc', { expr: expr + k });
  }
}

export function CalculatorApp() {
  const c = useX((s) => s.calc);
  const keys = ['C', '( )', '%', '÷', '7', '8', '9', '×', '4', '5', '6', '−', '1', '2', '3', '+', '0', '.', '⌫', '='];
  return (
    <div className="flex h-full flex-col p-5">
      <div className="mb-4 flex min-h-[150px] flex-col items-end justify-end rounded-2xl bg-black/30 px-5 py-4">
        <div className="h-6 truncate text-[17px] text-white/40">{c.last}</div>
        <div className="w-full truncate text-right text-[44px] font-light tabular-nums text-white">{c.expr || '0'}</div>
        <div className="h-7 text-[20px] tabular-nums text-sky-300/80">{c.expr && preview(c.expr) !== c.expr ? preview(c.expr) : ''}</div>
      </div>
      <div className="grid flex-1 grid-cols-4 gap-3">
        {keys.map((k) => (
          <Btn key={k} onClick={() => calcKey(k)} title={k}
            className={cn('hv flex items-center justify-center rounded-2xl text-[28px] font-medium',
              k === '=' ? 'bg-blue-600 text-white' : '÷×−+'.includes(k) ? 'bg-white/15 text-sky-300' : k === 'C' ? 'bg-white/15 text-red-300' : 'bg-white/[.07] text-white')}>
            {k === '⌫' ? <Delete size={28} /> : k}
          </Btn>
        ))}
      </div>
    </div>
  );
}

/* =========================== Relógio =========================== */
const ZONES = [
  { n: 'São Paulo', tz: 'America/Sao_Paulo' }, { n: 'Manaus', tz: 'America/Manaus' }, { n: 'Lisboa', tz: 'Europe/Lisbon' },
  { n: 'Londres', tz: 'Europe/London' }, { n: 'Nova York', tz: 'America/New_York' }, { n: 'Tóquio', tz: 'Asia/Tokyo' },
  { n: 'Dubai', tz: 'Asia/Dubai' }, { n: 'Sydney', tz: 'Australia/Sydney' },
];
function useNow(ms: number, active = true) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => { if (!active) return; const i = setInterval(() => setNow(Date.now()), ms); return () => clearInterval(i); }, [ms, active]);
  return now;
}
const fmtSw = (ms: number) => {
  const t = Math.max(0, ms);
  const m = Math.floor(t / 60000), s = Math.floor((t % 60000) / 1000), d = Math.floor((t % 1000) / 100);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${d}`;
};
const fmtTm = (sec: number) => `${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(Math.floor(sec % 60)).padStart(2, '0')}`;
const swElapsed = () => { const c = X().clock; return c.swAcc + (c.swRun ? Date.now() - c.swStart : 0); };

function swToggle() {
  const c = X().clock;
  if (c.swRun) setX('clock', { swRun: false, swAcc: c.swAcc + Date.now() - c.swStart });
  else setX('clock', { swRun: true, swStart: Date.now() });
}
const swReset = () => setX('clock', { swRun: false, swAcc: 0, laps: [] });
const swLap = () => { if (X().clock.swRun) setX('clock', { laps: [swElapsed(), ...X().clock.laps].slice(0, 20) }); };
function tmToggle() {
  const c = X().clock;
  if (c.tmRun) setX('clock', { tmRun: false, tmLeft: Math.max(0, (c.tmEnd - Date.now()) / 1000) });
  else if (c.tmLeft > 0) setX('clock', { tmRun: true, tmEnd: Date.now() + c.tmLeft * 1000 });
}
const tmSet = (sec: number) => setX('clock', { tmTotal: sec, tmLeft: sec, tmRun: false });

export function ClockApp() {
  const eye = useContext(EyeCtx);
  const c = useX((s) => s.clock);
  const now = useNow(c.tab === 'stopwatch' && c.swRun ? 100 : c.tab === 'timer' && c.tmRun ? 250 : 1000);
  const tmLeft = c.tmRun ? Math.max(0, (c.tmEnd - now) / 1000) : c.tmLeft;
  // Timer end: handled once (left/mono eye only) → no double sound/toast in stereo
  useEffect(() => {
    if (eye === 'R' || !c.tmRun || tmLeft > 0) return;
    setX('clock', { tmRun: false, tmLeft: 0 });
    sfx.hold(); setTimeout(() => sfx.hold(), 400);
    S().toast('⏰ Timer finalizado!', 'ok');
  }, [tmLeft, c.tmRun, eye]);
  const tabs: [Extra['clock']['tab'], string][] = [['world', 'Mundial'], ['stopwatch', 'Cronômetro'], ['timer', 'Timer']];
  return (
    <div className="flex h-full flex-col">
      <div className="flex shrink-0 gap-2 border-b border-white/10 px-4 py-3">
        {tabs.map(([k, l]) => (
          <Btn key={k} onClick={() => setX('clock', { tab: k })} className={cn('hv rounded-full px-5 py-2 text-[15px]', c.tab === k ? 'bg-white text-black' : 'bg-white/10 text-white/80')}>{l}</Btn>
        ))}
      </div>
      {c.tab === 'world' && (
        <div data-scroll className="grid min-h-0 flex-1 auto-rows-min grid-cols-2 gap-3 overflow-y-auto p-4">
          {ZONES.map((z) => {
            const d = new Date(now);
            return (
              <div key={z.tz} className="rounded-2xl bg-white/5 p-4">
                <div className="text-[15px] text-white/55">{z.n}</div>
                <div className="text-[36px] font-light tabular-nums text-white">{d.toLocaleTimeString('pt-BR', { timeZone: z.tz, hour: '2-digit', minute: '2-digit' })}</div>
                <div className="text-[13px] capitalize text-white/40">{d.toLocaleDateString('pt-BR', { timeZone: z.tz, weekday: 'long', day: '2-digit', month: 'short' })}</div>
              </div>
            );
          })}
        </div>
      )}
      {c.tab === 'stopwatch' && (
        <div className="flex min-h-0 flex-1 flex-col items-center p-5">
          <div className="my-4 text-[72px] font-light tabular-nums text-white">{fmtSw(c.swAcc + (c.swRun ? now - c.swStart : 0))}</div>
          <div className="mb-4 flex gap-4">
            <Btn onClick={swReset} className="hv flex h-16 w-16 items-center justify-center rounded-full bg-white/10 text-white"><RotateCcw size={26} /></Btn>
            <Btn onClick={swToggle} className={cn('hv-solid flex h-16 w-28 items-center justify-center rounded-full text-white', c.swRun ? 'bg-amber-600' : 'bg-emerald-600')}>
              {c.swRun ? <Pause size={30} fill="white" /> : <Play size={30} fill="white" />}
            </Btn>
            <Btn onClick={swLap} className="hv flex h-16 w-16 items-center justify-center rounded-full bg-white/10 text-white"><Flag size={26} /></Btn>
          </div>
          <div data-scroll className="min-h-0 w-full max-w-md flex-1 overflow-y-auto">
            {c.laps.map((l, i) => (
              <div key={i} className="flex justify-between border-b border-white/5 px-3 py-2 text-[17px] tabular-nums text-white/75">
                <span>Volta {c.laps.length - i}</span><span>{fmtSw(l)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
      {c.tab === 'timer' && (
        <div className="flex min-h-0 flex-1 flex-col items-center justify-center gap-5 p-5">
          <div className="text-[80px] font-light tabular-nums text-white">{fmtTm(Math.ceil(tmLeft))}</div>
          <div className="h-2 w-full max-w-md overflow-hidden rounded-full bg-white/10">
            <div className="h-full rounded-full bg-sky-400" style={{ width: `${c.tmTotal ? (tmLeft / c.tmTotal) * 100 : 0}%` }} />
          </div>
          <div className="flex flex-wrap justify-center gap-2">
            {[60, 180, 300, 600, 900, 1800].map((s) => (
              <Btn key={s} onClick={() => tmSet(s)} className={cn('hv rounded-full px-5 py-2.5 text-[16px]', c.tmTotal === s && !c.tmRun ? 'bg-sky-600 text-white' : 'bg-white/10 text-white/85')}>{s / 60} min</Btn>
            ))}
          </div>
          <div className="flex gap-4">
            <Btn onClick={() => tmSet(c.tmTotal)} className="hv flex h-16 w-16 items-center justify-center rounded-full bg-white/10 text-white"><RotateCcw size={26} /></Btn>
            <Btn onClick={tmToggle} className={cn('hv-solid flex h-16 w-28 items-center justify-center rounded-full text-white', c.tmRun ? 'bg-amber-600' : 'bg-emerald-600')}>
              {c.tmRun ? <Pause size={30} fill="white" /> : <Play size={30} fill="white" />}
            </Btn>
          </div>
        </div>
      )}
    </div>
  );
}

/* =========================== Câmbio =========================== */
const PAIRS = 'USD-BRL,EUR-BRL,GBP-BRL,ARS-BRL,JPY-BRL,CAD-BRL,CHF-BRL,CNY-BRL,BTC-BRL,ETH-BRL';
async function fxLoad() {
  if (X().fx.loading) return;
  setX('fx', { loading: true, error: '' });
  try {
    const r = await fetch(`https://economia.awesomeapi.com.br/json/last/${PAIRS}`);
    if (!r.ok) throw new Error();
    const j = (await r.json()) as Record<string, { code: string; name: string; bid: string; pctChange: string; high: string; low: string }>;
    const list = Object.values(j).map((v) => ({ code: v.code, name: v.name.split('/')[0], bid: Number(v.bid), pct: Number(v.pctChange), high: Number(v.high), low: Number(v.low) }));
    setX('fx', { list, loading: false, at: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) });
  } catch {
    setX('fx', { loading: false, error: 'Não foi possível obter as cotações (sem internet ou limite da API). Tente atualizar.' });
  }
}
const brl = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: v < 1 ? 4 : 2 });

export function FxApp() {
  const eye = useContext(EyeCtx);
  const f = useX((s) => s.fx);
  useEffect(() => { if (eye !== 'R' && !X().fx.list.length) void fxLoad(); }, [eye]);
  return (
    <div className="flex h-full flex-col">
      <div className="flex shrink-0 items-center gap-2 border-b border-white/10 px-4 py-3">
        <span className="text-[15px] text-white/60">Converter</span>
        {[1, 10, 100, 1000].map((a) => (
          <Btn key={a} onClick={() => setX('fx', { amount: a })} className={cn('hv rounded-full px-4 py-2 text-[15px]', f.amount === a ? 'bg-emerald-600 text-white' : 'bg-white/10 text-white/80')}>{a}</Btn>
        ))}
        <div className="flex-1" />
        {f.at && <span className="text-[13px] text-white/40">Atualizado {f.at}</span>}
        <Btn onClick={fxLoad} className="hv flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white">{f.loading ? <Loader2 size={18} className="animate-spin" /> : <RefreshCw size={18} />}</Btn>
      </div>
      {f.error && <div className="mx-4 mt-3 rounded-xl bg-red-500/10 p-3 text-sm text-red-300">{f.error}</div>}
      <div data-scroll className="grid min-h-0 flex-1 auto-rows-min grid-cols-2 gap-3 overflow-y-auto p-4">
        {f.list.map((r) => (
          <div key={r.code} className="rounded-2xl bg-white/5 p-4">
            <div className="flex items-center justify-between">
              <span className="text-[16px] font-semibold text-white">{r.code}</span>
              <span className={cn('flex items-center gap-1 text-[14px]', r.pct >= 0 ? 'text-emerald-400' : 'text-red-400')}>
                {r.pct >= 0 ? <TrendingUp size={15} /> : <TrendingDown size={15} />}{r.pct.toFixed(2)}%
              </span>
            </div>
            <div className="text-[13px] text-white/45">{r.name}</div>
            <div className="mt-1 text-[26px] font-light tabular-nums text-white">{brl(r.bid)}</div>
            <div className="text-[13px] text-white/50">{f.amount} {r.code} = <b className="text-white/80">{brl(r.bid * f.amount)}</b></div>
          </div>
        ))}
      </div>
      <TouchNote text="Cotações: AwesomeAPI (valor de compra) · apenas informativo" />
    </div>
  );
}

/* =========================== Museu =========================== */
const THEMES = ['Monet', 'Van Gogh', 'Rembrandt', 'Japão', 'Paisagem', 'Retrato', 'Gatos', 'Mar'];
async function museumLoad(q: string) {
  setX('museum', { q, loading: true, error: '', list: [], sel: -1 });
  try {
    const r = await fetch(`https://api.artic.edu/api/v1/artworks/search?q=${encodeURIComponent(q)}&query[term][is_public_domain]=true&fields=id,title,artist_display,date_display,image_id&limit=40`);
    if (!r.ok) throw new Error();
    const j = (await r.json()) as { data: { id: number; title: string; artist_display: string; date_display: string; image_id: string | null }[] };
    const list = j.data.filter((a) => a.image_id).map((a) => ({ id: a.id, title: a.title, artist: (a.artist_display || '').split('\n')[0], date: a.date_display || '', image: a.image_id! }));
    if (X().museum.q === q) setX('museum', { list, loading: false, error: list.length ? '' : 'Nenhuma obra encontrada.' });
  } catch {
    if (X().museum.q === q) setX('museum', { loading: false, error: 'Não foi possível acessar o acervo (sem internet?).' });
  }
}
const iiif = (id: string, w: number) => `https://www.artic.edu/iiif/2/${id}/full/${w},/0/default.jpg`;

export function MuseumApp() {
  const eye = useContext(EyeCtx);
  const m = useX((s) => s.museum);
  useEffect(() => { if (eye !== 'R' && !X().museum.list.length && !X().museum.loading) void museumLoad(X().museum.q); }, [eye]);
  const cur = m.sel >= 0 ? m.list[m.sel] : null;
  return (
    <div className="flex h-full flex-col">
      <div data-scroll="x" className="flex shrink-0 gap-2 overflow-x-auto border-b border-white/10 px-4 py-3">
        {THEMES.map((t) => (
          <Btn key={t} onClick={() => museumLoad(t)} className={cn('hv shrink-0 rounded-full px-4 py-2 text-[14px]', m.q === t ? 'bg-amber-600 text-white' : 'bg-white/10 text-white/80')}>{t}</Btn>
        ))}
      </div>
      {cur ? (
        <div className="flex min-h-0 flex-1">
          <div className="flex min-w-0 flex-1 items-center justify-center bg-black p-3">
            <img src={iiif(cur.image, 843)} alt={cur.title} draggable={false} className="max-h-full max-w-full object-contain" />
          </div>
          <div className="flex w-[300px] shrink-0 flex-col gap-2 p-5">
            <div className="text-[22px] font-semibold leading-snug text-white">{cur.title}</div>
            <div className="text-[15px] text-white/65">{cur.artist}</div>
            <div className="text-[14px] text-white/45">{cur.date}</div>
            <div className="flex-1" />
            <div className="flex gap-2">
              <Btn onClick={() => setX('museum', { sel: Math.max(0, m.sel - 1) })} className="hv flex-1 rounded-full bg-white/10 py-3 text-center text-white">‹ Anterior</Btn>
              <Btn onClick={() => setX('museum', { sel: Math.min(m.list.length - 1, m.sel + 1) })} className="hv flex-1 rounded-full bg-white/10 py-3 text-center text-white">Próxima ›</Btn>
            </div>
            <Btn onClick={() => setX('museum', { sel: -1 })} className="hv rounded-full bg-amber-600 py-3 text-center text-white">Voltar à galeria</Btn>
          </div>
        </div>
      ) : (
        <div data-scroll className="grid min-h-0 flex-1 auto-rows-min grid-cols-4 gap-3 overflow-y-auto p-4">
          {m.loading && <div className="col-span-4 flex items-center gap-2 text-white/60"><Loader2 className="animate-spin" /> Carregando acervo…</div>}
          {m.error && <div className="col-span-4 rounded-xl bg-red-500/10 p-3 text-sm text-red-300">{m.error}</div>}
          {m.list.map((a, i) => (
            <Btn key={a.id} onClick={() => setX('museum', { sel: i })} className="hv-lift overflow-hidden rounded-xl bg-white/5">
              <img src={iiif(a.image, 400)} alt="" loading="lazy" draggable={false} className="h-[150px] w-full bg-white/5 object-cover" />
              <div className="truncate px-2 pt-1.5 text-[13px] text-white">{a.title}</div>
              <div className="truncate px-2 pb-2 text-[11px] text-white/45">{a.artist}</div>
            </Btn>
          ))}
        </div>
      )}
      <TouchNote text="Acervo de domínio público do Art Institute of Chicago (api.artic.edu)" />
    </div>
  );
}

/* =========================== Jogo da Velha =========================== */
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
function winner(b: Cell[]): { w: '' | 'X' | 'O' | 'draw'; line: number[] } {
  for (const l of LINES) if (b[l[0]] && b[l[0]] === b[l[1]] && b[l[0]] === b[l[2]]) return { w: b[l[0]] as 'X' | 'O', line: l };
  return { w: b.every(Boolean) ? 'draw' : '', line: [] };
}
function minimax(b: Cell[], me: 'O' | 'X'): number {
  const r = winner(b).w;
  if (r === 'O') return 1;
  if (r === 'X') return -1;
  if (r === 'draw') return 0;
  let best = me === 'O' ? -2 : 2;
  for (let i = 0; i < 9; i++) if (!b[i]) {
    b[i] = me;
    const s = minimax(b, me === 'O' ? 'X' : 'O');
    b[i] = '';
    best = me === 'O' ? Math.max(best, s) : Math.min(best, s);
  }
  return best;
}
function cpuMove() {
  const t = X().ttt;
  if (t.win || t.turn !== 'O') return;
  const b = t.b.slice();
  const free = b.map((v, i) => (v ? -1 : i)).filter((i) => i >= 0);
  // 25% random move → beatable and fun; otherwise perfect play
  let pick = free[Math.floor(Math.random() * free.length)];
  if (Math.random() > 0.25) {
    let best = -2;
    for (const i of free) { b[i] = 'O'; const s = minimax(b, 'X'); b[i] = ''; if (s > best) { best = s; pick = i; } }
  }
  b[pick] = 'O';
  finishTurn(b, 'X');
}
function finishTurn(b: Cell[], next: 'X' | 'O') {
  const t = X().ttt;
  const r = winner(b);
  const score = { ...t.score };
  if (r.w) { score[r.w] += 1; if (r.w === 'X') sfx.hold(); }
  setX('ttt', { b, turn: next, win: r.w, line: r.line, score });
}
function tttPlay(i: number) {
  const t = X().ttt;
  if (t.win || t.turn !== 'X' || t.b[i]) return;
  const b = t.b.slice();
  b[i] = 'X';
  finishTurn(b, 'O');
  if (!X().ttt.win) setTimeout(cpuMove, 380);
}
const tttReset = () => setX('ttt', { b: Array(9).fill(''), turn: 'X', win: '', line: [] });

export function TicTacToeApp() {
  const t = useX((s) => s.ttt);
  const msg = t.win === 'X' ? 'Você venceu! 🎉' : t.win === 'O' ? 'O BLVR venceu' : t.win === 'draw' ? 'Empate' : t.turn === 'X' ? 'Sua vez (X)' : 'BLVR pensando…';
  return (
    <div className="flex h-full flex-col items-center p-5">
      <div className="mb-2 flex w-full justify-around text-center text-white">
        <div><div className="text-[13px] text-white/50">Você</div><div className="text-[26px] font-semibold text-sky-300">{t.score.X}</div></div>
        <div><div className="text-[13px] text-white/50">Empates</div><div className="text-[26px] font-semibold">{t.score.draw}</div></div>
        <div><div className="text-[13px] text-white/50">BLVR</div><div className="text-[26px] font-semibold text-pink-300">{t.score.O}</div></div>
      </div>
      <div className="mb-4 text-[20px] text-white/85">{msg}</div>
      <div className="grid grid-cols-3 gap-3">
        {t.b.map((v, i) => (
          <Btn key={i} onClick={() => tttPlay(i)}
            className={cn('hv flex h-[130px] w-[130px] items-center justify-center rounded-2xl text-[72px] font-bold', t.line.includes(i) ? 'bg-emerald-500/30' : 'bg-white/[.07]', v === 'X' ? 'text-sky-300' : 'text-pink-300')}>
            {v}
          </Btn>
        ))}
      </div>
      <Btn onClick={tttReset} className="hv-solid mt-5 flex items-center gap-2 rounded-full bg-blue-600 px-7 py-3 text-[17px] text-white"><RotateCcw size={20} /> Nova partida</Btn>
    </div>
  );
}

/* =========================== Memória =========================== */
function memFlip(i: number) {
  const m = X().mem;
  const c = m.cards[i];
  if (m.lock || m.won || c.open || c.done) return;
  const cards = m.cards.map((x, k) => (k === i ? { ...x, open: true } : x));
  if (m.first < 0) { setX('mem', { cards, first: i }); return; }
  const a = cards[m.first];
  const moves = m.moves + 1;
  if (a.e === c.e) {
    const done = cards.map((x, k) => (k === i || k === m.first ? { ...x, done: true } : x));
    const won = done.every((x) => x.done);
    const best = won ? (m.best ? Math.min(m.best, moves) : moves) : m.best;
    setX('mem', { cards: done, first: -1, moves, won, best });
    sfx.pop();
    if (won) { sfx.hold(); S().toast(`Você completou em ${moves} jogadas!`, 'ok'); }
  } else {
    const first = m.first;
    setX('mem', { cards, first: -1, moves, lock: true });
    setTimeout(() => {
      setX('mem', { cards: X().mem.cards.map((x, k) => (k === i || k === first ? { ...x, open: false } : x)), lock: false });
    }, 750);
  }
}
const memReset = () => setX('mem', { cards: newDeck(), first: -1, moves: 0, lock: false, won: false });

export function MemoryApp() {
  const m = useX((s) => s.mem);
  return (
    <div className="flex h-full flex-col items-center p-5">
      <div className="mb-4 flex w-full items-center justify-between px-2 text-white">
        <span className="text-[18px]">Jogadas: <b>{m.moves}</b></span>
        {m.best > 0 && <span className="text-[16px] text-white/55">Recorde: {m.best}</span>}
        <Btn onClick={memReset} className="hv flex items-center gap-2 rounded-full bg-white/10 px-5 py-2.5 text-[15px]"><RotateCcw size={18} /> Embaralhar</Btn>
      </div>
      <div className="grid grid-cols-4 gap-3">
        {m.cards.map((c, i) => (
          <Btn key={c.k} onClick={() => memFlip(i)}
            className={cn('hv flex h-[130px] w-[150px] items-center justify-center rounded-2xl text-[56px]',
              c.done ? 'bg-emerald-500/25' : c.open ? 'bg-white/20' : 'bg-gradient-to-br from-pink-500/60 to-purple-700/60')}>
            {c.open || c.done ? c.e : <span className="text-[30px] text-white/50">?</span>}
          </Btn>
        ))}
      </div>
      {m.won && <div className="mt-4 text-[20px] text-emerald-300">Parabéns! Todos os pares encontrados 🎉</div>}
    </div>
  );
}
