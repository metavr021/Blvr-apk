import { useState } from 'react';
import { Check, Plus, Info } from 'lucide-react';
import { useStore } from '../../core/store';
import { DROID, openMyApp, toggleMyApp, launchAndroid, type DroidApp } from '../../core/launcher';
import { openApp } from '../../core/actions';
import { Btn } from '../ui';
import { cn } from '../../utils/cn';

const CATS: { id: DroidApp['cat'] | 'meus'; label: string }[] = [
  { id: 'meus', label: 'Meus apps' }, { id: 'jogos', label: 'Jogos' }, { id: 'video', label: 'Vídeo' },
  { id: 'musica', label: 'Música' }, { id: 'social', label: 'Social' }, { id: 'util', label: 'Utilidades' },
];

export function AppIcon({ a, size = 'h-16 w-16 text-[24px]' }: { a: DroidApp; size?: string }) {
  return <span className={cn('flex shrink-0 items-center justify-center rounded-2xl font-bold', a.color, a.color.includes('white') || a.color.includes('yellow-3') || a.color.includes('zinc-2') ? 'text-black' : 'text-white', size)}>{a.letter}</span>;
}

export function Badge({ a }: { a: DroidApp }) {
  return a.inside
    ? <span className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-[11px] text-emerald-300">abre aqui no BLVR</span>
    : <span className="rounded bg-amber-500/15 px-1.5 py-0.5 text-[11px] text-amber-300/90">abre no celular</span>;
}

/** "Meus apps do celular": pick which phone apps appear in the BLVR menu. */
export function AndroidApp() {
  const my = useStore((s) => s.myApps);
  const [cat, setCat] = useState<(typeof CATS)[number]['id']>('meus');
  const list = cat === 'meus' ? DROID.filter((a) => my.includes(a.id)) : DROID.filter((a) => a.cat === cat);
  return (
    <div className="flex h-full flex-col">
      <div className="shrink-0 border-b border-white/10 px-5 py-3">
        <div className="flex items-start gap-2 rounded-xl bg-white/5 p-3 text-[13px] leading-relaxed text-white/60">
          <Info size={18} className="mt-0.5 shrink-0 text-sky-300" />
          <span>
            O Android não deixa sites/apps web lerem os apps instalados nem mostrarem outro app dentro de uma janela
            (só o sistema de um óculos, como o do Quest, consegue). Então: <b className="text-white/85">marque os apps que você tem</b> para
            eles aparecerem no menu do BLVR. Os marcados <b className="text-emerald-300">“abre aqui”</b> rodam numa janela do BLVR;
            os outros abrem o app de verdade no celular.
          </span>
        </div>
      </div>
      <div data-scroll="x" className="flex shrink-0 gap-2 overflow-x-auto px-5 py-3">
        {CATS.map((c) => (
          <Btn key={c.id} onClick={() => setCat(c.id)} className={cn('hv shrink-0 rounded-full px-4 py-2 text-[14px]', cat === c.id ? 'bg-white text-black' : 'bg-white/10 text-white/85')}>
            {c.label}{c.id === 'meus' ? ` (${my.length})` : ''}
          </Btn>
        ))}
      </div>
      <div data-scroll className="grid min-h-0 flex-1 auto-rows-min grid-cols-2 gap-3 overflow-y-auto px-5 pb-5">
        {cat === 'meus' && !list.length && <div className="col-span-2 p-6 text-center text-white/50">Nenhum app marcado ainda. Abra uma categoria e toque em “+ Menu”.</div>}
        {list.map((a) => {
          const on = my.includes(a.id);
          return (
            <div key={a.id} className="flex items-center gap-3 rounded-2xl bg-white/5 p-3">
              <AppIcon a={a} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-[17px] font-medium text-white">{a.name}</div>
                <div className="mt-0.5 flex flex-wrap items-center gap-1.5"><Badge a={a} />{a.note && <span className="text-[11px] text-white/40">{a.note}</span>}</div>
              </div>
              {a.alt && (
                <Btn onClick={() => openApp(a.alt!)} title="Alternativa que roda dentro do BLVR" className="hv shrink-0 rounded-xl bg-emerald-600 px-3 py-2.5 text-[13px] text-white">Jogar aqui</Btn>
              )}
              <Btn onClick={() => (a.inside ? openMyApp(a.id) : launchAndroid(a.id))} className="hv shrink-0 rounded-xl bg-white/10 px-3 py-2.5 text-[13px] text-white">Abrir</Btn>
              <Btn onClick={() => toggleMyApp(a.id)} title={on ? 'Tirar do menu' : 'Colocar no menu'}
                className={cn('hv flex shrink-0 items-center gap-1 rounded-xl px-3 py-2.5 text-[13px]', on ? 'bg-blue-600 text-white' : 'bg-white/10 text-white/85')}>
                {on ? <><Check size={15} /> No menu</> : <><Plus size={15} /> Menu</>}
              </Btn>
            </div>
          );
        })}
      </div>
    </div>
  );
}
