import { memo, useEffect, useLayoutEffect, useRef } from 'react';
import { useStore } from '../core/store';
import { eyes, type EyeId } from '../core/view';
import { camera } from '../core/camera';
import { EyeCtx } from './ui';
import { Environment } from './Environment';
import { Windows } from './Windows';
import { Menu, BottomBar, Welcome, QuickPanel } from './Menu';
import { Game } from './Game';
import { Telao } from './Telao';
import { MetaWorldView, MetaHub } from './Metaverse';
import { GlobalKeyboard } from './GlobalKeyboard';
import { cn } from '../utils/cn';

/**
 * Passthrough background. The <video> element is created ONCE per eye and never re-rendered:
 * the component subscribes to camera changes imperatively and only swaps srcObject when the
 * MediaStream object actually changes. Monocular: both eyes show the same camera image.
 * Inside the Metaverso the camera image is hidden (the camera only feeds the hand tracking).
 */
const CameraView = memo(function CameraView() {
  const ref = useRef<HTMLVideoElement>(null);
  const on = useStore((s) => s.settings.passthrough && !s.meta);
  const zoom = useStore((s) => s.settings.ptZoom);
  const bright = useStore((s) => s.settings.ptBrightness * (s.cinemaDim ? 0.3 : 1)); // Quest-style theater dimming
  useEffect(() => {
    const v = ref.current;
    if (!v) return;
    const sync = () => {
      const want = on ? camera.stream : null;
      if (v.srcObject !== want) v.srcObject = want;
      if (want && v.paused) v.play().catch(() => undefined);
      v.style.transform = `scale(${zoom})${camera.facing === 'user' ? ' scaleX(-1)' : ''}`;
    };
    sync();
    camera.listeners.add(sync);
    return () => { camera.listeners.delete(sync); };
  }, [on, zoom]);
  return (
    <video
      ref={ref}
      muted
      playsInline
      autoPlay
      disablePictureInPicture
      className="absolute inset-0 h-full w-full object-cover"
      style={{ display: on ? 'block' : 'none', filter: bright !== 1 ? `brightness(${bright})` : undefined }}
    />
  );
});

function HeadHud() {
  const toasts = useStore((s) => s.toasts);
  return (
    <div className="pointer-events-none absolute inset-x-0 top-[7%] flex flex-col items-center gap-2">
      {toasts.map((t) => (
        <div key={t.id} className={cn('anim-toast max-w-[70%] rounded-full border px-5 py-2 text-center text-[13px] font-medium text-white',
          t.kind === 'ok' ? 'border-emerald-400/30 bg-emerald-900/85' : t.kind === 'warn' ? 'border-amber-400/30 bg-amber-900/90' : 'border-white/15 bg-slate-900/85')}>
          {t.text}
        </div>
      ))}
    </div>
  );
}

/** Metaverso world, or the virtual environment when passthrough is off / the camera failed. */
function Surroundings() {
  const meta = useStore((s) => s.meta);
  const pt = useStore((s) => s.settings.passthrough);
  const camOk = useStore((s) => s.cameraStatus === 'active' || s.cameraStatus === 'starting');
  if (meta) return <MetaWorldView />;
  if (pt && camOk) return null;
  return <Environment />;
}

const World = memo(function World() {
  return (
    <>
      <Surroundings />
      <Telao />
      <Windows />
      <Welcome />
      <Menu />
      <QuickPanel />
      <MetaHub />
      <GlobalKeyboard />
      <BottomBar />
      <Game />
    </>
  );
});

export function Eye({ eye }: { eye: EyeId }) {
  const root = useRef<HTMLDivElement>(null);
  const stage = useRef<HTMLDivElement>(null);
  const world = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const dot = useRef<HTMLDivElement>(null);
  const sep = useStore((s) => s.settings.separation);
  const distortion = useStore((s) => s.settings.distortion && s.settings.displayMode === 'stereo');

  useLayoutEffect(() => {
    if (!root.current || !stage.current || !world.current || !canvas.current || !dot.current) return;
    const reg = { eye, root: root.current, stage: stage.current, world: world.current, canvas: canvas.current, dot: dot.current };
    eyes.set(eye, reg);
    return () => { if (eyes.get(eye) === reg) eyes.delete(eye); };
  }, [eye]);

  const off = eye === 'L' ? -sep / 2 : eye === 'R' ? sep / 2 : 0;
  return (
    <EyeCtx.Provider value={eye}>
      <div ref={root} data-eye={eye} className="relative h-full flex-1 overflow-hidden bg-black"
        style={{ filter: distortion ? 'url(#blvr-barrel)' : undefined }}>
        <div ref={stage} className="absolute inset-0 overflow-hidden" style={{ transform: off ? `translateX(${off}px)` : undefined, perspectiveOrigin: '50% 50%' }}>
          <CameraView />
          <div ref={world} className="absolute left-1/2 top-1/2 h-0 w-0" style={{ transformStyle: 'preserve-3d' }}>
            <World />
          </div>
          <canvas ref={canvas} className="pointer-events-none absolute inset-0 h-full w-full" />
          <div ref={dot} className="blvr-dot" data-mode="none"><i /></div>
          <HeadHud />
        </div>
      </div>
    </EyeCtx.Provider>
  );
}
