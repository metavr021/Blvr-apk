import { Trophy, Timer, LogOut, RotateCcw } from 'lucide-react';
import { useStore } from '../core/store';
import { popTarget, exitGame, startGame } from '../core/actions';
import { Btn, Placed } from './ui';
import { cn } from '../utils/cn';

export function Game() {
  const g = useStore((s) => s.game);
  if (!g.active) return null;
  const neon = g.mode === 'neonpop';
  return (
    <>
      {g.targets.map((t) => (
        <Placed key={t.id} yaw={t.yaw} pitch={t.pitch} dist={1500} w={t.size} h={t.size * 1.25}>
          <div className={cn('h-full w-full', t.popped ? 'anim-pop' : 'anim-in')}>
            <div className="h-full w-full">
              <Btn
                onClick={() => popTarget(t.id)}
                className="hv-solid relative h-[80%] w-full rounded-[50%]"
                style={{
                  background: neon
                    ? `radial-gradient(circle at 35% 30%, #fff 0, hsl(${t.hue} 100% 70%) 12%, hsl(${t.hue} 100% 45%) 55%, hsl(${t.hue} 100% 20%) 100%)`
                    : `radial-gradient(circle at 35% 30%, rgba(255,255,255,.9) 0, hsl(${t.hue} 85% 62%) 14%, hsl(${t.hue} 80% 45%) 60%, hsl(${t.hue} 75% 28%) 100%)`,
                  boxShadow: neon ? `0 0 40px hsl(${t.hue} 100% 60%)` : '0 18px 30px rgba(0,0,0,.35)',
                }}
              />
              <div className="mx-auto h-[20%] w-0.5 bg-white/50" />
            </div>
          </div>
        </Placed>
      ))}

      <Placed yaw={g.yaw} pitch={30} dist={1250} w={560} h={120} visible={!g.finished}>
        <div className={cn('flex h-full items-center gap-6 rounded-[28px] border px-7', neon ? 'border-fuchsia-400/40 bg-[#14061f]/90' : 'border-white/10 bg-[#0d1322]/90')}>
          <div className="flex items-center gap-2 text-white"><Trophy className="text-amber-300" size={30} /><span className="text-[34px] font-bold tabular-nums">{g.score}</span></div>
          <div className="flex items-center gap-2 text-white"><Timer className={g.timeLeft <= 10 ? 'text-red-400' : 'text-sky-300'} size={30} /><span className="text-[34px] font-bold tabular-nums">{g.timeLeft}s</span></div>
          <div className="flex-1" />
          <Btn onClick={exitGame} className="hv flex items-center gap-2 rounded-full bg-white/10 px-5 py-3 text-[17px] text-white"><LogOut size={20} /> Sair</Btn>
        </div>
      </Placed>

      <Placed yaw={g.yaw} pitch={4} dist={1100} w={620} h={360} visible={g.finished}>
        <div className="flex h-full flex-col items-center justify-center gap-3 rounded-[34px] border border-white/10 bg-[#0d1322]/95 text-white shadow-2xl">
          <Trophy size={56} className="text-amber-300" />
          <div className="text-[34px] font-bold">Fim de jogo!</div>
          <div className="text-[22px] text-white/80">Pontuação: <b className="text-white">{g.score}</b> · Recorde: <b className="text-amber-300">{g.best[g.mode] ?? 0}</b></div>
          <div className="mt-4 flex gap-3">
            <Btn onClick={() => startGame(g.mode)} className="hv-solid flex items-center gap-2 rounded-full bg-blue-600 px-7 py-3.5 text-[18px]"><RotateCcw size={20} /> Jogar de novo</Btn>
            <Btn onClick={exitGame} className="hv flex items-center gap-2 rounded-full bg-white/10 px-7 py-3.5 text-[18px]"><LogOut size={20} /> Sair</Btn>
          </div>
        </div>
      </Placed>
    </>
  );
}
