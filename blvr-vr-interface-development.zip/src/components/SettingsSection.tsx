import { useStore, S, type HandSide } from '../core/store';
import { recenter, setDisplayMode, setPortrait, set3dof, is3dof } from '../core/actions';
import { arrangeWindows, toggleReclined, toggleCinemaDim } from '../core/quest';
import { Btn, Row, Toggle, Stepper, Choice } from './ui';
import { cn } from '../utils/cn';

const GYRO_TXT: Record<string, string> = {
  off: 'Desligado', waiting: 'Aguardando sensor…', active: 'Ativo', unavailable: 'Sem sensor — arraste/setas para olhar', denied: 'Permissão negada',
};

function Group({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-6 rounded-2xl bg-white/[.04] px-5 py-2">
      <h2 className="pb-1 pt-3 text-[13px] font-semibold uppercase tracking-[.18em] text-sky-300">{title}</h2>
      {children}
    </section>
  );
}

function HandLive({ name, h }: { name: string; h: HandSide }) {
  return (
    <div className={cn('flex-1 rounded-xl p-3', h.present ? 'bg-emerald-500/10' : 'bg-white/5')}>
      <div className="mb-1 flex items-center justify-between">
        <span className="font-semibold text-white">{name}</span>
        <span className={cn('text-sm', h.present ? 'text-emerald-400' : 'text-white/40')}>{h.present ? 'rastreada' : 'não detectada'}</span>
      </div>
      <div className="mb-2 h-2 overflow-hidden rounded-full bg-white/10">
        <div className={cn('h-full rounded-full transition-all', h.pinching ? 'bg-sky-400' : 'bg-white/40')} style={{ width: `${h.present ? h.pinch * 100 : 0}%` }} />
      </div>
      <div className="grid grid-cols-2 gap-1 text-sm text-white/70">
        <span>Pinça: <b className={h.pinching ? 'text-sky-300' : ''}>{h.pinching ? 'SIM' : 'não'}</b></span>
        <span>Palma ↑: <b className={h.palmUp ? 'text-sky-300' : ''}>{h.palmUp ? 'SIM' : 'não'}</b></span>
        <span>Apontando: {h.pointing ? 'sim' : 'não'}</span>
        <span>Direção: <span className="inline-block" style={{ transform: `rotate(${h.dir}deg)` }}>↑</span> {h.present ? `${h.dir}°` : '—'}</span>
      </div>
    </div>
  );
}

export function SettingsSection() {
  const s = useStore((st) => st.settings);
  const set = S().setSetting;
  const gyro = useStore((st) => st.gyroStatus);
  const handStatus = useStore((st) => st.handStatus);
  const handMsg = useStore((st) => st.handMsg);
  const hands = useStore((st) => st.hands);
  const installed = useStore((st) => st.installed);
  const camStatus = useStore((st) => st.cameraStatus);
  const camMsg = useStore((st) => st.cameraMsg);
  const engine = useStore((st) => st.handEngine);
  const perfTier = useStore((st) => st.perfTier);
  const mode3dof = is3dof(s);
  const reclined = useStore((st) => st.reclined);
  const cinemaDim = useStore((st) => st.cinemaDim);
  const handBad = handStatus === 'error' || handStatus === 'unsupported';

  return (
    <div>
      <h1 className="mb-1 text-[28px] font-semibold text-white">Configurações</h1>
      <p className="mb-5 text-white/55">Ajustes salvos automaticamente neste dispositivo.</p>

      <Group title="Exibição · VR Box">
        <Row label="Modo de exibição" hint="Estéreo para usar no óculos VR Box">
          <Choice value={s.displayMode} onChange={(v) => setDisplayMode(v)} options={[{ v: 'single', label: 'Tela única' }, { v: 'stereo', label: 'VR estéreo' }]} />
        </Row>
        <Row label="Modo vertical (teste)" hint="Celular em pé, tela única — para testar sem o VR Box">
          <Toggle value={s.portrait} onChange={(v) => setPortrait(v)} />
        </Row>
        <Row label="IPD (distância entre olhos)" hint="Profundidade estereoscópica">
          <Stepper value={s.ipd} step={1} min={50} max={80} onChange={(v) => set('ipd', v)} fmt={(v) => `${v} mm`} />
        </Row>
        <Row label="Separação das telas" hint="Alinha o centro de cada lente">
          <Stepper value={s.separation} step={4} min={-120} max={120} onChange={(v) => set('separation', v)} fmt={(v) => `${v} px`} />
        </Row>
        <Row label="Escala / zoom" hint="Campo de visão">
          <Stepper value={s.zoom} step={0.05} min={0.6} max={1.8} onChange={(v) => set('zoom', v)} fmt={(v) => `${v.toFixed(2)}×`} />
        </Row>
        <Row label="Correção de distorção (experimental)" hint="Pré-distorção barril para lentes; pode reduzir o desempenho">
          <Toggle value={s.distortion} onChange={(v) => set('distortion', v)} />
        </Row>
        {s.distortion && (
          <Row label="Intensidade da correção">
            <Stepper value={s.distortionStrength} step={0.02} min={0.04} max={0.5} onChange={(v) => set('distortionStrength', v)} fmt={(v) => v.toFixed(2)} />
          </Row>
        )}
        <Row label="Ambiente">
          <Choice value={s.environment} onChange={(v) => set('environment', v)} options={[
            { v: 'sunset', label: 'Pôr do sol' },
            { v: 'night', label: 'Noite', disabled: !installed.includes('env-night') },
            { v: 'void', label: 'Vazio', disabled: !installed.includes('env-void') },
          ]} />
        </Row>
      </Group>

      <Group title="Passthrough · realidade mista">
        <Row label="Passthrough (câmera traseira)" hint={`Câmera: ${camMsg}`}>
          <Toggle value={s.passthrough} onChange={(v) => set('passthrough', v)} />
        </Row>
        {s.passthrough && camStatus !== 'active' && camStatus !== 'starting' && (
          <div className="mb-3 rounded-xl border border-amber-400/30 bg-amber-500/10 p-3 text-sm text-amber-200">
            Câmera indisponível — exibindo o ambiente virtual como alternativa.
          </div>
        )}
        <div className="mb-2 rounded-xl bg-white/5 p-3 text-sm text-white/55">
          O celular expõe uma única câmera ao navegador: o passthrough é <b className="text-white/80">monocular</b>. No modo VR estéreo a mesma imagem aparece nos dois olhos (sem profundidade real); apenas a interface BLVR tem profundidade estéreo.
        </div>
        <Row label="Zoom da câmera" hint="Ajuste para a escala parecer natural nas lentes">
          <Stepper value={s.ptZoom} step={0.05} min={0.6} max={2} onChange={(v) => set('ptZoom', v)} fmt={(v) => `${v.toFixed(2)}×`} />
        </Row>
        <Row label="Brilho da câmera">
          <Stepper value={s.ptBrightness} step={0.1} min={0.4} max={1.6} onChange={(v) => set('ptBrightness', v)} fmt={(v) => `${Math.round(v * 100)}%`} />
        </Row>
        <Row label="Resolução da câmera" hint="480p = menos latência e bateria">
          <Choice value={s.cameraRes} onChange={(v) => set('cameraRes', v)} options={[{ v: '480', label: '480p' }, { v: '720', label: '720p' }]} />
        </Row>
      </Group>

      <Group title="Menu espacial">
        <Row label="Seguir visão" hint="Desligado: o menu fica ancorado onde foi aberto">
          <Toggle value={s.menuFollow} onChange={(v) => set('menuFollow', v)} />
        </Row>
        <Row label="Distância do menu" hint="Também pelo controle abaixo do menu (pinça + arrastar)">
          <Stepper value={s.menuDistance} step={100} min={800} max={2500} onChange={(v) => set('menuDistance', v)} fmt={(v) => `${(v / 1000).toFixed(1)} m`} />
        </Row>
        <Row label="Tamanho do menu" hint="Também pelas alças nos cantos do menu (pinça + arrastar)">
          <Stepper value={s.menuScale} step={0.05} min={0.55} max={1.8} onChange={(v) => set('menuScale', v)} fmt={(v) => `${Math.round(v * 100)}%`} />
        </Row>
        <Row label="Distância do telão" hint="Também pelo controle Perto ⟷ Longe embaixo do telão">
          <Stepper value={s.telaoDist} step={250} min={1500} max={6000} onChange={(v) => set('telaoDist', v)} fmt={(v) => `${(v / 1000).toFixed(2)} m`} />
        </Row>
        <Row label="Tamanho do telão" hint="Também pelas alças nos cantos do telão (pinça + arrastar)">
          <Stepper value={s.telaoScale} step={0.1} min={0.4} max={2.5} onChange={(v) => set('telaoScale', v)} fmt={(v) => `${Math.round(v * 100)}%`} />
        </Row>
        <Row label="Tamanho da barra inferior" hint="Também pelas alças ⟷ nas pontas da barra (pinça + arrastar)">
          <Stepper value={s.barScale} step={0.05} min={0.6} max={1.8} onChange={(v) => set('barScale', v)} fmt={(v) => `${Math.round(v * 100)}%`} />
        </Row>
      </Group>

      <Group title="Movimento 3DOF">
        <Row label="Modo 3DoF (só sensores)" hint="Câmera desligada: menos bateria, sem aquecimento · cursor por olhar">
          <Toggle value={mode3dof} onChange={set3dof} />
        </Row>
        <div className="mb-2 rounded-xl bg-white/5 p-3 text-sm leading-relaxed text-white/60">
          O 3DoF usa <b className="text-white/85">apenas o giroscópio e o acelerômetro</b> do celular: reconhece quando você olha para cima, para baixo, vira para os lados ou inclina a cabeça.
          Ele <b className="text-white/85">não calcula deslocamento</b> — andar, se abaixar ou se aproximar do chão não move o cenário, que continua à mesma distância.
          Ideal para menus, vídeos e jogos sentado. Sem bússola, a direção pode desviar devagar com o tempo: use <b className="text-white/85">Recalibrar</b>.
          {!mode3dof && <span className="mt-1 block text-amber-200/80">Agora a câmera está em uso (passthrough/mãos). Ligue o Modo 3DoF para economizar bateria.</span>}
        </div>
        <Row label="Giroscópio + acelerômetro" hint={`Status: ${GYRO_TXT[gyro]}`}>
          <Toggle value={s.gyroEnabled} onChange={(v) => set('gyroEnabled', v)} />
        </Row>
        <Row label="Recalibrar visão" hint="Define a direção atual como centro">
          <Btn onClick={recenter} className="hv-solid rounded-xl bg-blue-600 px-5 py-2.5 text-white">Recalibrar</Btn>
        </Row>
        <Row label="Sensibilidade">
          <Stepper value={s.sensitivity} step={0.1} min={0.3} max={2.5} onChange={(v) => set('sensitivity', v)} fmt={(v) => `${v.toFixed(1)}×`} />
        </Row>
        <Row label="Suavização">
          <Stepper value={s.smoothing} step={0.05} min={0} max={0.9} onChange={(v) => set('smoothing', v)} fmt={(v) => `${Math.round(v * 100)}%`} />
        </Row>
        <Row label="Inverter horizontal"><Toggle value={s.invertH} onChange={(v) => set('invertH', v)} /></Row>
        <Row label="Inverter vertical"><Toggle value={s.invertV} onChange={(v) => set('invertV', v)} /></Row>
      </Group>

      <Group title="Mãos · Hand tracking">
        <Row label="Hand tracking (câmera)" hint={handMsg}>
          <Toggle value={s.handTracking} onChange={(v) => set('handTracking', v)} />
        </Row>
        {handBad && (
          <div className="mb-3 rounded-xl border border-amber-400/30 bg-amber-500/10 p-3 text-sm text-amber-200">
            O hand tracking não está funcionando neste dispositivo/navegador. O modo 3DOF continua ativo — use o <b>cursor por olhar</b> (toque na tela ou fixação) para interagir.
          </div>
        )}
        {s.handTracking && !handBad && (
          <div className="mb-3 flex gap-3">
            <HandLive name="Mão esquerda" h={hands.left} />
            <HandLive name="Mão direita" h={hands.right} />
          </div>
        )}
        {engine && <div className="mb-2 text-sm text-white/45">Motor: {engine}</div>}
        <Row label="Taxa do hand tracking" hint="Menor = mais fluidez em aparelhos fracos">
          <Choice value={String(s.handFps) as '15' | '20' | '24' | '30'} onChange={(v) => set('handFps', Number(v))} options={[{ v: '15', label: '15' }, { v: '20', label: '20' }, { v: '24', label: '24' }, { v: '30', label: '30 FPS' }]} />
        </Row>
        <Row label="Câmera" hint={s.passthrough ? 'Passthrough ativo: usa a traseira' : 'Traseira para uso no óculos'}>
          <Choice value={s.passthrough ? 'environment' : s.camera} onChange={(v) => set('camera', v)} options={[{ v: 'environment', label: 'Traseira' }, { v: 'user', label: 'Frontal', disabled: s.passthrough }]} />
        </Row>
        <Row label="Mão dominante" hint="A outra mão abre o menu (palma ↑ + pinça)">
          <Choice value={s.dominantHand} onChange={(v) => set('dominantHand', v)} options={[{ v: 'right', label: 'Direita' }, { v: 'left', label: 'Esquerda' }]} />
        </Row>
        <Row label="Inverter identificação das mãos" hint="Use se esquerda/direita aparecerem trocadas">
          <Toggle value={s.swapHands} onChange={(v) => set('swapHands', v)} />
        </Row>
        <Row label="Tempo do gesto de menu" hint="Palma para cima + pinça mantida">
          <Stepper value={s.menuGestureTime} step={0.25} min={1} max={3} onChange={(v) => set('menuGestureTime', v)} fmt={(v) => `${v.toFixed(2)} s`} />
        </Row>
        <Row label="Mãos rastreadas" hint="1 mão = detecção ~2× mais rápida (recomendado em celular simples). Auto: 1 em celulares até 6 GB">
          <Choice value={s.handsNum} onChange={(v) => set('handsNum', v)} options={[{ v: 'auto', label: 'Auto' }, { v: '1', label: '1 (rápido)' }, { v: '2', label: '2 mãos' }]} />
        </Row>
        <Row label="Processador das mãos" hint="Auto: testa GPU e CPU neste celular e usa o mais rápido">
          <Choice value={s.handDelegate} onChange={(v) => set('handDelegate', v)} options={[{ v: 'auto', label: 'Auto' }, { v: 'cpu', label: 'CPU' }, { v: 'gpu', label: 'GPU' }]} />
        </Row>
        <Row label="Velocidade de acompanhamento" hint="Lenta = mais estável · Instantânea = segue o dedo sem atraso (tremor filtrado)">
          <Choice value={s.handFollow} onChange={(v) => set('handFollow', v)} options={[
            { v: 'slow', label: 'Lenta' }, { v: 'normal', label: 'Normal' }, { v: 'fast', label: 'Rápida' }, { v: 'instant', label: 'Instantânea' },
          ]} />
        </Row>
        <Row label="Alcance do cursor" hint="1,0× = bolinha exatamente no dedo indicador">
          <Stepper value={s.rayGain} step={0.1} min={1} max={2.5} onChange={(v) => set('rayGain', v)} fmt={(v) => `${v.toFixed(1)}×`} />
        </Row>
        <Row label="Esqueleto da mão (diagnóstico)" hint="Desligado: só aparece o cursor e o indicador quando você faz a pinça"><Toggle value={s.showHandSkeleton} onChange={(v) => set('showHandSkeleton', v)} /></Row>
        <Row label="Poke (experimental)" hint="Aponte com o indicador e empurre para tocar"><Toggle value={s.poke} onChange={(v) => set('poke', v)} /></Row>
        <Row label="Tempo de pinça mantida" hint="Para ações que exigem confirmação">
          <Stepper value={s.holdTime} step={0.1} min={0.4} max={2} onChange={(v) => set('holdTime', v)} fmt={(v) => `${v.toFixed(1)} s`} />
        </Row>
      </Group>

      <Group title="Cursor por olhar">
        <Row label="Cursor por olhar" hint="Usa o centro da visão quando não há mãos">
          <Toggle value={s.gazeCursor} onChange={(v) => set('gazeCursor', v)} />
        </Row>
        <Row label="Método de seleção" hint="Toque: tela/botão do óculos/controle BT">
          <Choice value={s.gazeSelect} onChange={(v) => set('gazeSelect', v)} options={[{ v: 'tap', label: 'Toque' }, { v: 'dwell', label: 'Fixar olhar' }]} />
        </Row>
        {s.gazeSelect === 'dwell' && (
          <Row label="Tempo de fixação">
            <Stepper value={s.dwellTime} step={0.2} min={0.6} max={3} onChange={(v) => set('dwellTime', v)} fmt={(v) => `${v.toFixed(1)} s`} />
          </Row>
        )}
      </Group>

      <Group title="Recursos estilo Meta Quest 3S">
        <Row label="Toque duplo no óculos = passthrough" hint="Bata 2× de leve no VR Box (acelerômetro). No Metaverso, volta ao mundo real">
          <Toggle value={s.doubleTap} onChange={(v) => set('doubleTap', v)} />
        </Row>
        <Row label="Organizar janelas" hint="Coloca as janelas abertas lado a lado na sua frente">
          <Btn onClick={arrangeWindows} className="hv rounded-xl bg-white/10 px-5 py-2.5 text-white">Organizar</Btn>
        </Row>
        <Row label="Modo deitado" hint="A direção para onde você olha (inclusive para cima) vira a frente">
          <Toggle value={reclined} onChange={() => toggleReclined()} />
        </Row>
        <Row label="Modo cinema" hint="Escurece o passthrough para assistir">
          <Toggle value={cinemaDim} onChange={() => toggleCinemaDim()} />
        </Row>
        <div className="py-2 text-sm text-white/45">
          Também: pinça para clicar, palma ↑ + pinça para o menu, painel rápido (⋮), passthrough, telão, ambientes, Loja e Biblioteca de apps.
          Recursos do Quest que dependem de 6DoF/sensores do headset (limite Guardian, rastreamento de posição) não existem em celular.
        </div>
      </Group>

      <Group title="Sistema">
        <Row label="Desempenho" hint={`Auto ajusta sozinho pelo FPS · nível atual: ${['alto', 'médio', 'leve'][perfTier]}`}>
          <Choice value={s.perfMode} onChange={(v) => set('perfMode', v)} options={[{ v: 'auto', label: 'Auto' }, { v: 'low', label: 'Leve' }, { v: 'high', label: 'Qualidade' }]} />
        </Row>
        <Row label="Sons de interface"><Toggle value={s.sound} onChange={(v) => set('sound', v)} /></Row>
        <Row label="Tela cheia">
          <Btn onClick={() => { document.documentElement.requestFullscreen?.().catch(() => undefined); }} className="hv rounded-xl bg-white/10 px-5 py-2.5 text-white">Ativar</Btn>
        </Row>
        <Row label="Fechar todas as janelas" hint="Segure para confirmar">
          <Btn hold="closeall" className="hv rounded-xl bg-white/10 px-5 py-2.5 text-white">Segure</Btn>
        </Row>
        <Row label="Restaurar padrões" hint="Segure para confirmar">
          <Btn hold="reset" className="hv rounded-xl bg-red-600/80 px-5 py-2.5 text-white">Segure</Btn>
        </Row>
        <div className="py-3 text-sm text-white/40">
          BLVR 1.0 · Atalhos: duplo toque = menu · M = menu · R = recalibrar · Enter/Espaço = selecionar · setas = olhar
        </div>
      </Group>
    </div>
  );
}
