import { memo } from 'react';
import { Orbit, Globe2, Gamepad2, Hand, LayoutGrid, RotateCcw, X, LogOut, MonitorPlay, Piano, Brain as HelpCircle, Grid3x3, Landmark, Radio, CircleDot, Hash, Target, Zap, Sparkles, Trees, SunMedium } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useStore, S, type MetaWorld, type MetaTab, type AppId } from '../core/store';
import { exitMeta, closeMetaHub } from '../core/meta';
import { openApp, openMenu, recenter, startGame } from '../core/actions';
import { Btn, Placed, AnchorGroup, Toggle, Choice } from './ui';
import { panel } from './Menu';
import { cn } from '../utils/cn';

/* ============================== Worlds ============================== */
export interface WorldDef {
  name: string;
  desc: string;
  sky: [string, string, string, string];
  floor: string;
  grid: string;
  accent: string;
  stars?: boolean;
  deco: 'city' | 'planet' | 'sun' | 'pillars' | 'forest' | 'meadow';
  bgImage?: string;
  previewGradient?: string;
}

export const WORLDS: Record<MetaWorld, WorldDef> = {
  forest: {
    name: 'Floresta Solar',
    desc: 'Pinheiros altos com raios de sol e copa verdejante.',
    sky: ['#051a0e', '#0d331b', '#166534', '#15803d'],
    floor: '#04130a',
    grid: 'rgba(74,222,128,.35)',
    accent: '#84cc16',
    deco: 'forest',
    previewGradient: 'from-emerald-950 via-green-800 to-lime-600',
  },
  meadow: {
    name: 'Campos Verdes',
    desc: 'Colinas verdejantes sob céu azul e sol brilhante.',
    sky: ['#0369a1', '#38bdf8', '#bae6fd', '#16a34a'],
    floor: '#15803d',
    grid: 'rgba(34,197,94,.4)',
    accent: '#22c55e',
    deco: 'meadow',
    previewGradient: 'from-sky-500 via-emerald-400 to-green-700',
  },
  neon: {
    name: 'Neon City',
    desc: 'Cidade cyberpunk com arranha-céus e luzes neon.',
    sky: ['#04010c', '#12052a', '#ff2bd6', '#1a0630'],
    floor: '#07031a',
    grid: 'rgba(34,211,238,.45)',
    accent: '#22d3ee',
    deco: 'city',
    previewGradient: 'from-indigo-950 via-purple-900 to-pink-600',
  },
  space: {
    name: 'Órbita',
    desc: 'Plataforma no espaço com planeta gigante e estrelas.',
    sky: ['#000003', '#03061a', '#4c1d95', '#05030f'],
    floor: '#05040f',
    grid: 'rgba(167,139,250,.4)',
    accent: '#a78bfa',
    stars: true,
    deco: 'planet',
    previewGradient: 'from-black via-slate-900 to-violet-800',
  },
  sunset: {
    name: 'Synthwave',
    desc: 'Pôr do sol retrô sobre grade neon infinita.',
    sky: ['#0b0423', '#3b0a5e', '#ff7a45', '#2a0838'],
    floor: '#12031f',
    grid: 'rgba(244,114,182,.5)',
    accent: '#f472b6',
    stars: true,
    deco: 'sun',
    previewGradient: 'from-purple-950 via-fuchsia-900 to-orange-500',
  },
  matrix: {
    name: 'Matrix',
    desc: 'Espaço digital com pilares de dados e código verde.',
    sky: ['#000000', '#010a03', '#14532d', '#000502'],
    floor: '#000402',
    grid: 'rgba(74,222,128,.4)',
    accent: '#4ade80',
    deco: 'pillars',
    previewGradient: 'from-black via-zinc-950 to-emerald-800',
  },
};

const SEG = 12, R = 2800, TOP = -2000, BOTTOM = 1250, H = BOTTOM - TOP;
const SEG_W = 2 * R * Math.tan(Math.PI / SEG) + 4;
const HW = SEG_W / 2, HH = H / 2;
const YC = (TOP + BOTTOM) / 2;
const HORIZON = ((0 - TOP) / H) * 100;
const STARS = 'radial-gradient(1px 1px at 12px 20px, #fff, transparent), radial-gradient(1px 1px at 70px 90px, rgba(255,255,255,.8), transparent), radial-gradient(1.5px 1.5px at 110px 40px, #fff, transparent), radial-gradient(1px 1px at 40px 120px, rgba(255,255,255,.6), transparent)';

function at(yaw: number, y: number, dist: number) {
  return `rotateY(${yaw}deg) translateY(${y}px) translateZ(${-dist}px)`;
}

function Decorations({ w }: { w: WorldDef }) {
  if (w.deco === 'forest') {
    return (
      <>
        {/* Soft sunbeams streaming from upper angle */}
        <div className="absolute left-0 top-0 pointer-events-none" style={{
          width: 2200, height: 1600, marginLeft: -1100, marginTop: -800,
          transform: at(15, -400, 2400),
          background: 'radial-gradient(circle at 50% 20%, rgba(254,240,138,0.38) 0%, rgba(253,224,71,0.18) 35%, transparent 70%)',
        }} />
        {/* Sun flare orb */}
        <div className="absolute left-0 top-0 rounded-full pointer-events-none" style={{
          width: 500, height: 500, marginLeft: -250, marginTop: -250,
          transform: at(18, -750, 2600),
          background: 'radial-gradient(circle, rgba(255,255,255,0.95) 0%, rgba(253,224,71,0.7) 35%, rgba(250,204,21,0.2) 65%, transparent 75%)',
          boxShadow: '0 0 100px rgba(253,224,71,0.8)',
        }} />
      </>
    );
  }

  if (w.deco === 'meadow') {
    return (
      <>
        {/* Bright warm sun */}
        <div className="absolute left-0 top-0 rounded-full pointer-events-none" style={{
          width: 440, height: 440, marginLeft: -220, marginTop: -220,
          transform: at(-25, -950, 2700),
          background: 'radial-gradient(circle, #ffffff 0%, #fef08a 30%, #facc15 60%, rgba(234,179,8,0.2) 80%, transparent 100%)',
          boxShadow: '0 0 120px rgba(250,204,21,0.75)',
        }} />
      </>
    );
  }

  if (w.deco === 'city') {
    const towers = [[-40, 1900, 320], [-62, 1300, 260], [-85, 2100, 380], [-115, 1500, 300], [-145, 1800, 340], [180, 2200, 420], [145, 1600, 300], [115, 2000, 360], [85, 1200, 260], [62, 1700, 330], [40, 1400, 280]];
    return (
      <>
        {towers.map(([yaw, h, wd], i) => (
          <div key={i} className="absolute left-0 top-0" style={{
            width: wd, height: h, marginLeft: -wd / 2, marginTop: -h / 2,
            transform: at(yaw, BOTTOM - h / 2, 2600 + (i % 3) * 120),
            background: `repeating-linear-gradient(0deg, transparent 0 26px, rgba(255,255,255,.07) 26px 32px), repeating-linear-gradient(90deg, transparent 0 22px, ${i % 2 ? 'rgba(34,211,238,.18)' : 'rgba(255,43,214,.16)'} 22px 30px), linear-gradient(to top, #1a0b3a, #07031a)`,
            borderTop: `4px solid ${i % 2 ? w.accent : '#ff2bd6'}`,
          }} />
        ))}
      </>
    );
  }
  if (w.deco === 'planet') {
    return (
      <>
        <div className="absolute left-0 top-0 rounded-full" style={{ width: 900, height: 900, marginLeft: -450, marginTop: -450, transform: `rotateY(-35deg) rotateX(22deg) translateZ(-2850px)`, background: 'radial-gradient(circle at 35% 30%, #ddd6fe, #7c3aed 42%, #2e1065 72%, #0b0420 100%)' }} />
        <div className="absolute left-0 top-0 rounded-[50%]" style={{ width: 1500, height: 300, marginLeft: -750, marginTop: -150, transform: `rotateY(-35deg) rotateX(22deg) translateZ(-2840px) rotateZ(-14deg)`, border: '10px solid rgba(196,181,253,.45)' }} />
        <div className="absolute left-0 top-0 rounded-full" style={{ width: 220, height: 220, marginLeft: -110, marginTop: -110, transform: `rotateY(55deg) rotateX(38deg) translateZ(-2850px)`, background: 'radial-gradient(circle at 40% 35%, #f1f5f9, #94a3b8 60%, #334155)' }} />
      </>
    );
  }
  if (w.deco === 'sun') {
    const sky = w.sky[2];
    return (
      <div className="absolute left-0 top-0 rounded-full" style={{
        width: 1400, height: 1400, marginLeft: -700, marginTop: -700,
        transform: `rotateY(0deg) rotateX(9deg) translateZ(-2950px)`,
        background: `linear-gradient(to bottom, transparent 52%, ${sky} 52% 55%, transparent 55% 63%, ${sky} 63% 67%, transparent 67% 74%, ${sky} 74% 79%, transparent 79% 85%, ${sky} 85% 92%, transparent 92%), linear-gradient(to bottom, #fde047, #fb923c 48%, #db2777 80%)`,
      }} />
    );
  }
  return (
    <>
      {[-150, -110, -70, -35, 35, 70, 110, 150, 180].map((yaw, i) => (
        <div key={i} className="absolute left-0 top-0" style={{
          width: 70, height: 3200, marginLeft: -35, marginTop: -1600, transform: at(yaw, BOTTOM - 1600, 2400 + (i % 2) * 300),
          background: 'repeating-linear-gradient(to bottom, rgba(74,222,128,.9) 0 18px, rgba(74,222,128,.15) 18px 40px)',
        }} />
      ))}
    </>
  );
}

function MetaWorldInner() {
  const id = useStore((s) => s.settings.metaWorld);
  const w = WORLDS[id] ?? WORLDS.forest;
  const [top, mid, glow, below] = w.sky;
  const skyBg = `${w.stars ? `${STARS}, ` : ''}linear-gradient(to bottom, ${top} 0%, ${mid} ${HORIZON - 20}%, ${glow} ${HORIZON}%, ${below} ${HORIZON + 2}%, ${w.floor} 100%)`;

  return (
    <>
      {Array.from({ length: SEG }).map((_, i) => {
        const yaw = (SEG / 2 - 0.5 - i) * (360 / SEG);
        const mirrored = i >= SEG / 2;

        return (
          <div key={i} className="absolute left-0 top-0" style={{
            width: HW, height: HH, marginLeft: -HW / 2, marginTop: -HH / 2,
            transform: `rotateY(${yaw}deg) translateY(${YC}px) translateZ(${-R}px) scale(${mirrored ? -2 : 2}, 2)`,
            background: skyBg,
            backgroundSize: w.stars ? '140px 140px, 140px 140px, 140px 140px, 140px 140px, 100% 100%' : '100% 100%',
          }} />
        );
      })}

      {/* Floor with radial blend and soft grid */}
      <div className="absolute left-0 top-0 rounded-full" style={{
        width: 800, height: 800, marginLeft: -400, marginTop: -400,
        transform: `translateY(${BOTTOM}px) rotateX(90deg) scale(8)`,
        background: w.deco === 'forest' || w.deco === 'meadow'
          ? `radial-gradient(circle, ${w.floor} 0%, ${w.floor} 50%, #031207 75%, transparent 80%)`
          : `radial-gradient(circle, transparent 0 8%, ${w.accent} 8.4%, transparent 9%, transparent 35%, ${w.floor} 72%), linear-gradient(${w.grid} 1px, transparent 1px) 0 0 / 30px 30px, linear-gradient(90deg, ${w.grid} 1px, transparent 1px) 0 0 / 30px 30px, ${w.floor}`,
      }} />

      <Decorations w={w} />

      {/* Floating sign */}
      <div className="absolute left-0 top-0 flex items-center justify-center pointer-events-none" style={{
        width: 1400, height: 180, marginLeft: -700, marginTop: -90, transform: `rotateY(0deg) rotateX(28deg) translateZ(-2600px)`,
        color: w.accent, fontSize: 110, fontWeight: 800, letterSpacing: 14, opacity: 0.75,
      }}>
        BLVR
      </div>
    </>
  );
}
export const MetaWorldView = memo(MetaWorldInner);

/* ============================== Hub (menus) ============================== */
const TABS: { id: MetaTab; label: string; icon: LucideIcon }[] = [
  { id: 'home', label: 'Início', icon: Orbit },
  { id: 'worlds', label: 'Mundos', icon: Globe2 },
  { id: 'activities', label: 'Atividades', icon: Gamepad2 },
  { id: 'hands', label: 'Mãos neon', icon: Hand },
];
const COLORS = [
  { c: '#3b82f6', n: 'Azul' }, { c: '#22d3ee', n: 'Ciano' }, { c: '#a855f7', n: 'Roxo' }, { c: '#ec4899', n: 'Rosa' },
  { c: '#22c55e', n: 'Verde' }, { c: '#f97316', n: 'Laranja' }, { c: '#facc15', n: 'Amarelo' }, { c: '#e5e7eb', n: 'Branco' },
];
const ACTIVITIES: { label: string; icon: LucideIcon; color: string; run: () => void }[] = [
  { label: 'Block Blast 3D', icon: Sparkles, color: 'from-fuchsia-600 to-indigo-800', run: () => openApp('blockblast') },
  { label: 'BLVR Craft', icon: Trees, color: 'from-green-600 to-sky-700', run: () => openApp('craft') },
  { label: 'Orbs Neon', icon: Zap, color: 'from-fuchsia-500 to-indigo-700', run: () => startGame('neonpop') },
  { label: 'Balões 360', icon: Target, color: 'from-amber-400 to-orange-600', run: () => startGame('balloons') },
  { label: 'Telão YouTube', icon: MonitorPlay, color: 'from-red-600 to-zinc-900', run: () => openApp('telao') },
  { label: 'Piano', icon: Piano, color: 'from-slate-500 to-slate-900', run: () => openApp('piano') },
  { label: 'Quiz', icon: HelpCircle, color: 'from-sky-500 to-blue-800', run: () => openApp('quiz') },
  { label: '2048', icon: Grid3x3, color: 'from-amber-500 to-yellow-700', run: () => openApp('g2048') },
  { label: 'Pokédex', icon: CircleDot, color: 'from-red-500 to-rose-800', run: () => openApp('pokedex') },
  { label: 'Museu', icon: Landmark, color: 'from-amber-700 to-stone-900', run: () => openApp('museum') },
  { label: 'Rádio', icon: Radio, color: 'from-orange-500 to-pink-600', run: () => openApp('radio') },
  { label: 'Jogo da Velha', icon: Hash, color: 'from-sky-500 to-indigo-700', run: () => openApp('tictactoe' as AppId) },
];

function HandPreview({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 100 120" className="h-[150px] w-[125px]">
      <path d="M38 118 C38 100 30 92 24 80 L10 52 C6 44 16 38 21 46 L32 62 L28 18 C27 9 39 8 40 17 L44 52 L47 8 C48 -1 60 -1 59 8 L58 52 L64 14 C66 5 77 7 75 16 L68 58 L80 42 C86 35 95 42 89 50 L70 80 C64 90 62 100 62 118"
        fill="none" stroke={color} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" style={{ filter: `drop-shadow(0 0 4px ${color})` }} />
    </svg>
  );
}

function HomeTab() {
  const world = useStore((s) => s.settings.metaWorld);
  const handMsg = useStore((s) => s.handMsg);
  const curWorld = WORLDS[world] ?? WORLDS.forest;

  const big = (label: string, Icon: LucideIcon, fn: () => void, cls = 'bg-white/[.07]') => (
    <Btn onClick={fn} className={cn('hv flex h-[110px] flex-col items-center justify-center gap-2 rounded-2xl text-[17px] text-white', cls)}>
      <Icon size={32} /> {label}
    </Btn>
  );

  return (
    <div>
      <div className="mb-1 text-[30px] font-semibold text-white">Metaverso BLVR</div>
      <div className="mb-5 text-[16px] text-white/55">Mundo Atual: <b className="text-white/85">{curWorld.name}</b> · Mãos: {handMsg}</div>
      <div className="grid grid-cols-3 gap-3">
        {big('Mundos (6 Mapas)', Globe2, () => S().set({ metaTab: 'worlds' }), 'bg-gradient-to-br from-emerald-600/30 to-green-700/30 border border-emerald-500/30')}
        {big('Atividades', Gamepad2, () => S().set({ metaTab: 'activities' }))}
        {big('Mãos neon', Hand, () => S().set({ metaTab: 'hands' }))}
        {big('Menu BLVR', LayoutGrid, () => { closeMetaHub(); openMenu(); })}
        {big('Recalibrar', RotateCcw, recenter)}
        {big('Fechar painel', X, closeMetaHub)}
      </div>
      <div className="mt-5 rounded-2xl bg-white/5 p-4 text-[14px] leading-relaxed text-white/55">
        Aponte com o indicador e faça <b className="text-white/85">pinça</b> para clicar · segure a pinça para arrastar ·
        <b className="text-white/85"> palma ↑ + pinça</b> (mão não dominante) abre/fecha este painel · toque duplo também.
      </div>
    </div>
  );
}

function WorldsTab() {
  const world = useStore((s) => s.settings.metaWorld);
  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h2 className="text-[26px] font-bold text-white">Mundos do Metaverso</h2>
          <p className="text-[14px] text-white/60">Escolha o ambiente imersivo para navegar e usar seus apps.</p>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        {(Object.keys(WORLDS) as MetaWorld[]).map((id) => {
          const w = WORLDS[id];
          const isSelected = world === id;
          return (
            <Btn
              key={id}
              onClick={() => S().setSetting('metaWorld', id)}
              className={cn(
                'hv overflow-hidden rounded-3xl bg-white/5 transition-all text-left flex flex-col',
                isSelected ? 'ring-2 ring-emerald-400 bg-emerald-950/40 shadow-xl' : 'hover:bg-white/10'
              )}
            >
              <div
                className="relative h-[130px] w-full overflow-hidden"
                style={{
                  backgroundImage: w.bgImage ? `url(${w.bgImage})` : undefined,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center',
                }}
              >
                {!w.bgImage && (
                  <div className={cn('h-full w-full bg-gradient-to-br', w.previewGradient || 'from-slate-900 to-black')} />
                )}
                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                {isSelected && (
                  <span className="absolute right-3 top-3 rounded-full bg-emerald-500 px-3 py-1 text-[12px] font-bold text-black shadow-lg flex items-center gap-1">
                    <SunMedium size={14} /> Ativo
                  </span>
                )}
              </div>
              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-[18px] font-bold text-white leading-tight">{w.name}</div>
                  <div className="mt-1 line-clamp-2 text-[13px] text-white/55 leading-relaxed">{w.desc}</div>
                </div>
              </div>
            </Btn>
          );
        })}
      </div>
    </div>
  );
}

function ActivitiesTab() {
  return (
    <div>
      <div className="mb-4 text-[26px] font-semibold text-white">Atividades</div>
      <div className="grid grid-cols-4 gap-3 sm:grid-cols-6">
        {ACTIVITIES.map((a) => (
          <Btn key={a.label} onClick={a.run} className="hv overflow-hidden rounded-2xl bg-white/5">
            <div className={cn('flex h-[88px] items-center justify-center bg-gradient-to-br', a.color)}><a.icon size={36} className="text-white" /></div>
            <div className="truncate px-2 py-2 text-center text-[13px] text-white/90">{a.label}</div>
          </Btn>
        ))}
      </div>
      <div className="mt-4 text-[13px] text-white/45">Os apps abrem em janelas flutuando no mundo virtual. Use o Menu BLVR para todos os outros apps.</div>
    </div>
  );
}

function HandsTab() {
  const s = useStore((st) => st.settings);
  const engine = useStore((st) => st.handEngine);
  const handMsg = useStore((st) => st.handMsg);
  const set = S().setSetting;
  return (
    <div className="flex gap-6">
      <div className="min-w-0 flex-1">
        <div className="mb-3 text-[26px] font-semibold text-white">Mãos neon</div>
        <div className="mb-2 text-[15px] text-white/60">Cor</div>
        <div className="mb-4 flex flex-wrap gap-2">
          {COLORS.map((c) => (
            <Btn key={c.c} onClick={() => set('handColor', c.c)} title={c.n}
              className={cn('hv h-12 w-12 rounded-full', s.handColor === c.c && 'ring-4 ring-white')} style={{ background: c.c }} />
          ))}
        </div>
        <div className="mb-3 flex items-center justify-between">
          <span className="text-[16px] text-white">Espessura</span>
          <Choice value={String(s.handWidth) as '0.7' | '1' | '1.4'} onChange={(v) => set('handWidth', Number(v))}
            options={[{ v: '0.7', label: 'Fina' }, { v: '1', label: 'Normal' }, { v: '1.4', label: 'Grossa' }]} />
        </div>
        <div className="mb-3 flex items-center justify-between">
          <span className="text-[16px] text-white">Brilho neon</span>
          <Toggle value={s.handGlow} onChange={(v) => set('handGlow', v)} />
        </div>
        <div className="mb-3 flex items-center justify-between gap-3">
          <span className="text-[16px] text-white">Velocidade</span>
          <Choice value={s.handFollow} onChange={(v) => set('handFollow', v)} options={[
            { v: 'slow', label: 'Lenta' }, { v: 'normal', label: 'Normal' }, { v: 'fast', label: 'Rápida' }, { v: 'instant', label: 'Instant.' },
          ]} />
        </div>
        <div className="rounded-xl bg-white/5 p-3 text-[13px] text-white/50">{handMsg}{engine ? ` · ${engine}` : ''}</div>
      </div>
      <div className="flex w-[180px] shrink-0 flex-col items-center justify-center rounded-2xl bg-black/60">
        <HandPreview color={s.handColor} />
        <div className="mt-2 text-[13px] text-white/50">Prévia</div>
      </div>
    </div>
  );
}

export function MetaHub() {
  const open = useStore((s) => s.metaHubOpen && s.meta);
  const tab = useStore((s) => s.metaTab);
  return (
    <AnchorGroup id="metahub">
      <Placed yaw={0} dist={0} w={1040} h={660} visible={open}>
        <div className={cn(panel, 'flex overflow-hidden')}>
          <div className="flex w-[230px] shrink-0 flex-col gap-1.5 border-r border-white/10 p-5">
            <div className="mb-5 flex items-center gap-2 px-2 text-white">
              <Sparkles size={28} className="text-sky-400" />
              <span className="text-[22px] font-bold">Metaverso</span>
            </div>
            {TABS.map((t) => (
              <Btn key={t.id} onClick={() => S().set({ metaTab: t.id })}
                className={cn('hv flex items-center gap-3 rounded-2xl px-4 py-3.5 text-[18px]', tab === t.id ? 'bg-blue-600 text-white' : 'text-white/85')}>
                <t.icon size={24} /> {t.label}
              </Btn>
            ))}
            <div className="flex-1" />
            <Btn onClick={exitMeta} className="hv-solid flex items-center justify-center gap-2 rounded-2xl bg-red-600 px-4 py-4 text-[17px] font-semibold text-white">
              <LogOut size={22} /> Sair do Metaverso
            </Btn>
          </div>
          <div data-scroll className="min-w-0 flex-1 overflow-y-auto p-7">
            {tab === 'home' && <HomeTab />}
            {tab === 'worlds' && <WorldsTab />}
            {tab === 'activities' && <ActivitiesTab />}
            {tab === 'hands' && <HandsTab />}
          </div>
        </div>
      </Placed>
    </AnchorGroup>
  );
}
