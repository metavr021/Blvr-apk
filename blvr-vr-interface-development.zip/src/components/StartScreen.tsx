import { useState } from 'react';
import { Infinity as InfinityIcon, Glasses, Smartphone, Check, X, AlertTriangle, Hand, Camera, Download } from 'lucide-react';
import { S, useStore } from '../core/store';
import { startGyro } from '../core/orientation';
import { unlockAudio } from '../core/sound';
import { applyOrientation, set3dof, is3dof } from '../core/actions';
import { promptInstall, isInstalled } from '../core/install';
import { cn } from '../utils/cn';

const checks = () => [
  { label: 'Sensores de rotação (3DoF)', ok: typeof DeviceOrientationEvent !== 'undefined', note: 'giroscópio + acelerômetro' },
  { label: 'Câmera para hand tracking', ok: !!navigator.mediaDevices?.getUserMedia, note: 'getUserMedia' },
  { label: 'Conexão segura (HTTPS)', ok: window.isSecureContext, note: 'exigida pela câmera' },
  { label: 'WebAssembly (modelo de mãos)', ok: typeof WebAssembly !== 'undefined', note: 'MediaPipe' },
  { label: 'Tela cheia', ok: !!document.documentElement.requestFullscreen, note: 'opcional' },
];

export function StartScreen() {
  const settings = useStore((s) => s.settings);
  const [busy, setBusy] = useState(false);
  const list = checks();
  const handPossible = list[1].ok && list[2].ok && list[3].ok;
  const mode3dof = is3dof(settings);
  const canInstall = useStore((s) => s.canInstall);
  const installed = isInstalled();

  const start = async (mode: 'single' | 'stereo', portrait = false) => {
    if (busy) return;
    setBusy(true);
    unlockAudio();
    S().setSetting('displayMode', mode);
    S().setSetting('portrait', portrait);
    const g = startGyro().catch(() => undefined); // permission prompt must happen inside the user gesture (iOS)
    const f = document.documentElement.requestFullscreen?.({ navigationUI: 'hide' }).catch(() => undefined);
    await Promise.all([g, f]);
    await applyOrientation(); // landscape for VR Box / tela única, portrait for the vertical test mode
    try { await (navigator as unknown as { wakeLock?: { request: (t: string) => Promise<unknown> } }).wakeLock?.request('screen'); } catch { /* ignore */ }
    if (!handPossible && !is3dof()) set3dof(true); // no camera support → pure 3DoF, never a broken camera mode
    S().set({ started: true });
    setTimeout(() => S().toast(is3dof()
      ? 'Modo 3DoF: o centro da visão é o cursor · toque na tela (ou botão do óculos) para selecionar · olhe para baixo → BLVR'
      : 'Menu: palma ↑ + pinça (mão não dominante) · olhe para baixo e selecione BLVR · toque duplo', 'info'), 800);
  };

  return (
    <div className="relative min-h-full overflow-y-auto bg-[#05070d] text-white">
      <img src="env/panorama.jpg" alt="" className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-35" />
      <div className="absolute inset-0 bg-gradient-to-b from-[#05070d]/40 via-[#05070d]/70 to-[#05070d]" />
      <div className="relative mx-auto flex max-w-4xl flex-col items-center px-5 py-8 sm:py-12">
        <div className="mb-2 flex items-center gap-3">
          <InfinityIcon size={64} className="text-blue-500" strokeWidth={2.6} />
          <span className="text-6xl font-bold tracking-wide">BLVR</span>
        </div>
        <p className="mb-8 text-center text-white/60">Sistema VR para Android · 3DOF · hand tracking por câmera · VR Box</p>

        <div className="mb-8 grid w-full gap-4 sm:grid-cols-2">
          <button onClick={() => start('stereo')} disabled={busy}
            className="group flex items-center gap-4 rounded-3xl bg-gradient-to-br from-blue-600 to-indigo-700 p-6 text-left shadow-xl shadow-blue-900/40 transition hover:scale-[1.02] active:scale-95">
            <Glasses size={44} />
            <div>
              <div className="text-xl font-semibold">Entrar no VR Box</div>
              <div className="text-sm text-white/75">Visão estereoscópica esquerda/direita</div>
            </div>
          </button>
          <button onClick={() => start('single')} disabled={busy}
            className="flex items-center gap-4 rounded-3xl border border-white/15 bg-white/5 p-6 text-left transition hover:scale-[1.02] hover:bg-white/10 active:scale-95">
            <Smartphone size={44} />
            <div>
              <div className="text-xl font-semibold">Tela única</div>
              <div className="text-sm text-white/65">Mova o celular ou arraste para olhar</div>
            </div>
          </button>
          <button onClick={() => start('single', true)} disabled={busy}
            className="flex items-center gap-4 rounded-3xl border border-white/15 bg-white/5 p-5 text-left transition hover:bg-white/10 active:scale-95 sm:col-span-2">
            <Smartphone size={36} className="shrink-0" />
            <div>
              <div className="text-lg font-semibold">Testar na vertical</div>
              <div className="text-sm text-white/65">Celular em pé, tela única — para testar menu, pinça e câmera sem o VR Box</div>
            </div>
          </button>
        </div>

        {!installed && (
          <div className="mb-6 flex w-full items-center justify-between gap-3 rounded-2xl border border-blue-400/30 bg-blue-600/10 p-4">
            <div className="flex items-center gap-3">
              <Download className="shrink-0 text-sky-400" />
              <div>
                <div className="font-medium">Instalar o BLVR como app</div>
                <div className="text-sm text-white/55">{canInstall ? 'Ícone na tela inicial, abre em tela cheia, funciona offline.' : 'No Chrome: menu ⋮ → "Instalar app" ou "Adicionar à tela inicial".'}</div>
              </div>
            </div>
            {canInstall && (
              <button onClick={() => void promptInstall()} className="shrink-0 rounded-full bg-blue-600 px-5 py-2.5 font-semibold transition active:scale-95">Instalar</button>
            )}
          </div>
        )}

        <div className="mb-2 w-full text-sm font-semibold uppercase tracking-widest text-white/50">Modo de rastreamento</div>
        <div className="mb-6 grid w-full gap-3 sm:grid-cols-2">
          <button onClick={() => set3dof(true)}
            className={cn('rounded-2xl border p-4 text-left transition active:scale-[.98]', mode3dof ? 'border-blue-400 bg-blue-600/20' : 'border-white/10 bg-white/5 hover:bg-white/10')}>
            <div className="mb-1 flex items-center gap-2 font-semibold">
              <Smartphone size={20} className="text-sky-400" /> 3DoF · só sensores
              {mode3dof && <Check size={18} className="ml-auto text-blue-300" />}
            </div>
            <div className="text-sm leading-relaxed text-white/60">
              Giroscópio + acelerômetro: olhar para cima, para baixo, para os lados e inclinar a cabeça.
              Câmera desligada → <b className="text-white/80">menos bateria e sem aquecimento</b>. Ideal para menus, vídeos e jogos sentado.
              Não rastreia deslocamento (andar não move o cenário).
            </div>
          </button>
          <button onClick={() => handPossible && set3dof(false)} disabled={!handPossible}
            className={cn('rounded-2xl border p-4 text-left transition active:scale-[.98]', !mode3dof ? 'border-blue-400 bg-blue-600/20' : 'border-white/10 bg-white/5 hover:bg-white/10', !handPossible && 'opacity-50')}>
            <div className="mb-1 flex items-center gap-2 font-semibold">
              <Camera size={20} className="text-sky-400" /> <Hand size={20} className="text-sky-400" /> Realidade mista
              {!mode3dof && <Check size={18} className="ml-auto text-blue-300" />}
            </div>
            <div className="text-sm leading-relaxed text-white/60">
              {handPossible
                ? <>3DoF + câmera: ambiente real ao fundo (passthrough monocular) e controle com as mãos (pinça). <b className="text-white/80">Gasta mais bateria e esquenta mais.</b></>
                : 'Indisponível neste navegador/conexão (requer câmera + HTTPS + WebAssembly).'}
            </div>
          </button>
        </div>

        <div className="mb-6 w-full rounded-2xl border border-white/10 bg-white/5 p-4">
          <div className="mb-3 text-sm font-semibold uppercase tracking-widest text-white/50">Compatibilidade deste dispositivo</div>
          <div className="grid gap-2 sm:grid-cols-2">
            {list.map((c) => (
              <div key={c.label} className="flex items-center gap-2 text-sm">
                {c.ok ? <Check size={18} className="text-emerald-400" /> : <X size={18} className="text-red-400" />}
                <span className={c.ok ? 'text-white/85' : 'text-white/50'}>{c.label}</span>
                <span className="text-white/30">· {c.note}</span>
              </div>
            ))}
          </div>
          {!window.isSecureContext && (
            <div className="mt-3 flex items-start gap-2 rounded-xl bg-amber-500/10 p-3 text-sm text-amber-200">
              <AlertTriangle size={18} className="shrink-0" /> Abra o BLVR por HTTPS para liberar câmera e hand tracking.
            </div>
          )}
        </div>

        <div className="grid w-full gap-3 text-sm text-white/60 sm:grid-cols-3">
          <div className="rounded-2xl bg-white/5 p-4"><b className="text-white">Pinça</b> (polegar + indicador) = clique. Mantenha para arrastar janelas, rolar e confirmar.</div>
          <div className="rounded-2xl bg-white/5 p-4"><b className="text-white">Menu:</b> mão não dominante com a palma para cima + pinça por ~1,5 s. Ou olhe para baixo e selecione BLVR.</div>
          <div className="rounded-2xl bg-white/5 p-4"><b className="text-white">Sem mãos?</b> O centro da visão vira cursor. Toque na tela (ou botão do óculos) para selecionar.</div>
        </div>
      </div>
    </div>
  );
}
