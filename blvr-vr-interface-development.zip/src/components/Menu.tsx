import { useEffect } from 'react';
import { Home as HomeIcon, Globe, LayoutGrid, Gamepad2, ShoppingBag, Settings, Infinity as InfinityIcon, User, Glasses, Compass, Hand, RotateCcw, X, GripHorizontal, Camera, MoreVertical, Maximize2, MoveHorizontal, Smartphone, MonitorPlay, Orbit } from 'lucide-react';
import { enterMeta, exitMeta, toggleMetaHub } from '../core/meta';
import { arrangeWindows, toggleReclined, toggleCinemaDim } from '../core/quest';
import { Clapperboard, LayoutDashboard, Bed, Vibrate, Box } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useStore, S, type Section } from '../core/store';
import { openSection, closeMenu, toggleMenu, restoreWin, recenter, toggleQuick, closeQuick, setDisplayMode, set3dof, is3dof, toggleTelao, openApp } from '../core/actions';
import { menuGeo, setMenuGeo, setBarGeo, MENU_BASE } from '../core/spatial';
import { Btn, Placed, AnchorGroup, StatusIcons, ICONS } from './ui';
import { byId } from '../core/catalog';
import { Home, Apps, Games, Store } from './Sections';
import { SettingsSection } from './SettingsSection';
import { cn } from '../utils/cn';

/* Layout authored in px (1 px ≈ 1 mm at scale 1); size/depth come from the --ms / --md CSS variables. */
const MAIN_W = 940, MAIN_H = 620, NAV_W = 330, SIDE_W = 330, GAP = 30;

export const NAV: { id: Section; label: string; icon: LucideIcon }[] = [
  { id: 'home', label: 'Início', icon: HomeIcon },
  { id: 'browser', label: 'Navegador', icon: Globe },
  { id: 'apps', label: 'Aplicativos', icon: LayoutGrid },
  { id: 'games', label: 'Jogos', icon: Gamepad2 },
  { id: 'store', label: 'Loja', icon: ShoppingBag },
  { id: 'settings', label: 'Configurações', icon: Settings },
];

/** Floating glass panel: slight transparency, top light, soft edge, single moderate shadow (cheap). */
export const panel = 'blvr-panel h-full w-full rounded-[34px]';

function NavPanel() {
  const section = useStore((s) => s.section);
  return (
    <div className={cn(panel, 'flex flex-col p-6')}>
      <div className="mb-7 flex items-center gap-3 px-2">
        <InfinityIcon size={44} className="text-blue-500" strokeWidth={2.6} />
        <span className="text-[30px] font-bold tracking-wide text-white">BLVR</span>
      </div>
      <div className="flex flex-col gap-1.5">
        {NAV.map((n) => {
          const active = section === n.id;
          return (
            <Btn key={n.id} onClick={() => openSection(n.id)}
              className={cn('hv flex items-center gap-4 rounded-2xl px-4 py-3.5 text-[20px]', active ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white' : 'text-white/85')}>
              <n.icon size={26} /> {n.label}
            </Btn>
          );
        })}
      </div>
      <div className="flex-1" />
      <Btn onClick={closeMenu} className="hv flex items-center gap-3 rounded-2xl px-4 py-3 text-[17px] text-white/60">
        <X size={22} /> Fechar menu
      </Btn>
    </div>
  );
}

function MainPanel() {
  const section = useStore((s) => s.section);
  return (
    <div className={cn(panel, 'overflow-hidden')}>
      <div data-scroll className="h-full overflow-y-auto px-8 py-7">
        {section === 'apps' ? <Apps /> : section === 'games' ? <Games /> : section === 'store' ? <Store /> : section === 'settings' ? <SettingsSection /> : <Home />}
      </div>
    </div>
  );
}

const dot = (ok: boolean, warn?: boolean) => <span className={cn('h-2.5 w-2.5 shrink-0 rounded-full', ok ? 'bg-emerald-400' : warn ? 'bg-amber-400' : 'bg-red-400')} />;

function useQuickActions() {
  const set = useStore((s) => s.settings);
  const telao = useStore((s) => s.telaoOpen);
  const meta = useStore((s) => s.meta);
  const cinemaDim = useStore((s) => s.cinemaDim);
  const reclined = useStore((s) => s.reclined);
  return [
    { label: set.displayMode === 'stereo' ? 'Modo VR: ON' : 'Modo VR', icon: Glasses, on: set.displayMode === 'stereo', fn: () => setDisplayMode(set.displayMode === 'stereo' ? 'single' : 'stereo') },
    { label: 'Giroscópio', icon: Compass, on: set.gyroEnabled, fn: () => S().setSetting('gyroEnabled', !set.gyroEnabled) },
    { label: 'Mãos', icon: Hand, on: set.handTracking, fn: () => S().setSetting('handTracking', !set.handTracking) },
    { label: 'Passthrough', icon: Camera, on: set.passthrough, fn: () => S().setSetting('passthrough', !set.passthrough) },
    { label: 'Modo 3DoF', icon: Smartphone, on: is3dof(set), fn: () => set3dof(!is3dof(set)) },
    { label: 'Telão', icon: MonitorPlay, on: telao, fn: toggleTelao },
    { label: meta ? 'Sair do Meta' : 'Metaverso', icon: Orbit, on: meta, fn: () => (meta ? exitMeta() : enterMeta()) },
    { label: 'Recalibrar', icon: RotateCcw, on: false, fn: recenter },
    // ---- Meta Quest 3S–style features ----
    { label: 'Modo cinema', icon: Clapperboard, on: cinemaDim, fn: toggleCinemaDim },
    { label: 'Organizar janelas', icon: LayoutDashboard, on: false, fn: arrangeWindows },
    { label: 'Modo deitado', icon: Bed, on: reclined, fn: toggleReclined },
    { label: 'Toque duplo', icon: Vibrate, on: set.doubleTap, fn: () => S().setSetting('doubleTap', !set.doubleTap) },
    { label: 'Apps Android', icon: Box, on: false, fn: () => { closeQuick(); openApp('android'); } },
  ];
}

function SystemStatus() {
  const gyro = useStore((s) => s.gyroStatus);
  const handMsg = useStore((s) => s.handMsg);
  const handStatus = useStore((s) => s.handStatus);
  const camStatus = useStore((s) => s.cameraStatus);
  const camMsg = useStore((s) => s.cameraMsg);
  const battery = useStore((s) => s.battery);
  const online = useStore((s) => s.online);
  return (
    <div className="flex flex-col gap-2 rounded-2xl bg-white/5 p-3 text-[14px] text-white/75">
      <div className="flex items-center gap-2">{dot(gyro === 'active', gyro === 'waiting' || gyro === 'off')}<span>Giroscópio: {gyro === 'active' ? 'ativo' : gyro === 'off' ? 'desligado' : gyro === 'waiting' ? 'aguardando' : gyro === 'denied' ? 'negado' : 'indisponível'}</span></div>
      <div className="flex items-center gap-2">{dot(handStatus === 'tracking', ['searching', 'loading', 'starting', 'off'].includes(handStatus))}<span className="truncate">Mãos: {handMsg}</span></div>
      <div className="flex items-center gap-2">{dot(camStatus === 'active', camStatus === 'off' || camStatus === 'starting')}<span className="truncate">Câmera: {camMsg}</span></div>
      <div className="flex items-center gap-2">{dot(!!battery && battery.level > 0.2, !battery)}<span>Bateria: {battery ? `${Math.round(battery.level * 100)}%${battery.charging ? ' (carregando)' : ''}` : 'não informada'}</span></div>
      <div className="flex items-center gap-2">{dot(online)}<span>Rede: {online ? 'conectado' : 'sem conexão'}</span></div>
    </div>
  );
}

function SidePanel() {
  const online = useStore((s) => s.online);
  const quick = useQuickActions().filter((q) => ['Modo VR', 'Modo VR: ON', 'Giroscópio', 'Mãos', 'Recalibrar'].includes(q.label));
  return (
    <div className={cn(panel, 'flex flex-col p-6')}>
      <div className="mb-5 flex items-center gap-3">
        <div className="relative flex h-14 w-14 items-center justify-center rounded-full bg-blue-600">
          <User size={30} className="text-white" />
          <span className={cn('absolute bottom-0 right-0 h-4 w-4 rounded-full border-2 border-[#0d1322]', online ? 'bg-emerald-400' : 'bg-zinc-500')} />
        </div>
        <div>
          <div className="text-[19px] font-semibold text-white">BLVR_User</div>
          <div className="text-sm text-white/55">{online ? 'Online' : 'Offline'}</div>
        </div>
      </div>
      <div className="mb-2 text-[16px] font-medium text-white/80">Status do sistema</div>
      <div className="mb-4"><SystemStatus /></div>
      <div className="mb-2 text-[16px] font-medium text-white/80">Atalhos rápidos</div>
      <div className="grid grid-cols-2 gap-3">
        {quick.map((q) => (
          <Btn key={q.label} onClick={q.fn} className={cn('hv flex h-[80px] flex-col items-center justify-center gap-1.5 rounded-2xl text-[14px]', q.on ? 'bg-blue-600/30 text-white ring-1 ring-blue-400/50' : 'bg-white/[.07] text-white/85')}>
            <q.icon size={26} /> {q.label}
          </Btn>
        ))}
      </div>
    </div>
  );
}

/** Secondary system panel – dominant hand palm up + pinch, the ⋮ button, or key Q. */
export function QuickPanel() {
  const open = useStore((s) => s.quickOpen);
  const fps = useStore((s) => s.fps);
  const actions = useQuickActions();
  return (
    <AnchorGroup id="quick">
      <Placed yaw={0} dist={0} w={820} h={760} visible={open}>
        <div className={cn(panel, 'flex flex-col p-6')}>
          <div className="mb-4 flex items-center gap-3">
            <InfinityIcon size={36} className="text-blue-500" strokeWidth={2.6} />
            <span className="flex-1 text-[24px] font-bold text-white">BLVR · Sistema</span>
            <span className="rounded-full bg-white/10 px-3 py-1 text-sm tabular-nums text-white/70">{fps} FPS</span>
            <Btn onClick={closeQuick} className="hv flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white"><X size={22} /></Btn>
          </div>
          <StatusIcons size={22} className="mb-4 justify-center" labels />
          <div className="grid grid-cols-4 gap-3">
            {actions.map((q) => (
              <Btn key={q.label} onClick={q.fn} className={cn('hv flex h-[96px] flex-col items-center justify-center gap-2 rounded-2xl text-[15px]', q.on ? 'bg-blue-600/35 text-white ring-1 ring-blue-400/50' : 'bg-white/[.07] text-white/85')}>
                <q.icon size={28} /> {q.label}
              </Btn>
            ))}
            <Btn onClick={() => { closeQuick(); openSection('settings'); }} className="hv flex h-[96px] flex-col items-center justify-center gap-2 rounded-2xl bg-white/[.07] text-[15px] text-white/85">
              <Settings size={28} /> Configurações
            </Btn>
          </div>
        </div>
      </Placed>
    </AnchorGroup>
  );
}

/** Hotbar end handle: pinch + hold and pull outward (bigger) / inward (smaller), like the menu corners. */
function BarHandle({ side }: { side: 'left' | 'right' }) {
  return (
    <Btn drag="barSize" title="Segure a pinça e arraste para redimensionar a barra"
      className={cn('grab flex h-12 w-12 shrink-0 items-center justify-center rounded-full border-2 border-white/40 bg-[#0d1322]/90 text-white', side === 'left' ? 'mr-3' : 'ml-3')}>
      <MoveHorizontal size={22} />
    </Btn>
  );
}

export function BottomBar() {
  const inMeta = useStore((s) => s.meta);
  const barScale = useStore((s) => s.settings.barScale);
  useEffect(() => { setBarGeo(barScale); }, [barScale]);
  const menuOpen = useStore((s) => s.menuOpen);
  const lookingDown = useStore((s) => s.lookingDown);
  const section = useStore((s) => s.section);
  const windows = useStore((s) => s.windows);
  const gameActive = useStore((s) => s.game.active);
  const expanded = menuOpen || lookingDown;
  const minimized = windows.filter((w) => w.minimized);
  return (
    <AnchorGroup id="bar">
      <Placed yaw={0} dist={0} w={1100} h={170} visible={!gameActive || expanded}>
        <div className="pointer-events-none flex h-full flex-col items-center justify-start gap-3 pt-2">
          <div className="pointer-events-auto relative flex items-center">
          {expanded && <BarHandle side="left" />}
          <div className="blvr-panel flex items-center gap-2 rounded-[30px] px-3 py-2.5">
            <Btn onClick={toggleMenu} className={cn('hv-solid flex h-[62px] items-center gap-2 rounded-[22px] px-4 text-white', menuOpen ? 'bg-white/10' : 'bg-gradient-to-br from-blue-500 to-indigo-700')}>
              <InfinityIcon size={30} strokeWidth={2.6} />
              {!expanded && <span className="whitespace-nowrap text-[18px] font-bold">BLVR</span>}
            </Btn>
            {/* No animated max-width (that re-runs layout every frame inside a 3D layer) – instant swap */}
            <div className={cn('items-center gap-2', expanded ? 'flex' : 'hidden')}>
              {NAV.map((n) => (
                <Btn key={n.id} onClick={() => openSection(n.id)} title={n.label}
                  className={cn('hv flex h-[62px] w-[66px] shrink-0 items-center justify-center rounded-[22px] text-white', menuOpen && section === n.id ? 'bg-blue-600' : 'bg-white/[.06]')}>
                  <n.icon size={28} />
                </Btn>
              ))}
              {(minimized.length > 0 || inMeta) && <div className="mx-1 h-10 w-px bg-white/15" />}
              {/* Metaverso running like an app: its icon sits here, tap = open its menu */}
              {inMeta && (
                <Btn onClick={toggleMetaHub} title="Metaverso (aberto)" className="hv relative flex h-[62px] w-[62px] shrink-0 items-center justify-center rounded-[22px] bg-gradient-to-br from-sky-500/40 to-fuchsia-600/40 text-white">
                  <Orbit size={28} />
                  <span className="absolute bottom-1.5 h-1 w-5 rounded-full bg-sky-300" />
                </Btn>
              )}
              {minimized.map((w) => {
                const Icon = ICONS[byId(w.app)?.icon ?? 'globe'] ?? Globe;
                return (
                  <Btn key={w.id} onClick={() => restoreWin(w.id)} title={w.title} className="hv relative flex h-[62px] w-[62px] shrink-0 items-center justify-center rounded-[22px] bg-white/[.06] text-white">
                    <Icon size={26} />
                    <span className="absolute bottom-1.5 h-1 w-5 rounded-full bg-blue-400" />
                  </Btn>
                );
              })}
              <div className="mx-2 h-10 w-px shrink-0 bg-white/15" />
              <StatusIcons size={24} className="shrink-0" />
              <Btn onClick={toggleQuick} title="Painel do sistema" className="hv flex h-[62px] w-[48px] shrink-0 items-center justify-center rounded-[22px] text-white">
                <MoreVertical size={26} />
              </Btn>
            </div>
          </div>
          {expanded && <BarHandle side="right" />}
          </div>
          {menuOpen && (
            <div className="pointer-events-auto flex items-center gap-4">
              <Btn drag="menu" title="Segure a pinça para mover o menu" className="grab flex h-10 w-44 items-center justify-center rounded-full bg-white/25">
                <GripHorizontal size={22} className="text-white/80" />
              </Btn>
              {/* Depth slider: pinch + hold and move the hand right (farther) or left (closer) */}
              <Btn drag="menuDepth" title="Segure a pinça e mova: direita = mais longe, esquerda = mais perto"
                className="hv blvr-panel flex h-12 w-[400px] items-center gap-3 rounded-full px-5 text-[14px] text-white">
                <span className="text-white/60">Perto</span>
                <div className="relative h-1.5 flex-1 rounded-full bg-white/20">
                  <div className="absolute top-1/2 h-6 w-6 rounded-full border-2 border-blue-300 bg-white"
                    style={{ left: 'calc((clamp(800, var(--md, 1400), 2500) - 800) / 1700 * 100%)', transform: 'translate(-50%, -50%)' }} />
                </div>
                <span className="text-white/60">Longe</span>
                <span data-md-label className="w-14 text-right font-medium tabular-nums">{(menuGeo.dist / 1000).toFixed(2)} m</span>
              </Btn>
            </div>
          )}
        </div>
      </Placed>
    </AnchorGroup>
  );
}

export function Welcome() {
  const show = useStore((s) => !s.introDone && !s.menuOpen && !s.quickOpen && !s.game.active && s.windows.length === 0);
  const handStatus = useStore((s) => s.handStatus);
  const dom = useStore((s) => s.settings.dominantHand);
  const gt = useStore((s) => s.settings.menuGestureTime);
  const nonDom = dom === 'right' ? 'esquerda' : 'direita';
  return (
    <Placed yaw={0} pitch={4} dist={1300} scale={1.3} w={740} h={370} visible={show} delay={0.3}>
      <div className={cn(panel, 'flex flex-col items-center justify-center gap-4 px-10 text-center')}>
        <div className="flex items-center gap-3">
          <InfinityIcon size={48} className="text-blue-500" strokeWidth={2.6} />
          <span className="text-[34px] font-bold text-white">Bem-vindo ao BLVR</span>
        </div>
        <div className="grid w-full grid-cols-3 gap-3 text-[15px] text-white/75">
          <div className="rounded-2xl bg-white/5 p-3"><Hand className="mx-auto mb-1 text-sky-300" size={26} />Mão {nonDom}: palma ↑ + pinça por {gt.toFixed(1)} s</div>
          <div className="rounded-2xl bg-white/5 p-3"><GripHorizontal className="mx-auto mb-1 text-sky-300" size={26} />Olhe para baixo e selecione <b>BLVR</b></div>
          <div className="rounded-2xl bg-white/5 p-3"><Glasses className="mx-auto mb-1 text-sky-300" size={26} />Toque duplo na tela ou tecla M</div>
        </div>
        <div className="text-sm text-white/45">
          {handStatus === 'tracking' || handStatus === 'searching' ? 'Hand tracking ativo: aponte com a mão e faça pinça para clicar.' : handStatus === 'error' || handStatus === 'unsupported' ? 'Hand tracking indisponível — usando cursor por olhar (toque para selecionar).' : 'Cursor por olhar: o centro da visão seleciona.'}
        </div>
        <Btn onClick={() => openSection('home')} className="hv-solid rounded-full bg-blue-600 px-8 py-3 text-[18px] font-medium text-white">Abrir menu</Btn>
      </div>
    </Placed>
  );
}

/** Corner handle: pinch + hold and pull away from / toward the menu center to resize the menu. */
function ResizeHandle({ side }: { side: 'left' | 'right' }) {
  return (
    <Btn drag="menuSize" title="Segure a pinça e arraste para redimensionar o menu"
      className={cn('grab absolute -bottom-5 z-10 flex h-14 w-14 items-center justify-center rounded-full border-2 border-white/40 bg-[#0d1322]/90 text-white', side === 'right' ? '-right-5' : '-left-5')}>
      <Maximize2 size={24} className={side === 'right' ? 'rotate-90' : ''} />
    </Btn>
  );
}

/*
 * Panels on a cylinder of radius --md. World scale = MENU_BASE × --ms. Side panels' angle = arc / radius.
 * Changing --ms / --md (CSS variables written by core/spatial.ts) resizes / moves the menu with zero React work.
 */
const ARC = (MAIN_W / 2 + GAP + NAV_W / 2) * MENU_BASE;
const ZS = `translateZ(calc(var(--md, 1400) * -1px)) scale(calc(var(--ms, 1) * ${MENU_BASE}))`;
const TF_MAIN = ZS;
const TF_NAV = `rotateY(calc(${ARC}rad * var(--ms, 1) / var(--md, 1400))) ${ZS}`;
const TF_SIDE = `rotateY(calc(${-ARC}rad * var(--ms, 1) / var(--md, 1400))) ${ZS}`;

export function Menu() {
  const open = useStore((s) => s.menuOpen);
  const D = useStore((s) => s.settings.menuDistance);
  const ms = useStore((s) => s.settings.menuScale);
  // Settings (stepper / saved values) -> live geometry
  useEffect(() => { setMenuGeo({ dist: D, scale: ms }); }, [D, ms]);
  return (
    <AnchorGroup id="menu">
      <Placed yaw={0} dist={0} tf={TF_NAV} w={NAV_W} h={MAIN_H} visible={open} delay={0.05}>
        <div className="relative h-full w-full"><NavPanel /><ResizeHandle side="left" /></div>
      </Placed>
      <Placed yaw={0} dist={0} tf={TF_MAIN} w={MAIN_W} h={MAIN_H} visible={open}><MainPanel /></Placed>
      <Placed yaw={0} dist={0} tf={TF_SIDE} w={SIDE_W} h={MAIN_H} visible={open} delay={0.1}>
        <div className="relative h-full w-full"><SidePanel /><ResizeHandle side="right" /></div>
      </Placed>
    </AnchorGroup>
  );
}
