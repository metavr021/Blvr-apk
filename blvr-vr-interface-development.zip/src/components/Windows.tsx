import { useContext, useEffect, useRef } from 'react';
import { Minus, X, Play, Pause, Rewind, FastForward, Globe, Maximize2 } from 'lucide-react';
import { useStore, S, type WinState } from '../core/store';
import { focusWin, closeWin, minimizeWin } from '../core/actions';
import { openKb } from '../core/keyboard';
import { MapsApp } from './apps/MapApps';
import { TwitchApp, SpotifyApp } from './apps/StreamApps';
import { AndroidApp } from './apps/LauncherApp';
import { CraftApp } from './apps/CraftApp';
import { BlockBlastApp } from './apps/BlockBlastApp';
import { BrowserProApp } from './apps/BrowserProApp';
import { ShizukuGuideApp } from './apps/ShizukuGuideApp';
import { TetrisApp, SnakeApp } from './apps/RetroGamesApp';
import { PaintApp, SynthApp, CodePlaygroundApp, SolitaireApp } from './apps/CreativeApps';
import { byId, VIDEOS } from '../core/catalog';
import { Btn, Anchored, EyeCtx, ICONS } from './ui';
import { cn } from '../utils/cn';
import { YouTubeApp, RadioApp } from './apps/MediaApps';
import { WeatherApp, NasaApp, NewsApp, ChessApp, PhotopeaApp } from './apps/InfoApps';
import { CalculatorApp, ClockApp, FxApp, MuseumApp, TicTacToeApp, MemoryApp } from './apps/ExtraApps';
import { PokedexApp, PianoApp, QuizApp, Game2048App, RecipesApp, CountriesApp, QuakesApp, BooksApp } from './apps/FunApps';

function WindowFrame({ win, children }: { win: WinState; children: React.ReactNode }) {
  const focused = useStore((s) => s.focused === win.id);
  const Icon = ICONS[byId(win.app)?.icon ?? 'globe'] ?? Globe;
  return (
    <Anchored id={`win:${win.id}`} visible={!win.minimized}>
      <div className="flex h-full flex-col">
        <div
          onClickCapture={() => focusWin(win.id)}
          className={cn('blvr-panel relative flex flex-1 flex-col overflow-hidden rounded-[28px]', focused && 'blvr-focus')}
        >
          <Btn drag={`win:${win.id}`} onClick={() => focusWin(win.id)} title="Segure a pinça e mova para arrastar" className="hv-text flex h-16 shrink-0 items-center gap-3 border-b border-white/10 px-5 text-white">
            <Icon size={24} className="text-sky-300" />
            <span className="flex-1 truncate text-[20px] font-medium">{win.title}</span>
            <Btn onClick={() => minimizeWin(win.id)} title="Minimizar" className="hv flex h-11 w-11 items-center justify-center rounded-full bg-white/10"><Minus size={22} /></Btn>
            <Btn onClick={() => closeWin(win.id)} title="Fechar" className="hv flex h-11 w-11 items-center justify-center rounded-full bg-white/10 hover:bg-red-500"><X size={22} /></Btn>
          </Btn>
          <div className="relative min-h-0 flex-1">{children}</div>
          <Btn drag={`resize:${win.id}`} title="Redimensionar" className="grab absolute bottom-2 right-2 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-white/15 text-white/80">
            <Maximize2 size={18} className="rotate-90" />
          </Btn>
        </div>
        <div className="flex h-[44px] items-center justify-center">
          <Btn drag={`win:${win.id}`} title="Arrastar janela" className="grab h-3.5 w-52 rounded-full bg-white/35" />
        </div>
      </div>
    </Anchored>
  );
}

/* ---------------- Cinema VR ---------------- */
const masterVideo: { el: HTMLVideoElement | null } = { el: null };
const setCinema = (p: Partial<ReturnType<typeof S>['cinema']>) => S().set({ cinema: { ...S().cinema, ...p } });

function seek(t: number) {
  const c = S().cinema;
  const nt = Math.max(0, Math.min(c.duration || 0, t));
  if (masterVideo.el) masterVideo.el.currentTime = nt;
  setCinema({ time: nt });
}
const fmt = (t: number) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;

function CinemaApp() {
  const eye = useContext(EyeCtx);
  const master = eye !== 'R';
  const c = useStore((s) => s.cinema);
  const ref = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (master) masterVideo.el = ref.current;
    return () => { if (master && masterVideo.el === ref.current) masterVideo.el = null; };
  }, [master]);
  useEffect(() => {
    const v = ref.current;
    if (!v) return;
    if (c.playing) v.play().catch(() => { if (master) { setCinema({ playing: false }); S().toast('Toque na tela para permitir a reprodução', 'warn'); } });
    else v.pause();
  }, [c.playing, c.src, master]);
  useEffect(() => {
    if (master) return;
    const v = ref.current;
    if (v && Math.abs(v.currentTime - c.time) > 0.35) v.currentTime = c.time;
  }, [c.time, master]);

  return (
    <div className="flex h-full flex-col bg-black">
      <div className="relative min-h-0 flex-1">
        <video
          ref={ref}
          src={VIDEOS[c.src].src}
          muted={!master}
          playsInline
          preload="metadata"
          className="h-full w-full object-contain"
          onTimeUpdate={(e) => { if (master && Math.abs(e.currentTarget.currentTime - S().cinema.time) > 0.45) setCinema({ time: e.currentTarget.currentTime }); }}
          onLoadedMetadata={(e) => { if (master) setCinema({ duration: e.currentTarget.duration }); }}
          onEnded={() => master && setCinema({ playing: false })}
        />
        {!c.playing && (
          <Btn onClick={() => setCinema({ playing: true })} className="hv-solid absolute left-1/2 top-1/2 flex h-24 w-24 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-blue-600/90 text-white">
            <Play size={44} fill="white" />
          </Btn>
        )}
      </div>
      <div className="shrink-0 bg-[#0d1322] px-5 pb-4 pt-3">
        <div className="mb-3 flex h-6 items-center gap-[3px]">
          {Array.from({ length: 30 }).map((_, i) => {
            const p = c.duration ? c.time / c.duration : 0;
            return (
              <Btn key={i} onClick={() => seek((i / 30) * (c.duration || 0))} className={cn('hv h-full flex-1 rounded-sm', i / 30 < p ? 'bg-blue-500' : 'bg-white/15')} />
            );
          })}
        </div>
        <div className="flex items-center gap-3">
          <Btn onClick={() => seek(c.time - 10)} className="hv flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-white"><Rewind size={22} /></Btn>
          <Btn onClick={() => setCinema({ playing: !c.playing })} className="hv-solid flex h-12 w-12 items-center justify-center rounded-full bg-blue-600 text-white">
            {c.playing ? <Pause size={22} fill="white" /> : <Play size={22} fill="white" />}
          </Btn>
          <Btn onClick={() => seek(c.time + 10)} className="hv flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-white"><FastForward size={22} /></Btn>
          <span className="w-28 text-center tabular-nums text-white/70">{fmt(c.time)} / {fmt(c.duration || 0)}</span>
          <div className="flex-1" />
          {VIDEOS.map((v, i) => (
            <Btn key={v.title} onClick={() => setCinema({ src: i, time: 0, playing: false, duration: 0 })} className={cn('hv rounded-full px-4 py-2 text-sm', c.src === i ? 'bg-blue-600 text-white' : 'bg-white/10 text-white/80')}>
              {v.title}
            </Btn>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------------- Notes ---------------- */
function NotesApp() {
  const notes = useStore((s) => s.notes);
  return (
    <div className="flex h-full flex-col p-4">
      <div data-scroll className="mb-3 min-h-0 flex-1 overflow-y-auto whitespace-pre-wrap break-words rounded-2xl bg-[#fef9c3] p-5 font-mono text-[22px] text-slate-800">
        {notes || <span className="text-slate-400">Toque em “Escrever” para abrir o teclado grande…</span>}
        <span className="ml-0.5 inline-block h-6 w-0.5 bg-slate-700 align-middle" />
      </div>
      <div className="flex gap-3">
        <Btn onClick={() => openKb('notes')} className="hv-solid flex flex-1 items-center justify-center gap-2 rounded-2xl bg-amber-500 py-4 text-[20px] font-semibold text-black">⌨ Escrever</Btn>
        <Btn hold="clearnotes" title="Segure para apagar tudo" className="hv rounded-2xl bg-white/10 px-6 py-4 text-[18px] text-white">Apagar (segure)</Btn>
      </div>
    </div>
  );
}

export function Windows() {
  const windows = useStore((s) => s.windows);
  return (
    <>
      {windows.map((w) => (
        <WindowFrame key={w.id} win={w}>
          {w.app === 'browser' && <BrowserProApp />}
          {w.app === 'cinema' && <CinemaApp />}
          {w.app === 'maps' && <MapsApp />}
          {w.app === 'notes' && <NotesApp />}
          {w.app === 'youtube' && <YouTubeApp />}
          {w.app === 'radio' && <RadioApp />}
          {w.app === 'spotify' && <SpotifyApp />}
          {w.app === 'twitch' && <TwitchApp />}
          {w.app === 'weather' && <WeatherApp />}
          {w.app === 'nasa' && <NasaApp />}
          {w.app === 'news' && <NewsApp />}
          {w.app === 'chess' && <ChessApp />}
          {w.app === 'photopea' && <PhotopeaApp />}
          {w.app === 'calc' && <CalculatorApp />}
          {w.app === 'clock' && <ClockApp />}
          {w.app === 'fx' && <FxApp />}
          {w.app === 'museum' && <MuseumApp />}
          {w.app === 'tictactoe' && <TicTacToeApp />}
          {w.app === 'memory' && <MemoryApp />}
          {w.app === 'pokedex' && <PokedexApp />}
          {w.app === 'piano' && <PianoApp />}
          {w.app === 'quiz' && <QuizApp />}
          {w.app === 'g2048' && <Game2048App />}
          {w.app === 'recipes' && <RecipesApp />}
          {w.app === 'countries' && <CountriesApp />}
          {w.app === 'quakes' && <QuakesApp />}
          {w.app === 'books' && <BooksApp />}
          {w.app === 'android' && <AndroidApp />}
          {w.app === 'craft' && <CraftApp />}
          {w.app === 'blockblast' && <BlockBlastApp />}
          {w.app === 'tetris' && <TetrisApp />}
          {w.app === 'snake' && <SnakeApp />}
          {w.app === 'solitaire' && <SolitaireApp />}
          {w.app === 'paint' && <PaintApp />}
          {w.app === 'synth' && <SynthApp />}
          {w.app === 'code' && <CodePlaygroundApp />}
          {w.app === 'shizuku' && <ShizukuGuideApp />}
        </WindowFrame>
      ))}
    </>
  );
}
