import { useEffect } from 'react';
import { Play, Pause, Rewind, FastForward, Volume2, VolumeX, Search, X, GripHorizontal, Maximize2 } from 'lucide-react';
import { useStore } from '../core/store';
import { useApps, ytToggle, ytSeek, ytMute } from '../core/apps';
import { closeTelao, openApp, TELAO_BASE } from '../core/actions';
import { getAnchor, setAnchor } from '../core/spatial';
import { Btn, Anchored } from './ui';
import { YtPlayer } from './apps/MediaApps';
import { cn } from '../utils/cn';

/**
 * Telão: a giant YouTube-only screen standing in the scene (world-locked, ~3 m away).
 *  - Pinch the bottom grip to MOVE it, the corner handles to RESIZE it, the "Perto ⟷ Longe" slider for DEPTH.
 *  - Rendered at 1280×830 CSS px and scaled up in 3D (cheap rasterization, smooth on low-end phones).
 *  - Uses the same single YouTube player as the YouTube window (the player moves here, never two at once).
 */
function Corner({ side }: { side: 'left' | 'right' }) {
  return (
    <Btn drag="telaoSize" title="Segure a pinça e arraste para redimensionar o telão"
      className={cn('grab absolute -bottom-6 z-10 flex h-16 w-16 items-center justify-center rounded-full border-2 border-white/40 bg-[#0d1322]/90 text-white', side === 'right' ? '-right-6' : '-left-6')}>
      <Maximize2 size={28} className={side === 'right' ? 'rotate-90' : ''} />
    </Btn>
  );
}

function TelaoBody() {
  const playing = useApps((s) => s.yt.playing);
  const muted = useApps((s) => s.yt.muted);
  const title = useApps((s) => s.yt.title);
  return (
    <div className="flex h-full flex-col">
      <div className="relative h-[720px] shrink-0 rounded-[20px] bg-black ring-2 ring-white/15">
        <div className="touch-frame h-full w-full overflow-hidden rounded-[20px]"><YtPlayer /></div>
        <Corner side="left" />
        <Corner side="right" />
      </div>
      <div className="mt-4 flex h-[90px] items-center gap-3 px-8">
        <Btn onClick={() => ytSeek(-10)} title="Voltar 10 s" className="hv flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-white/10 text-white"><Rewind size={28} /></Btn>
        <Btn onClick={ytToggle} title="Play/Pause" className="hv-solid flex h-16 w-20 shrink-0 items-center justify-center rounded-full bg-red-600 text-white">
          {playing ? <Pause size={32} fill="white" /> : <Play size={32} fill="white" />}
        </Btn>
        <Btn onClick={() => ytSeek(10)} title="Avançar 10 s" className="hv flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-white/10 text-white"><FastForward size={28} /></Btn>
        <Btn onClick={ytMute} title="Som" className="hv flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-white/10 text-white">
          {muted ? <VolumeX size={28} /> : <Volume2 size={28} />}
        </Btn>
        <Btn onClick={() => openApp('youtube')} title="Pesquisar vídeos" className="hv flex h-16 shrink-0 items-center gap-2 rounded-full bg-white/10 px-6 text-[20px] text-white">
          <Search size={24} /> Pesquisar
        </Btn>
        <div className="min-w-0 flex-1 truncate px-2 text-[19px] text-white/80">{title}</div>
        <Btn drag="telao" title="Segure a pinça para mover o telão" className="grab flex h-14 w-40 shrink-0 items-center justify-center rounded-full bg-white/25">
          <GripHorizontal size={28} className="text-white/85" />
        </Btn>
        <Btn drag="telaoDepth" title="Segure a pinça e mova: direita = mais longe, esquerda = mais perto"
          className="hv blvr-panel flex h-14 w-[260px] shrink-0 items-center gap-3 rounded-full px-5 text-[16px] text-white">
          <span className="text-white/60">Perto</span>
          <div className="relative h-1.5 flex-1 rounded-full bg-white/20">
            <div className="absolute top-1/2 h-7 w-7 rounded-full border-2 border-red-300 bg-white"
              style={{ left: 'calc((clamp(1500, var(--d, 3000), 6000) - 1500) / 4500 * 100%)', transform: 'translate(-50%, -50%)' }} />
          </div>
          <span className="text-white/60">Longe</span>
        </Btn>
        <Btn onClick={closeTelao} title="Fechar telão" className="hv flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-white/10 text-white"><X size={28} /></Btn>
      </div>
    </div>
  );
}

export function Telao() {
  const open = useStore((s) => s.telaoOpen);
  const dist = useStore((s) => s.settings.telaoDist);
  const sc = useStore((s) => s.settings.telaoScale);
  // Settings steppers → live geometry (pinch drags write the anchor directly)
  useEffect(() => { if (getAnchor('telao')) setAnchor('telao', { dist, scale: TELAO_BASE * sc }); }, [dist, sc]);
  return (
    <Anchored id="telao" visible={open}>
      {open && <TelaoBody />}
    </Anchored>
  );
}
