import { useState } from 'react';
import { Delete, CornerDownLeft, ArrowBigUp, X, GripHorizontal, Keyboard as KbIcon } from 'lucide-react';
import { useStore } from '../core/store';
import { useApps } from '../core/apps';
import { useStream } from './apps/StreamApps';
import { kbInfo, kbSend, closeKb } from '../core/keyboard';
import { Btn, Anchored } from './ui';
import { cn } from '../utils/cn';

/**
 * Big floating keyboard – lives in the 3D world (outside any window), low in front of the user.
 * Keys are ~2.5× the old in-window keyboard → easy to hit with the hand ray / pinch or the gaze cursor.
 * Pinch the grip to move it.
 */
const ROWS = [
  ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
  ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
  ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'ç'],
  ['z', 'x', 'c', 'v', 'b', 'n', 'm', '.', '-', '/'],
];
const ACCENTS = [
  ['á', 'à', 'â', 'ã', 'é', 'ê', 'í', 'ó', 'ô', 'õ'],
  ['ú', 'ü', '!', '?', ',', ':', ';', '@', '#', '&'],
  ['(', ')', '"', "'", '+', '=', '_', '*', '%', '$'],
  ['ç', 'ñ', '<', '>', '[', ']', '{', '}', '|', '~'],
];

function KeyBtn({ k, onKey, className, children }: { k: string; onKey: (k: string) => void; className?: string; children?: React.ReactNode }) {
  return (
    <Btn onClick={() => onKey(k)} title={k}
      className={cn('hv flex h-[96px] items-center justify-center rounded-2xl bg-white/[.12] text-[38px] font-medium text-white', className ?? 'w-[104px]')}>
      {children ?? k}
    </Btn>
  );
}

export function GlobalKeyboard() {
  const target = useStore((s) => s.kbTarget);
  // subscribe to every source value so the preview updates live
  const bOpen = useStore((s) => s.browser.keyboard);
  const bVal = useStore((s) => s.browser.input);
  const notes = useStore((s) => s.notes);
  const yOpen = useApps((s) => s.yt.keyboard);
  const yVal = useApps((s) => s.yt.input);
  const tVal = useStream((s) => s.tw.input);
  const [caps, setCaps] = useState(false);
  const [alt, setAlt] = useState(false);
  const info = kbInfo();
  const open = !!info && (target === 'browser' ? bOpen : target === 'youtube' ? yOpen : true);
  const value = target === 'browser' ? bVal : target === 'youtube' ? yVal : target === 'notes' ? notes : target === 'twitch' ? tVal : '';
  const rows = alt ? ACCENTS : ROWS;
  const send = (k: string) => kbSend(caps && k.length === 1 ? k.toUpperCase() : k);
  const shown = value.length > 60 ? '…' + value.slice(-60) : value;

  return (
    <Anchored id="keyboard" visible={open}>
      {open && (
        <div className="blvr-panel flex h-full w-full flex-col gap-3 rounded-[36px] p-5">
          <div className="flex items-center gap-3">
            <KbIcon size={30} className="shrink-0 text-sky-300" />
            <div className="flex min-w-0 flex-1 items-center rounded-2xl bg-black/40 px-5 py-3 text-[30px] text-white ring-2 ring-blue-500/60">
              <span className={cn('truncate whitespace-pre', !value && 'text-white/35')}>{shown || `Digite em ${info?.label ?? ''}…`}</span>
              <span className="ml-1 h-9 w-[3px] shrink-0 bg-sky-400" />
            </div>
            <Btn drag="keyboard" title="Segure a pinça para mover o teclado" className="grab flex h-16 w-20 shrink-0 items-center justify-center rounded-2xl bg-white/20 text-white">
              <GripHorizontal size={30} />
            </Btn>
            <Btn onClick={() => kbSend('clear')} className="hv flex h-16 shrink-0 items-center rounded-2xl bg-white/10 px-5 text-[20px] text-white">Limpar</Btn>
            <Btn onClick={closeKb} title="Fechar teclado" className="hv flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-white/10 text-white"><X size={30} /></Btn>
          </div>
          {info?.hint && <div className="-mt-1 px-2 text-[16px] text-white/45">{info.label} · {info.hint}</div>}
          {rows.map((r, i) => (
            <div key={i} className="flex justify-center gap-2.5">
              {r.map((k) => <KeyBtn key={k} k={caps ? k.toUpperCase() : k} onKey={send} />)}
            </div>
          ))}
          <div className="flex justify-center gap-2.5">
            <Btn onClick={() => setCaps(!caps)} title="Maiúsculas" className={cn('hv flex h-[96px] w-[130px] items-center justify-center rounded-2xl text-white', caps ? 'bg-blue-600' : 'bg-white/[.12]')}><ArrowBigUp size={40} /></Btn>
            <Btn onClick={() => setAlt(!alt)} title="Acentos e símbolos" className={cn('hv flex h-[96px] w-[130px] items-center justify-center rounded-2xl text-[26px] text-white', alt ? 'bg-blue-600' : 'bg-white/[.12]')}>{alt ? 'abc' : 'áç?'}</Btn>
            <KeyBtn k=".com" onKey={(k) => kbSend(k)} className="w-[130px] text-[26px]" />
            <KeyBtn k=" " onKey={(k) => kbSend(k)} className="w-[330px] text-[22px] text-white/60">espaço</KeyBtn>
            <KeyBtn k="⌫" onKey={(k) => kbSend(k)} className="w-[130px]"><Delete size={38} /></KeyBtn>
            <Btn onClick={() => kbSend('↵')} title="Enter" className="hv-solid flex h-[96px] w-[180px] items-center justify-center gap-2 rounded-2xl bg-blue-600 text-[26px] font-semibold text-white">
              <CornerDownLeft size={32} /> Ir
            </Btn>
          </div>
        </div>
      )}
    </Anchored>
  );
}
