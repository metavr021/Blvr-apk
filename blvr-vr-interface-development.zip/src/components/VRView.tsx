import { useEffect, useMemo } from 'react';
import { useStore } from '../core/store';
import { initInput } from '../core/input';
import { startRenderer } from '../core/renderer';
import { measure } from '../core/view';
import { Eye } from './Eye';

/** Barrel pre-distortion displacement map (experimental lens correction; costs GPU – off by default). */
function barrelMap(): string {
  const N = 96;
  const c = document.createElement('canvas');
  c.width = c.height = N;
  const ctx = c.getContext('2d');
  if (!ctx) return '';
  const img = ctx.createImageData(N, N);
  for (let y = 0; y < N; y++) {
    for (let x = 0; x < N; x++) {
      const u = ((x + 0.5) / N) * 2 - 1;
      const v = ((y + 0.5) / N) * 2 - 1;
      const r2 = u * u + v * v;
      const i = (y * N + x) * 4;
      img.data[i] = Math.round((0.5 + (u * r2) / 8) * 255);
      img.data[i + 1] = Math.round((0.5 + (v * r2) / 8) * 255);
      img.data[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return c.toDataURL();
}

export function VRView() {
  const stereo = useStore((s) => s.settings.displayMode === 'stereo');
  const distortion = useStore((s) => s.settings.distortion);
  const k = useStore((s) => s.settings.distortionStrength);
  const map = useMemo(() => (distortion ? barrelMap() : ''), [distortion]);

  useEffect(() => {
    initInput();
    return startRenderer();
  }, []);
  // Eye layout changed -> re-measure the primary stage
  const sep = useStore((s) => s.settings.separation);
  useEffect(() => { const t = setTimeout(measure, 30); return () => clearTimeout(t); }, [stereo, sep]);

  return (
    <div className="vr-root fixed inset-0 flex bg-black">
      {distortion && (
        <svg width="0" height="0" style={{ position: 'absolute' }} aria-hidden>
          <filter id="blvr-barrel" primitiveUnits="objectBoundingBox" x="0" y="0" width="1" height="1" colorInterpolationFilters="sRGB">
            <feImage href={map} x="0" y="0" width="1" height="1" preserveAspectRatio="none" result="map" />
            <feDisplacementMap in="SourceGraphic" in2="map" scale={4 * k} xChannelSelector="R" yChannelSelector="G" />
          </filter>
        </svg>
      )}
      {stereo ? (<><Eye key="L" eye="L" /><Eye key="R" eye="R" /></>) : <Eye key="M" eye="M" />}
      {stereo && <div className="pointer-events-none absolute inset-y-0 left-1/2 w-[2px] -translate-x-1/2 bg-black" />}
    </div>
  );
}
