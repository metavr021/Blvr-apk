import { createContext, useEffect, useLayoutEffect, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import { registerEl, unregisterEl } from '../core/spatial';
import {
  Globe, Film, Target, Map as MapIcon, Notebook, Zap, Moon, Circle, Sparkles, Rocket, Trees,
  Monitor, Calculator, Clock, Coins, Landmark, Hash, Brain,
  Orbit, CircleDot, Piano, Grid3x3, ChefHat, Flag, Activity, Library, Box, Smartphone,
  MonitorPlay, Radio as RadioIcon, CloudSun, Music, Tv, Telescope, Crown, Newspaper, BookOpen, Image as ImageIcon,
  Palette, Terminal, Wifi, WifiOff, Battery, BatteryCharging, BatteryLow, BatteryMedium, BatteryFull, Compass, Hand, type LucideIcon,
} from 'lucide-react';
import { cn } from '../utils/cn';
import { useStore } from '../core/store';
import type { EyeId } from '../core/view';

export const EyeCtx = createContext<EyeId>('M');

export const ICONS: Record<string, LucideIcon> = {
  globe: Globe, film: Film, target: Target, map: MapIcon, notebook: Notebook, zap: Zap,
  moon: Moon, circle: Circle, sparkles: Sparkles, rocket: Rocket, trees: Trees,
  youtube: MonitorPlay, radio: RadioIcon, cloud: CloudSun, music: Music, tv: Tv, telescope: Telescope,
  crown: Crown, newspaper: Newspaper, book: BookOpen, image: ImageIcon,
  monitor: Monitor, calculator: Calculator, clock: Clock, coins: Coins, landmark: Landmark, hash: Hash, brain: Brain,
  orbit: Orbit, circledot: CircleDot, piano: Piano, grid: Grid3x3, chef: ChefHat, flag: Flag, activity: Activity, library: Library,
  box: Box, smartphone: Smartphone, palette: Palette, terminal: Terminal,
};

/** An interactive object. Clicks only arrive through the BLVR input system (hand pinch, gaze, touch, mouse). */
export function Btn({ onClick, className, children, hold, drag, style, title }: {
  onClick?: () => void; className?: string; children?: ReactNode; hold?: string; drag?: string; style?: CSSProperties; title?: string;
}) {
  return (
    <div
      role="button"
      aria-label={title}
      data-hit={hold ? undefined : ''}
      data-hold={hold}
      data-drag={drag}
      onClick={onClick}
      style={style}
      className={cn('cursor-pointer select-none', className ?? 'hv')}
    >
      {children}
    </div>
  );
}

/** Open/close animation (~300 ms, opacity + scale only: GPU-cheap). Hidden content is skipped by the compositor. */
function Fade({ visible, delay = 0, className, children }: { visible: boolean; delay?: number; className?: string; children: ReactNode }) {
  return (
    <div
      className={cn('h-full w-full', className)}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'none' : 'scale(.9) translateY(24px)',
        transition: `opacity .3s ease ${visible ? delay : 0}s, transform .32s cubic-bezier(.2,1.1,.3,1) ${visible ? delay : 0}s`,
        pointerEvents: visible ? 'auto' : 'none',
      }}
    >
      {children}
    </div>
  );
}

/**
 * Presence: after the close animation, hidden panels get display:none → no layout, no paint,
 * no compositor layers (big win in stereo, where everything exists twice). On open, the element is
 * shown first and the fade starts on the next frames so the animation still plays.
 */
function usePresence(visible: boolean) {
  const [rendered, setRendered] = useState(visible);
  const [shown, setShown] = useState(visible);
  useEffect(() => {
    if (visible) {
      setRendered(true);
      let r2 = 0;
      const r1 = requestAnimationFrame(() => { r2 = requestAnimationFrame(() => setShown(true)); });
      return () => { cancelAnimationFrame(r1); cancelAnimationFrame(r2); };
    }
    setShown(false);
    const t = setTimeout(() => setRendered(false), 360);
    return () => clearTimeout(t);
  }, [visible]);
  return { rendered, shown };
}

const hideStyle = (visible: boolean, rendered: boolean) => ({
  visibility: (visible ? 'visible' : 'hidden') as 'visible' | 'hidden',
  transition: `visibility 0s linear ${visible ? '0s' : '.34s'}`,
  display: rendered ? undefined : 'none',
});

/**
 * Places a flat panel on a sphere around the user (yaw/pitch in degrees, dist in px ≈ mm).
 * `scale` lets a panel sit farther away (correct stereo depth) while keeping its angular size.
 * `tf` overrides the transform (used by the menu for CSS-variable driven size/depth).
 * Use only for static placements – moving things use <Anchored>.
 */
export function Placed({ yaw, pitch = 0, dist, w, h, children, visible = true, delay = 0, className, scale = 1, tf }: {
  yaw: number; pitch?: number; dist: number; w: number; h: number; children: ReactNode; visible?: boolean; delay?: number; className?: string; scale?: number; tf?: string;
}) {
  const { rendered, shown } = usePresence(visible);
  return (
    <div
      className="absolute left-0 top-0"
      style={{
        width: w, height: h, marginLeft: -w / 2, marginTop: -h / 2,
        transform: tf ?? `rotateY(${yaw}deg) rotateX(${-pitch}deg) translateZ(${-dist}px) scale(${scale})`,
        ...hideStyle(shown, rendered),
      }}
    >
      <Fade visible={shown} delay={delay} className={className}>{children}</Fade>
    </div>
  );
}

/**
 * World-anchored container whose transform is owned by core/spatial.ts (mutated imperatively:
 * drag, follow, open-at-gaze). React never writes its transform, so moving it costs no re-render.
 * Without w/h it acts as a 3D group (children use <Placed> relative to it).
 */
export function Anchored({ id, visible = true, children, className, delay }: { id: string; visible?: boolean; children: ReactNode; className?: string; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    registerEl(id, el);
    return () => unregisterEl(id, el);
  }, [id]);
  const { rendered, shown } = usePresence(visible);
  return (
    <div ref={ref} className="absolute left-0 top-0" style={{ transformStyle: 'preserve-3d', ...hideStyle(shown, rendered) }}>
      <Fade visible={shown} delay={delay} className={className}>{children}</Fade>
    </div>
  );
}

/** 3D group (no fade) – keeps preserve-3d so nested <Placed> panels get real depth. */
export function AnchorGroup({ id, children }: { id: string; children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    registerEl(id, el);
    return () => unregisterEl(id, el);
  }, [id]);
  return <div ref={ref} className="absolute left-0 top-0 h-0 w-0" style={{ transformStyle: 'preserve-3d' }}>{children}</div>;
}

export function useClock() {
  const [t, setT] = useState(() => new Date());
  useEffect(() => { const i = setInterval(() => setT(new Date()), 10000); return () => clearInterval(i); }, []);
  return t.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

export function StatusIcons({ size = 22, className, labels }: { size?: number; className?: string; labels?: boolean }) {
  const time = useClock();
  const online = useStore((s) => s.online);
  const net = useStore((s) => s.netType);
  const battery = useStore((s) => s.battery);
  const gyro = useStore((s) => s.gyroStatus);
  const hand = useStore((s) => s.handStatus);
  const BIcon = !battery ? Battery : battery.charging ? BatteryCharging : battery.level > 0.7 ? BatteryFull : battery.level > 0.3 ? BatteryMedium : BatteryLow;
  const gyroOk = gyro === 'active';
  const handOk = hand === 'tracking';
  const handWarn = hand === 'searching' || hand === 'loading' || hand === 'starting';
  return (
    <div className={cn('flex items-center gap-4 text-white', className)}>
      <span className="font-semibold tabular-nums" style={{ fontSize: size * 0.95 }}>{time}</span>
      <span className="flex items-center gap-1" title="Wi-Fi">
        {online ? <Wifi size={size} /> : <WifiOff size={size} className="text-red-400" />}
        {labels && <span className="text-sm text-white/60">{online ? (net || 'online') : 'offline'}</span>}
      </span>
      <span className="flex items-center gap-1" title="Bateria">
        <BIcon size={size + 4} className={battery && battery.level < 0.2 ? 'text-red-400' : ''} />
        {battery ? <span className="text-sm text-white/70">{Math.round(battery.level * 100)}%</span> : labels && <span className="text-sm text-white/40">n/d</span>}
      </span>
      <span title="Giroscópio" className={cn('flex items-center', gyroOk ? 'text-emerald-400' : gyro === 'off' ? 'text-white/40' : 'text-amber-400')}>
        <Compass size={size} />
      </span>
      <span title="Hand tracking" className={cn('flex items-center', handOk ? 'text-emerald-400' : handWarn ? 'text-amber-400' : hand === 'off' ? 'text-white/40' : 'text-red-400')}>
        <Hand size={size} />
      </span>
    </div>
  );
}

const ROWS = [
  ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
  ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
  ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'ç'],
  ['z', 'x', 'c', 'v', 'b', 'n', 'm', '.', '-', '/'],
];

export function Keyboard({ onKey, extra = true }: { onKey: (k: string) => void; extra?: boolean }) {
  const caps = useStore((s) => s.kbCaps);
  const setCaps = (v: boolean) => useStore.getState().set({ kbCaps: v });
  return (
    <div className="rounded-2xl border border-white/10 bg-[#0b1020] p-3 shadow-2xl">
      {ROWS.map((r, i) => (
        <div key={i} className="mb-2 flex justify-center gap-2">
          {r.map((k) => {
            const ch = caps ? k.toUpperCase() : k;
            return (
              <Btn key={k} onClick={() => onKey(ch)} className="hv flex h-12 w-14 items-center justify-center rounded-xl bg-white/10 text-xl font-medium text-white">
                {ch}
              </Btn>
            );
          })}
        </div>
      ))}
      <div className="flex justify-center gap-2">
        <Btn onClick={() => setCaps(!caps)} className={cn('hv flex h-12 w-20 items-center justify-center rounded-xl text-lg text-white', caps ? 'bg-blue-600' : 'bg-white/10')}>⇧</Btn>
        {extra && <Btn onClick={() => onKey('.com')} className="hv flex h-12 w-20 items-center justify-center rounded-xl bg-white/10 text-lg text-white">.com</Btn>}
        <Btn onClick={() => onKey(' ')} className="hv flex h-12 w-72 items-center justify-center rounded-xl bg-white/10 text-white/70">espaço</Btn>
        <Btn onClick={() => onKey('⌫')} className="hv flex h-12 w-20 items-center justify-center rounded-xl bg-white/10 text-xl text-white">⌫</Btn>
        <Btn onClick={() => onKey('↵')} className="hv-solid flex h-12 w-28 items-center justify-center rounded-xl bg-blue-600 text-lg font-semibold text-white">Ir ↵</Btn>
      </div>
    </div>
  );
}

/* ---------- Settings controls ---------- */
export function Row({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-white/5 py-3">
      <div className="min-w-0">
        <div className="text-[19px] text-white">{label}</div>
        {hint && <div className="text-sm text-white/45">{hint}</div>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

export function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <Btn onClick={() => onChange(!value)} className={cn('hv-solid relative h-9 w-16 rounded-full transition-colors', value ? 'bg-blue-600' : 'bg-white/15')}>
      <span className={cn('absolute top-1 h-7 w-7 rounded-full bg-white shadow transition-all', value ? 'left-8' : 'left-1')} />
    </Btn>
  );
}

export function Stepper({ value, onChange, step, min, max, fmt }: { value: number; onChange: (v: number) => void; step: number; min: number; max: number; fmt?: (v: number) => string }) {
  const r = (v: number) => Math.round(Math.min(max, Math.max(min, v)) * 1000) / 1000;
  return (
    <div className="flex items-center gap-2">
      <Btn onClick={() => onChange(r(value - step))} className="hv flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-2xl text-white">−</Btn>
      <span className="w-20 text-center text-lg tabular-nums text-white">{fmt ? fmt(value) : value}</span>
      <Btn onClick={() => onChange(r(value + step))} className="hv flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-2xl text-white">+</Btn>
    </div>
  );
}

export function Choice<T extends string>({ value, options, onChange }: { value: T; options: { v: T; label: string; disabled?: boolean }[]; onChange: (v: T) => void }) {
  return (
    <div className="flex gap-1 rounded-xl bg-white/5 p-1">
      {options.map((o) => (
        <Btn
          key={o.v}
          onClick={() => !o.disabled && onChange(o.v)}
          className={cn('hv rounded-lg px-4 py-2 text-base', value === o.v ? 'bg-blue-600 text-white' : o.disabled ? 'text-white/25' : 'text-white/75')}
        >
          {o.label}
        </Btn>
      ))}
    </div>
  );
}
