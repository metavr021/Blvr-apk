import { Play, Download, Trash2, Check, Heart, Settings as SettingsIcon, Clock } from 'lucide-react';
import { useStore, S, type AppId } from '../core/store';
import { CATALOG, type CatalogItem } from '../core/catalog';
import { openApp, openSection, browserGo } from '../core/actions';
import { launchAndroid, droid, openMyApp } from '../core/launcher';
import { AppIcon } from './apps/LauncherApp';
import { Btn, ICONS } from './ui';
import { cn } from '../utils/cn';

function launch(item: CatalogItem) {
  if (item.android) { launchAndroid(item.android); return; }
  if (item.appId) {
    openApp(item.appId as AppId);
    if (item.url) browserGo(item.url);
  } else if (item.kind === 'env') S().setSetting('environment', item.id === 'env-night' ? 'night' : 'void');
}

export function AppTile({ item, onClick, wide }: { item: CatalogItem; onClick?: () => void; wide?: boolean }) {
  const Icon = ICONS[item.icon] ?? ICONS.globe;
  return (
    <Btn onClick={onClick ?? (() => launch(item))} className={cn('hv-lift overflow-hidden rounded-2xl bg-white/5', wide ? 'w-full' : 'w-[150px] shrink-0')}>
      <div className={cn('relative flex h-[104px] items-center justify-center bg-gradient-to-br', item.gradient)}>
        {item.cover ? <img src={item.cover} alt="" className="absolute inset-0 h-full w-full object-cover" draggable={false} />
          : <Icon size={46} className="text-white drop-shadow-lg" strokeWidth={1.8} />}
        {item.comingSoon && <span className="absolute right-2 top-2 rounded-full bg-black/60 px-2 py-0.5 text-[11px] text-white">Em breve</span>}
      </div>
      <div className="truncate px-3 py-2 text-[15px] text-white/90">{item.name}</div>
    </Btn>
  );
}

export function Home() {
  const installed = useStore((s) => s.installed);
  const recommended = CATALOG.filter((c) => installed.includes(c.id) && c.kind !== 'env');
  const trending = CATALOG.filter((c) => c.kind === 'app' && !c.builtin);
  return (
    <div className="flex flex-col gap-5">
      <div>
        <h1 className="text-[30px] font-semibold text-white">Olá, seja bem-vindo(a)!</h1>
        <p className="text-[16px] text-white/60">Explore, jogue, assista e muito mais.</p>
      </div>
      <div className="relative h-[230px] shrink-0 overflow-hidden rounded-3xl">
        <img src="img/hero.jpg" alt="" className="absolute inset-0 h-full w-full object-cover" draggable={false} />
        <div className="absolute inset-0 bg-gradient-to-r from-[#08101f]/90 via-[#08101f]/40 to-transparent" />
        <div className="relative flex h-full flex-col justify-center gap-1 px-8">
          <div className="text-[13px] font-semibold uppercase tracking-[.2em] text-sky-300">Destaque BLVR</div>
          <div className="text-[34px] font-bold leading-tight text-white">Balões 360</div>
          <div className="mb-4 max-w-[340px] text-[16px] text-white/80">Estoure balões ao seu redor com a pinça ou com o olhar.</div>
          <Btn onClick={() => openApp('balloons')} className="hv-solid flex w-fit items-center gap-2 rounded-full bg-white/20 px-6 py-2.5 text-[17px] font-medium text-white">
            <Play size={18} fill="white" /> Jogar agora
          </Btn>
          <Btn onClick={() => openApp('telao')} className="hv-solid mt-2 flex w-fit items-center gap-2 rounded-full bg-red-600/90 px-5 py-2.5 text-[16px] font-medium text-white">
            <Play size={18} fill="white" /> Telão YouTube
          </Btn>
        </div>
      </div>
      <div>
        <h2 className="mb-3 text-[20px] font-medium text-white">Apps e jogos recomendados</h2>
        <div data-scroll="x" className="flex gap-4 overflow-x-auto pb-3 pt-2">
          {recommended.map((c) => <AppTile key={c.id} item={c} />)}
        </div>
      </div>
      <div>
        <h2 className="mb-3 text-[20px] font-medium text-white">Apps populares</h2>
        <div data-scroll="x" className="flex gap-4 overflow-x-auto pb-3 pt-2">
          {trending.map((c) => <AppTile key={c.id} item={c} onClick={() => (installed.includes(c.id) ? launch(c) : openSection('store'))} />)}
        </div>
      </div>
    </div>
  );
}

export function Apps() {
  const installed = useStore((s) => s.installed);
  const apps = CATALOG.filter((c) => installed.includes(c.id) && c.kind !== 'env');
  return (
    <div>
      <h1 className="mb-1 text-[28px] font-semibold text-white">Aplicativos</h1>
      <p className="mb-5 text-white/55">{apps.length} instalados · aponte e faça pinça para abrir</p>
      <div className="grid grid-cols-5 gap-4">
        {apps.map((c) => <AppTile key={c.id} item={c} wide />)}
        <Btn onClick={() => openSection('settings')} className="hv-lift overflow-hidden rounded-2xl bg-white/5">
          <div className="flex h-[104px] items-center justify-center bg-gradient-to-br from-slate-500 to-slate-800">
            <SettingsIcon size={46} className="text-white" strokeWidth={1.8} />
          </div>
          <div className="px-3 py-2 text-[15px] text-white/90">Configurações</div>
        </Btn>
      </div>
      <MyPhoneApps />
    </div>
  );
}

/** Phone apps the user marked: "abre aqui" ones open in a BLVR window, others open the real app. */
function MyPhoneApps() {
  const my = useStore((s) => s.myApps);
  const apps = my.map(droid).filter((a): a is NonNullable<ReturnType<typeof droid>> => !!a);
  return (
    <div className="mt-7">
      <div className="mb-3 flex items-end justify-between">
        <div>
          <h2 className="text-[22px] font-semibold text-white">Meus apps do celular</h2>
          <p className="text-[14px] text-white/50">Verde = abre numa janela aqui · âmbar = abre o app no celular</p>
        </div>
        <Btn onClick={() => openApp('android')} className="hv rounded-full bg-white/10 px-4 py-2 text-[14px] text-white">Editar</Btn>
      </div>
      <div className="grid grid-cols-6 gap-3">
        {apps.map((a) => (
          <Btn key={a.id} onClick={() => openMyApp(a.id)} title={a.name} className="hv-lift flex flex-col items-center gap-2 rounded-2xl bg-white/5 p-3">
            <span className="relative">
              <AppIcon a={a} />
              <span className={cn('absolute -right-1 -top-1 h-4 w-4 rounded-full border-2 border-[#0d1322]', a.inside ? 'bg-emerald-400' : 'bg-amber-400')} />
            </span>
            <span className="w-full truncate text-center text-[14px] text-white/90">{a.name}</span>
          </Btn>
        ))}
        <Btn onClick={() => openApp('android')} className="hv-lift flex flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-white/20 p-3 text-white/70">
          <span className="text-[34px] leading-none">+</span>
          <span className="text-[14px]">Adicionar</span>
        </Btn>
      </div>
    </div>
  );
}

export function Games() {
  const installed = useStore((s) => s.installed);
  const best = useStore((s) => s.game.best);
  const games = CATALOG.filter((c) => c.kind === 'game');
  return (
    <div>
      <h1 className="mb-1 text-[28px] font-semibold text-white">Jogos</h1>
      <p className="mb-5 text-white/55">Jogos instalados e próximos lançamentos</p>
      <div className="grid grid-cols-2 gap-4">
        {games.map((g) => {
          const have = installed.includes(g.id);
          return (
            <div key={g.id} className="flex overflow-hidden rounded-2xl bg-white/5">
              {g.cover ? <img src={g.cover} alt="" className="h-[130px] w-[150px] shrink-0 object-cover" draggable={false} /> : (() => {
                const GIcon = ICONS[g.icon] ?? ICONS.target;
                return <div className={cn('flex h-[130px] w-[150px] shrink-0 items-center justify-center bg-gradient-to-br', g.gradient)}><GIcon size={48} className="text-white" /></div>;
              })()}
              <div className="flex flex-1 flex-col justify-between p-4">
                <div>
                  <div className="text-[19px] font-semibold text-white">{g.name}</div>
                  <div className="line-clamp-2 text-sm text-white/55">{g.desc}</div>
                </div>
                <div className="flex items-center justify-between">
                  {have ? (
                    <>
                      <span className="text-sm text-white/50">Recorde: {best[g.id] ?? 0}</span>
                      <Btn onClick={() => launch(g)} className="hv-solid flex items-center gap-2 rounded-full bg-blue-600 px-5 py-2 text-white"><Play size={16} fill="white" />Jogar</Btn>
                    </>
                  ) : g.comingSoon ? (
                    <span className="flex items-center gap-1 text-sm text-amber-300"><Clock size={15} /> Em breve</span>
                  ) : (
                    <Btn onClick={() => openSection('store')} className="hv rounded-full bg-white/10 px-5 py-2 text-white">Ver na loja</Btn>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function Store() {
  const installed = useStore((s) => s.installed);
  const wishlist = useStore((s) => s.wishlist);
  const env = useStore((s) => s.settings.environment);
  const items = CATALOG.filter((c) => !c.builtin);
  return (
    <div>
      <h1 className="mb-1 text-[28px] font-semibold text-white">Loja</h1>
      <p className="mb-5 text-white/55">Para instalar ou remover, aponte e <b className="text-white">mantenha a pinça</b> até o círculo completar.</p>
      <div className="flex flex-col gap-3">
        {items.map((c) => {
          const have = installed.includes(c.id);
          const Icon = ICONS[c.icon] ?? ICONS.globe;
          const applied = c.kind === 'env' && ((c.id === 'env-night' && env === 'night') || (c.id === 'env-void' && env === 'void'));
          return (
            <div key={c.id} className="flex items-center gap-4 rounded-2xl bg-white/5 p-3">
              <div className={cn('relative flex h-20 w-28 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br', c.gradient)}>
                {c.cover ? <img src={c.cover} alt="" className="absolute inset-0 h-full w-full object-cover" draggable={false} /> : <Icon size={36} className="text-white" />}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 text-[19px] font-semibold text-white">
                  {c.name}
                  <span className="rounded bg-white/10 px-2 text-xs font-normal uppercase text-white/60">{c.kind === 'env' ? 'ambiente' : c.kind === 'game' ? 'jogo' : 'app'}</span>
                </div>
                <div className="truncate text-sm text-white/55">{c.desc}</div>
                <div className="text-xs text-white/35">
                  {c.comingSoon ? 'Lançamento em breve' : c.source ? `Grátis · ${c.source}` : `Grátis · ${c.size ?? ''}`}
                  {c.touchOnly && <span className="ml-2 rounded bg-amber-500/15 px-1.5 text-amber-300/90">toque direto</span>}
                </div>
              </div>
              <div className="flex shrink-0 gap-2">
                {c.comingSoon ? (
                  <Btn
                    onClick={() => S().set({ wishlist: wishlist.includes(c.id) ? wishlist.filter((x) => x !== c.id) : [...wishlist, c.id] })}
                    className={cn('hv flex items-center gap-2 rounded-full px-5 py-2.5', wishlist.includes(c.id) ? 'bg-pink-600 text-white' : 'bg-white/10 text-white')}
                  >
                    <Heart size={17} fill={wishlist.includes(c.id) ? 'white' : 'none'} /> {wishlist.includes(c.id) ? 'Na lista' : 'Desejar'}
                  </Btn>
                ) : have ? (
                  <>
                    <Btn onClick={() => launch(c)} className="hv-solid flex items-center gap-2 rounded-full bg-blue-600 px-5 py-2.5 text-white">
                      {c.kind === 'env' ? (applied ? <><Check size={17} /> Aplicado</> : 'Aplicar') : <><Play size={16} fill="white" /> Abrir</>}
                    </Btn>
                    <Btn hold={`uninstall:${c.id}`} className="hv flex items-center gap-2 rounded-full bg-white/10 px-4 py-2.5 text-red-300" title="Segure para remover">
                      <Trash2 size={17} /> Segure
                    </Btn>
                  </>
                ) : (
                  <Btn hold={`install:${c.id}`} className="hv-solid flex items-center gap-2 rounded-full bg-emerald-600 px-5 py-2.5 text-white">
                    <Download size={17} /> Segure p/ instalar
                  </Btn>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

