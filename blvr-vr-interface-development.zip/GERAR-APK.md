# Como gerar o APK do BLVR (Android)

O BLVR é um app web (PWA). O APK é gerado empacotando o site com o **PWABuilder**
(ferramenta gratuita da Microsoft que cria um app Android "Trusted Web Activity" usando o Chrome).
Câmera, hand tracking, giroscópio e tela cheia funcionam no APK.

## 1. Publicar o site (precisa de HTTPS)
1. Rode `npm run build` → é gerada a pasta `dist/`.
2. Acesse https://app.netlify.com/drop e **arraste a pasta `dist`** para a página.
3. Copie o endereço gerado (ex.: `https://blvr-123.netlify.app`).
   (Também serve GitHub Pages, Vercel ou Cloudflare Pages.)

## 2. Gerar o APK
1. Acesse https://www.pwabuilder.com e cole o endereço do passo 1 → **Start**.
2. Clique em **Package For Stores** → **Android** → **Generate Package**.
   - Em *Options*, nos campos **Icon URL** e **Maskable icon URL**, use:
     `https://SEU-ENDERECO/icons/blvr-icon.png`
   - **Display mode**: Fullscreen.
3. Baixe o `.zip`. Dentro dele está o **`app-release-signed.apk`**.
4. Guarde também o arquivo **`signing.keystore`** + senhas do zip: são necessários para atualizar o app depois.

## 3. Instalar no celular
1. Envie o `app-release-signed.apk` para o celular (WhatsApp, Drive, cabo USB…).
2. Abra o arquivo e permita **"Instalar apps desconhecidos"** quando o Android pedir.
3. Abra o BLVR e permita **câmera** (hand tracking/passthrough).

## Atualizações
O APK carrega o site publicado: para atualizar o BLVR basta publicar a nova pasta `dist`
no mesmo endereço — não precisa gerar outro APK.

## Sem APK (alternativa rápida)
Abra o endereço no Chrome do celular → menu ⋮ → **Instalar app**. O BLVR ganha ícone na tela
inicial e abre em tela cheia, igual a um app.
